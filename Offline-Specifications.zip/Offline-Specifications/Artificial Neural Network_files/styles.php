#fitem_id_availabilityconditionsjson .availability_grade input[type=text]{width:3em}.que.calculated
.answer{padding:0.3em;width:auto;display:inline}.que.calculated .answer input[type="text"]{width:30%}#page-question-type-calculated.dir-rtl input[name^="answer"],
#page-question-type-calculated.dir-rtl input[name^="unit"],
#page-question-type-calculated.dir-rtl input[name^="multiplier"],
#page-question-type-calculated.dir-rtl input[name^="calcmax"],
#page-question-type-calculated.dir-rtl input[name^="calcmin"],
#page-question-type-calculated.dir-rtl input[name^="number"],
#page-question-type-calculated.dir-rtl input[name^="tolerance"]{direction:ltr;text-align:left}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel label,
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answertolerance_] label[for^='id_tolerance_'],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_'],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-calculated div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answerdisplay_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answerdisplay_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-calculated div[id^=fitem_id_][id*=feedback_],
body#page-question-type-calculatedmulti div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.calculatedmulti .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.calculatedmulti .answer .specificfeedback
*{display:inline;background:#FFF3BF}.que.calculatedmulti .answer .specificfeedback
script{display:none}.que.calculatedmulti .answer div.r0,
.que.calculatedmulti .answer
div.r1{padding:0.3em}.que.calculatedsimple
.answer{padding:0.3em;width:auto;display:inline}.que.calculatedsimple .answer input[type="text"]{width:30%}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answertolerance_] label[for^='id_tolerance_'],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answerdisplay_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-calculatedsimple div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.essay
textarea.qtype_essay_response{width:100%}.que.essay
textarea.qtype_essay_response.qtype_essay_plain{white-space:pre-wrap;font:inherit}.que.essay
textarea.qtype_essay_response.qtype_essay_monospaced{white-space:pre;font-family:Andale Mono,Monaco,Courier New,DejaVu Sans Mono,monospace}.que.essay
.qtype_essay_response{min-height:3em}.que.essay
.qtype_essay_response.readonly{background-color:white}.que.essay div.qtype_essay_response
textarea{width:100%}.que.match .feedback .rightanswer
*{display:inline}.que.match .feedback .rightanswer
script{display:none}body#page-question-type-match div[id^=fitem_id_][id*=subquestions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-match div[id^=fitem_id_][id*=subquestions_] .fitemtitle{font-weight:bold}body#page-question-type-match div[id^=fitem_id_][id*=subanswers_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.multianswer
.feedbackspan{display:block;max-width:70%;background:#fff3bf;padding:0.5em;margin-top:1em;box-shadow:0.5em 0.5em 1em #000}body.ie6 .que.multianswer .feedbackspan,
body.ie7 .que.multianswer .feedbackspan,
body.ie8 .que.multianswer .feedbackspan,
body.ie9 .que.multianswer
.feedbackspan{width:70%}.que.multianswer .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.multianswer .answer .specificfeedback
*{display:inline;background:#FFF3BF}.que.multianswer .answer .specificfeedback
script{display:none}.que.multianswer .answer div.r0,
.que.multianswer .answer
div.r1{padding:0.3em}.que.multianswer
table.answer{margin-bottom:0;width:100%}.que.multichoice .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.multichoice .answer div.r0,
.que.multichoice .answer
div.r1{padding:0.3em 0 0.3em 25px;text-indent:-25px}.que.multichoice .answer div.r0 label,
.que.multichoice .answer div.r1 label,
.que.multichoice .answer div.r0 div.specificfeedback,
.que.multichoice .answer div.r1
div.specificfeedback{text-indent:0}.que.multichoice .answer div.r0 input,
.que.multichoice .answer div.r1
input{margin:0
5px;padding:0;width:15px}.dir-rtl .que.multichoice .answer div.r0,
.dir-rtl .que.multichoice .answer
div.r1{padding:0.3em 25px 0.3em 0}body#page-question-type-multichoice div[id^=fitem_id_][id*=answer_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-multichoice div[id^=fitem_id_][id*=answer_] .fitemtitle{font-weight:bold}body#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{margin-left:0px;margin-right:0px;padding-left:6px;padding-right:0px}body.dir-rtl#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{margin-left:0px;margin-right:0px;padding-left:0px;padding-right:6px}body#page-question-type-multichoice div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-multichoice div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.numerical
.answer{padding:0.3em;width:auto;display:inline}.que.numerical .answer input[type="text"]{width:30%}#page-question-type-numerical.dir-rtl input[name="unitpenalty"],
#page-question-type-numerical.dir-rtl input[name^="answer"],
#page-question-type-numerical.dir-rtl input[name^="tolerance"],
#page-question-type-numerical.dir-rtl input[name^="multiplier"],
#page-question-type-numerical.dir-rtl input[name^="unit"]{direction:ltr;text-align:left}body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body.path-question-type div#fgroup_id_penaltygrp label[for^=id_unitpenalty],
body.path-question-type div[id^=fgroup_id_units_] label[for^='id_unit_'],
body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-numerical div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-numerical div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.shortanswer
.answer{padding:0.3em;width:auto;display:inline}.que.shortanswer .answer
input{width:80%}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-shortanswer div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-shortanswer div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.truefalse .answer div.r0,
.que.truefalse .answer
div.r1{padding:0.3em}div.gradingnavigation
div{float:left;margin-left:2em}div.submissionstatustable,div.submissionfull,div.submissionlinks,div.usersummary,div.feedback,div.gradingsummary{margin-bottom:5em}div.submissionstatus .generaltable,
div.submissionlinks .generaltable,
div.feedback .generaltable,
div.submissionsummarytable .generaltable,
div.attempthistory table,
div.gradingsummary
.generaltable{width:100%}#page-mod-assign-view table.generaltable table
td{border:0px
none}.gradingsummarytable,.feedbacktable,.lockedsubmission,.submissionsummarytable{margin-top:1em}div.submissionsummarytable table tbody tr
td.c0{width:30%}.submittedlate{color:red;font-weight:900}.jsenabled .gradingoptionsform
.fsubmit{display:none}.jsenabled .gradingtable .c1
select{display:none}.quickgradingform .mform
fieldset{margin:0px;padding:0px}.gradingbatchoperationsform .mform
fieldset{margin:0px;padding:0px}td.submissionstatus,div.submissionstatus,a:link.submissionstatus{color:black;background-color:#efefef}td.submissionstatusdraft,div.submissionstatusdraft,a:link.submissionstatusdraft{color:black;background-color:#efefcf}td.submissionstatussubmitted,div.submissionstatussubmitted,a:link.submissionstatussubmitted{color:black;background-color:#cfefcf}td.submissionlocked,div.submissionlocked{color:black;background-color:#efefcf}td.submissionreopened,div.submissionreopened{color:black;background-color:#efefef}td.submissiongraded,div.submissiongraded{color:black;background-color:#cfefcf}td.submissionnotgraded,div.submissionnotgraded{color:black;background-color:#efefef}td.latesubmission,a:link.latesubmission,div.latesubmission{color:black;background-color:#efcfcf}td.earlysubmission,div.earlysubmission{color:black;background-color:#cfefcf}.gradingtable
.c0{display:none}.jsenabled .gradingtable
.c0{display:table-cell}.gradingbatchoperationsform{display:none}.jsenabled
.gradingbatchoperationsform{display:block}.gradingtable tr.selectedrow
td{background-color:#fec}.gradingtable tr.unselectedrow
td{background-color:white}.gradingtable .c0
div.selectall{margin-left:7px}.gradingtable .yui3-menu
ul{margin:0px}.gradingtable .yui3-menu-label{padding-left:0px;line-height:12px}.gradingtable .yui3-menu-label
img{padding:0
3px}.gradingtable .yui3-menu
li{list-style-type:none}.jsenabled .gradingtable .yui3-loading{display:none}.gradingtable .yui3-menu .yui3-menu-content{border:0px;padding-top:0}#page-mod-assign-view div.gradingtable tr
.quickgrademodified{background-color:#FC9}td.submissioneditable{color:red}.expandsummaryicon{cursor:pointer;display:none}.jsenabled
.expandsummaryicon{display:inline}.hidefull{display:none}.quickgradingform form .commentscontainer input,
.quickgradingform form .commentscontainer
textarea{display:none}.jsenabled .quickgradingform form .commentscontainer input,
.jsenabled .quickgradingform form .commentscontainer
textarea{display:inline}#page-mod-assign-view
.previousfeedbackwarning{font-size:140%;font-weight:bold;text-align:center;color:#500}#page-mod-assign-view
.submissionhistory{background-color:#b0b0b0}#page-mod-assign-view .submissionhistory
.cell.historytitle{background-color:#808080}#page-mod-assign-view .submissionhistory
.cell{background-color:#d0d0d0}#page-mod-assign-view .submissionhistory
.singlebutton{display:inline-block;float:right}#page-mod-assign-view.dir-rtl .submissionhistory
.singlebutton{float:left}#page-mod-assign-view .submissionsummarytable
.singlebutton{display:inline-block}.jsenabled .mod-assign-history-link{display:block;cursor:pointer;margin-bottom:7px}.jsenabled .mod-assign-history-link
h4{display:inline}#page-mod-assign-view.jsenabled .attempthistory
h4{margin-bottom:7px;text-align:left}#page-mod-assign-view.jsenabled.dir_rtl .attempthistory
h4{text-align:right}.dir-rtl.jsenabled .mod-assign-history-link
h4{text-align:right}.jsenabled .mod-assign-history-link-open{padding:0
5px 0 20px;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fexpanded) 2px center no-repeat}.jsenabled .mod-assign-history-link-closed{padding:0
5px 0 20px;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed) 2px center no-repeat}.dir-rtl.jsenabled .mod-assign-history-link-closed{padding:0
20px 0 5px;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_rtl) 2px center no-repeat}#page-mod-assign-view
.submithelp{padding:1em}#page-mod-assign-view
.feedbacktitle{font-weight:bold}#page-mod-assign-view .submitconfirm,
#page-mod-assign-view .submissionlinks,
#page-mod-assign-view
.submissionaction{text-align:center}#page-mod-assign-view .submissionsummarytable .c0,
#page-mod-assign-view .mod-assign-history-panel
.c0{width:150px}#page-mod-assign-view .gradingtable .moodle-actionmenu{white-space:nowrap}#page-mod-assign-view .gradingtable .moodle-actionmenu[data-enhanced].show .menu
a{padding-left:12px;padding-right:12px}#page-mod-assign-view .gradingtable .menu-action
img{display:none}.path-mod-book .navtop img.icon,
.path-mod-book .navbottom
img.icon{margin-right:4px;margin-left:4px;border:0;padding:0}.path-mod-book .navbottom,
.path-mod-book
.navtop{text-align:right}.dir-rtl.path-mod-book .navbottom,
.dir-rtl.path-mod-book
.navtop{text-align:left}.path-mod-book
.navtop{margin-bottom:0.5em}.path-mod-book .block_book_toc
ul{margin:0
0 0 5px;padding-left:0;padding-right:0}.dir-rtl.path-mod-book .block_book_toc
ul{margin:0
5px 0 0}.path-mod-book .block_book_toc
li{clear:both;list-style:none;margin-top: .5em}.path-mod-book .block_book_toc li
li{list-style:none}.path-mod-book .block_book_toc .action-list{float:right}.dir-rtl.path-mod-book .block_book_toc .action-list{float:left}.path-mod-book .block_book_toc .action-list
img.smallicon{margin:0
3px}.path-mod-book
.book_toc_none{font-size:0.8em}.path-mod-book .book_toc_none ul ul,
.dir-rtl.path-mod-book .book_toc_none ul
ul{margin-left:0;margin-right:0}.path-mod-book
.book_toc_bullets{font-size:0.8em}.path-mod-book .book_toc_bullets ul
ul{margin-left:20px}.dir-rtl.path-mod-book .book_toc_bullets ul
ul{margin-left:0;margin-right:20px}.path-mod-book .book_toc_bullets li
li{list-style:circle}.path-mod-book
.book_toc_indented{font-size:0.8em}.path-mod-book .book_toc_indented
ul{margin-left:5px}.dir-rtl.path-mod-book .book_toc_indented
ul{margin-left:0;margin-right:5px}.path-mod-book .book_toc_indented ul
ul{margin-left:15px}.dir-rtl.path-mod-book .book_toc_indented ul
ul{margin-left:0;margin-right:15px}.path-mod-book .book_toc_indented li
li{list-style:none}.path-mod-chat .chat-event .picture,
.path-mod-chat .chat-message
.picture{width:40px}.path-mod-chat .chat-event
.text{text-align:left}.path-mod-chat #messages-list,
.path-mod-chat #users-list{list-style-type:none;padding:0;margin:0}.path-mod-chat #chat-header{overflow:hidden}.path-mod-chat #chat-input-area table.generaltable
td.cell{padding:1px}@media all and (max-device-width: 320px){.path-mod-chat #input-message{width:150px}}@media all and (min-device-width: 321px) and (max-device-width: 640px){.path-mod-chat #input-message{width:175px}}#page-mod-chat-view .chatcurrentusers
.chatuserdetails{vertical-align:middle}#page-mod-chat-gui_basic #participants
ul{margin:0;padding:0;list-style-type:none}#page-mod-chat-gui_basic #participants ul
li{list-style-type:none;display:inline;margin-right:10px}#page-mod-chat-gui_basic #participants ul li
.userinfo{display:inline}#page-mod-chat-gui_basic
#messages{padding:0;margin:0}#page-mod-chat-gui_basic #messages
dl{padding:0;margin:6px
0}#page-mod-chat-gui_basic #messages
dt{margin-left:0;margin-right:5px;padding:0;display:inline}#page-mod-chat-gui_basic #messages
dd{padding:0;margin:0}#page-mod-chat-gui_header_js-jsupdate .chat-event,
#page-mod-chat-gui_header_js-jsupdate .chat-message{width:100%}.path-mod-chat .yui-layout-unit-top{background:#FFE39D}.path-mod-chat .yui-layout-unit-right{background:#FFD46B}.path-mod-chat .yui-layout-unit-bottom{background:#FFCB44}.path-mod-chat .yui-layout .yui-layout-hd{border:0}.path-mod-chat .yui-layout .yui-layout-unit div.yui-layout-bd{border:0;background:transparent}.path-mod-chat .yui-layout .yui-layout-unit div.yui-layout-unit-right{background:white}.path-mod-choice
.results{border-collapse:separate}.path-mod-choice .results
.data{vertical-align:top;white-space:nowrap}.path-mod-choice
.button{text-align:center}.path-mod-choice
.attemptcell{width:5px;white-space:nowrap}.path-mod-choice .anonymous,
.path-mod-choice
.names{margin-left:auto;margin-right:auto;width:80%}.path-mod-choice
.downloadreport{border-width:0;margin-left:10%}.path-mod-choice
.choiceresponse{width:100%}.path-mod-choice .choiceresponse
.picture{width:10px;white-space:nowrap}.path-mod-choice .choiceresponse
.fullname{width:100%;white-space:nowrap}.path-mod-choice
.responseheader{width:100%;text-align:center;margin-top:10px}.path-mod-choice .choices .option
label{vertical-align:top}.path-mod-choice .choices .option
input{vertical-align:middle}.path-mod-choice .horizontal,
.path-mod-choice
.vertical{margin-left:10%;margin-right:10%}.path-mod-choice .horizontal .choices
.option{padding-right:20px;display:inline-block;white-space:normal}.path-mod-choice .horizontal .choices
.button{margin-top:10px}.path-mod-choice ul.choices
li{list-style:none}.path-mod-choice
.results{text-align:center}.path-mod-choice .results.anonymous
.graph.horizontal{vertical-align:middle;text-align:left;width:70%}.path-mod-choice .results.anonymous .graph.vertical,
.path-mod-choice
.cell{vertical-align:bottom;text-align:center}.path-mod-choice .results.anonymous
th.header{border:1px
solid inherit}.path-mod-choice .results.names
.header{width:10%;white-space:normal}.path-mod-choice .results.names
.cell{vertical-align:top;text-align:left}.path-mod-choice .results.names .user,
.path-mod-choice
#yourselection{padding:5px}.path-mod-choice .results.names .user .attemptaction,
.path-mod-choice .results.names .user .image,
.path-mod-choice .results.names .user
.fullname{float:left}.path-mod-choice .results.names .user
.fullname{padding-left:5px}.path-mod-choice .results
.data.header{width:10%}.path-mod-choice
.responseaction{text-align:center}.path-mod-choice .results
.option{white-space:normal}.path-mod-choice
.response{overflow:auto}.path-mod-choice .results .option,
.path-mod-choice .results .numberofuser,
.path-mod-choice .results
.percentage{font-weight:bold;font-size:108%}#page-mod-choice-report .downloadreport ul
li{list-style:none;padding:0
20px;display:inline;float:left}.path-mod-choice
.clearfloat{float:none;clear:both}.path-mod-choice.dir-rtl .horizontal .choices
.option{padding-right:0px;padding-left:20px;float:right}.path-mod-choice.dir-rtl .results.anonymous
.graph.horizontal{text-align:right}.path-mod-choice.dir-rtl
.results.anonymous{text-align:center}.path-mod-choice.dir-rtl .results.names
.cell{text-align:right}.path-mod-choice.dir-rtl .results.names .user .attemptaction,
.path-mod-choice.dir-rtl .results.names .user .image,
.path-mod-choice.dir-rtl .results.names .user .fullname,
.path-mod-choice.dir-rtl .results.names .user
.fullname{padding-left:0px;padding-right:5px}.path-mod-choice.dir-rtl
.downloadreport{margin-left:0;margin-right:25%}#page-mod-choice-report.dir-rtl .downloadreport ul
li{float:right}#page-mod-choice-view.dir-rtl
.reportlink{text-align:left}.path-mod-data .fieldadd,
.path-mod-data .sortdefault,
.path-mod-data .defaulttemplate,
#page-mod-data-view .datapreferences,
#page-mod-data-preset
.presetmapping{text-align:center}.path-mod-data-field .c0,
#page-mod-data-view #sortsearch
.c0{text-align:right}#page-mod-data-view .approve
img.icon{width:34px;height:34px}#page-mod-data-view
img.list_picture{border:0px}#page-mod-data-view
div.search_none{display:none}#page-mod-data-view div.search_inline,
#page-mod-data-view
form#latlongfieldbrowse{display:inline}#page-mod-data-view
div#data_adv_form{margin-left:auto;margin-right:auto}#page-mod-data-edit
.basefieldinput{width:300px}#page-mod-data-preset .presetmapping
table{text-align:left;margin-left:auto;margin-right:auto}#page-mod-data-preset
.overwritesettings{margin-bottom:1em}#page-mod-data-preset
table.presets{margin-left:auto;margin-right:auto}.path-mod-data-field .fieldadd,
.path-mod-data-field
.sortdefault{margin:1em
0}.path-mod-data-field .fieldadd select,
.path-mod-data-field .sortdefault
select{margin-left:1em}.path-mod-data-field .fieldname,
.path-mod-data-field
.fielddescription{width:300px}.path-mod-data-field
textarea.optionstextarea{width:300px;height:150px}.path-mod-data-field
input.textareafieldsize{width:50px}.path-mod-data-field
input.picturefieldsize{width:70px}.path-mod-data .action-icon img.portfolio-add-icon{margin-left:0}#page-mod-data-export #notice
span{padding:0
10px}#page-mod-data-edit input[id*="url"]{text-align:left;direction:ltr}.mod-data-default-template
td{vertical-align:top}.mod-data-default-template .template-field{text-align:right}.mod-data-default-template .template-token{text-align:left}.mod-data-default-template
.controls{text-align:center}.mod-data-default-template
searchcontrols{text-align:right}#page-mod-data-templates td.save_template,
#page-mod-data-templates
.template_heading{text-align:center}.dir-rtl .mod-data-default-template .template-field{text-align:left}.dir-rtl .mod-data-default-template .template-token{text-align:right}.dir-rtl .mod-data-default-template
searchcontrols{text-align:left}.feedback_switchrequired
img{}span.feedback_info{font-weight:bold}div.feedback_item_box_left,div.feedback_item_box_right{}div.feedback_depend{background:#DDD}div.feedback_complete_depend{background:#EEE}span.feedback_depend{color:#f00}div.feedback_item_number_left,div.feedback_item_left{float:left}div.feedback_item_number_right,div.feedback_item_right{float:right}div.feedback_item_commands_left{float:right;text-align:right}div.feedback_item_commands_right{float:left;text-align:left}li.feedback_item_check_h_left,li.feedback_item_check_h_right,li.feedback_item_radio_h_left,li.feedback_item_radio_h_right{list-style-type:none;display:inline}div.feedback_item_select_h_left,div.feedback_item_select_h_right{display:block}li.feedback_item_check_v_left,li.feedback_item_check_v_right,li.feedback_item_radio_v_left,li.feedback_item_radio_v_right{list-style-type:none;display:block}div.feedback_item_select_v_left,div.feedback_item_select_v_right{display:block}div.feedback_items
label{display:inline}div.feedback_item_captcha_text_left,div.feedback_item_captcha_img_left{display:inline;margin:5px}div.feedback_item_captcha_text_right,div.feedback_item_captcha_img_right{display:inline;margin:5px}hr.feedback_pagebreak{height:8px;color:#aaa;background-color:#aaa;border:0px}.drag_target_active{opacity: .25}.drag_item_active{opacity: .5}ul#feedback_draglist{list-style:none;padding:0;margin:0}div#feedback_dragarea{width:95%}div
img.feedback_bar_image{height:10px}.path-mod-feedback input,
.path-mod-feedback textarea,
.path-mod-feedback .uneditable-input{width:auto}.forumpost{display:block;position:relative;margin:0
0 1em 0;padding:0;border:1px
solid #000;max-width:100%}.forumpost
.row{width:100%;position:relative}.forumpost .row
.left{float:left;width:43px;overflow:hidden}.forumpost .row .left .grouppictures
a{text-align:center;display:block;margin:6px
2px 0 2px}.forumpost .row .left
.grouppicture{width:20px;height:20px}.forumpost .row .topic,
.forumpost .row .content-mask,
.forumpost .row
.options{margin-left:43px}.forumpost .picture
img{margin:4px}.forumpost .options .commands,
.forumpost .content .attachments,
.forumpost .options .footer,
.forumpost .options
.link{text-align:right}.forumpost .options .forum-post-rating{float:left}.forumpost .content
.posting{overflow:auto;max-width:100%}.forumpost .content .attachedimages
img{max-width:100%}.forumpost .post-word-count{font-size: .85em;font-style:italic}.forumpost .shortenedpost .post-word-count{display:inline;padding:0
.3em}.dir-rtl .forumpost .row .topic,
.dir-rtl .forumpost .row .content-mask,
.dir-rtl .forumpost .row
.options{margin-right:43px;margin-left:0}.dir-rtl .forumpost .row
.left{float:right}.dir-rtl.path-mod-forum
.indent{margin-right:30px;margin-left:0}.path-mod-forum .forumolddiscuss,
#page-mod-forum-search
.c0{text-align:right}.path-mod-forum
.indent{margin-left:30px}.path-mod-forum
.forumheaderlist{width:100%;border-width:1px;border-style:solid;border-collapse:separate;margin-top:10px}.path-mod-forum .forumheaderlist
td{border-width:1px 0px 0px 1px;border-style:solid}.path-mod-forum .forumheaderlist th.header.replies
.iconsmall{margin:0
.3em}.path-mod-forum .forumheaderlist
.picture{width:35px}.path-mod-forum .forumheaderlist .discussion
.starter{vertical-align:middle}.path-mod-forum .forumheaderlist .discussion
.lastpost{white-space:nowrap;text-align:right}.path-mod-forum .forumheaderlist .replies,
.path-mod-forum .forumheaderlist .discussion
.author{white-space:nowrap}#page-mod-forum-subscribers .subscriberdiv,
#page-mod-forum-subscribers
.subscribertable{width:100%;vertical-align:top}#page-mod-forum-subscribers .subscribertable tr
td{vertical-align:top}#page-mod-forum-subscribers .subscribertable tr
td.actions{width:16%;padding-top:3em}#page-mod-forum-subscribers .subscribertable tr td.actions
.actionbutton{margin:0.3em 0;padding:0.5em 0;width:100%}#page-mod-forum-subscribers .subscribertable tr td.existing,
#page-mod-forum-subscribers .subscribertable tr
td.potential{width:42%}#page-mod-forum-discuss
.discussioncontrols{width:100%;margin:5px}#page-mod-forum-discuss .discussioncontrols
.discussioncontrol{width:33%;float:left}#page-mod-forum-discuss
.discussioncontrol.exporttoportfolio{text-align:left}#page-mod-forum-discuss
.discussioncontrol.displaymode{text-align:center}#page-mod-forum-discuss
.discussioncontrol.movediscussion{float:right;width:auto;text-align:right;padding-right:10px}#page-mod-forum-discuss .discussioncontrol.movediscussion
.movediscussionoption{}#page-mod-forum-view
.forumaddnew{margin-bottom:20px}#page-mod-forum-view
.groupmenu{float:left;text-align:left;white-space:nowrap}#page-mod-forum-index .subscription,
#page-mod-forum-view
.subscription{float:right;text-align:right;white-space:nowrap;margin:5px
0}#page-mod-forum-search
.introcontent{padding:15px;font-weight:bold}#page-mod-forum-index .unread a:first-child,
#page-mod-forum-view .unread a:first-child{padding-right:10px}#page-mod-forum-index .unread img,
#page-mod-forum-view .unread
img{margin-left:5px}#page-mod-forum-view .unread
img{margin-left:5px}.dir-rtl#page-mod-forum-view .unread
img{margin-right:5px;margin-left:0}#email
.unsubscribelink{margin-top:20px}#page-mod-forum-view .unread,
.forumpost.unread .row.header,
.path-course-view .unread,span.unread{background-color:#FFD}.forumpost.unread
.row.header{border-bottom:1px solid #DDD}.path-mod-glossary
.glossarypost{width:95%;border-collapse:separate;margin:0px
auto;text-align:left}.path-mod-glossary
.glossarypost.entrylist{border-width:0px}.path-mod-glossary .glossarypost.continuous
.concept{display:inline}.path-mod-glossary .glossarypost
.commands{width:200px;white-space:nowrap}.path-mod-glossary .glossarypost
td.picture{width:35px}.path-mod-glossary .glossarypost .entrylowersection
.aliases{text-align:center}.path-mod-glossary .glossarypost .entrylowersection
.icons{text-align:right;padding-right:5px}.path-mod-glossary .glossarypost .entrylowersection
.ratings{text-align:right;padding-right:5px;padding-bottom:2px}.path-mod-glossary .glossarypost .glossary-hidden-note{margin:0
.45em}.path-mod-glossary
.glossarydisplay{margin-left:auto;margin-right:auto}.path-mod-glossary .glossarydisplay
.tabs{width:100%;margin-bottom:0px}.path-mod-glossary .glossarydisplay .tabs
.side{border-style:none;border-width:0px;width:auto}.path-mod-glossary .glossarydisplay
.separator{width:4px}.path-mod-glossary
table.glossarypopup{width:95%}.path-mod-glossary .entrybox, .path-mod-glossary table.glossaryapproval,
.path-mod-glossary .glossarypost .entrylowersection
table{width:100%;margin-bottom:0em}.glossary-activity-picture{float:left}.glossary-activity-content{margin-left:40px}#page-mod-glossary-view
.glossarycontrol{float:right;text-align:right;white-space:nowrap;margin:5px
0}#page-mod-glossary-view table.glossarycategoryheader,
#page-mod-glossary-import
table.glossaryimportexport{margin-left:auto;margin-right:auto}#page-mod-glossary-view
table.glossarycategoryheader{margin-bottom:0em}#page-mod-glossary-view table.glossarycategoryheader
th{padding:0px}#page-mod-glossary-view td.glossarysearchbox
label{display:inline-block}#page-mod-glossary-showentry #page-content{min-width:600px}#page-mod-glossary-print .mod-glossary-entrylist .mod-glossary-entry{vertical-align:top}#page-mod-glossary-print .displayprinticon,
.path-mod-glossary.dir-rtl
.glossarypost{text-align:right}#page-mod-glossary-print
.displaydate{text-align:right;font-size:0.75em}#page-mod-glossary-print
.strong{font-weight:bold}.path-mod-glossary
.printicon{background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fprint) no-repeat scroll 2px center transparent;padding-left:20px}#page-mod-imscp-view
#imscp_nav{text-align:center;margin-bottom:5px;margin-top:10px}#page-mod-imscp-view #imscp_toc .ygtv-highlight1{font-weight:bold}#page-mod-imscp-view .yui-layout-hd{background-image:none;background-color:#DDD}#page-mod-imscp-view .yui-layout-hd
h2{color:black}.path-mod-lesson .contents,
.path-mod-lesson .standardtable,
.path-mod-lesson .mform .box.contents,
.path-mod-lesson .invisiblefieldset.fieldsetfix
tr{text-align:left}.path-mod-lesson #layout-table{width:100%}.path-mod-lesson .edit_buttons form,
.path-mod-lesson .edit_buttons
input{display:inline}.path-mod-lesson .userinfotable .cell,
.path-mod-lesson .userinfotable
.userpicture{vertical-align:middle}.path-mod-lesson
.invisiblefieldset.fieldsetfix{display:block}.path-mod-lesson
.slideshow{overflow:auto;padding:15px}.path-mod-lesson .menu
.menuwrapper{max-height:400px;overflow:auto;vertical-align:top;margin-bottom:10px}.path-mod-lesson .menu
ul{list-style:none;padding:5px
0px 0px 5px;margin:0px}.path-mod-lesson .menu ul
li{padding-bottom:5px}.path-mod-lesson
.skip{position:absolute;top:-1000em;width:20em}.path-mod-lesson .branchbuttoncontainer.horizontal div,
.path-mod-lesson .branchbuttoncontainer.horizontal
form{display:inline}.path-mod-lesson
.firstpageoptions{width:30%;margin-left:35%;margin-top:1em}.path-mod-lesson .progress_bar_table,
.path-mod-lesson .progress_bar_completed,
.path-mod-lesson
.progress_bar_todo{padding:0;margin:0}.path-mod-lesson
.progress_bar_token{height:20px;width:5px;padding:0;margin:0}.path-mod-lesson .edit_pages_box
.addlinks{margin:0;margin-bottom:1em}.path-mod-lesson
.progress_bar_completed{background-color:green;text-align:right;vertical-align:middle;color:#FFF}.path-mod-lesson
.resourcecontent{text-align:center}.path-mod-lesson .answeroption .fcheckbox > span,
.path-mod-lesson .answeroption .fradio>span{position:relative;float:left}.path-mod-lesson .answeroption .fcheckbox input,
.path-mod-lesson .answeroption .fradio
input{position:absolute;top:2px;margin-top:0px;left:0}.path-mod-lesson .answeroption .fcheckbox label,
.path-mod-lesson .answeroption .fradio
label{padding-left:20px;float:left}.path-mod-lesson .answeroption .felement label p:last-child{margin-bottom:0px}.path-mod-lesson.dir-rtl .answeroption .fcheckbox > span,
.path-mod-lesson.dir-rtl .answeroption .fradio>span{float:right}.path-mod-lesson.dir-rtl .answeroption .fcheckbox input,
.path-mod-lesson.dir-rtl .answeroption .fradio
input{left:inherit;right:0}.path-mod-lesson.dir-rtl .answeroption .fcheckbox label,
.path-mod-lesson.dir-rtl .answeroption .fradio
label{padding-left:0;padding-right:20px;float:right}#page-mod-lesson-view .password-form
.submitbutton{display:inline}.path-mod-lesson
.reviewessay{width:40%;border:1px
solid #DDD;background-color:#EEE}.path-mod-lesson.dir-rtl .contents,
.path-mod-lesson.dir-rtl .standardtable,
.path-mod-lesson.dir-rtl .mform .box.contents,
.path-mod-lesson.dir-rtl .invisiblefieldset.fieldsetfix
tr{text-align:right}.path-mod-lti
.ltiframe{position:relative;width:100%;height:100%}.path-mod-lti .userpicture,
.path-mod-lti .picture.user,
.path-mod-lti
.picture.teacher{width:35px;height:35px;vertical-align:top}.path-mod-lti .feedback .files,
.path-mod-lti .feedback .grade,
.path-mod-lti .feedback .outcome,
.path-mod-lti .feedback
.finalgrade{float:right}.path-mod-lti .feedback
.disabledfeedback{width:500px;height:250px}.path-mod-lti .feedback
.from{float:left}.path-mod-lti .files
img{margin-right:4px}.path-mod-lti .files
a{white-space:nowrap}.path-mod-lti
.late{color:red}.path-mod-lti
.message{text-align:center}#page-mod-lti-submissions
fieldset.felement{margin-left:16%}#page-mod-lti-submissions form#options
div{text-align:right;margin-left:auto;margin-right:20px}#page-mod-lti-submissions .header
.commands{display:inline}#page-mod-lti-submissions
.picture{width:35px}#page-mod-lti-submissions .fullname,
#page-mod-lti-submissions .timemodified,
#page-mod-lti-submissions
.timemarked{text-align:left}#page-mod-lti-submissions .submissions .grade,
#page-mod-lti-submissions .submissions .outcome,
#page-mod-lti-submissions .submissions
.finalgrade{text-align:right}#page-mod-lti-submissions .qgprefs
#optiontable{text-align:right;margin-left:auto}.path-admin-mod-lti .mform .fitem
.fitemtitle{min-width:18em;padding-right:1em}.path-mod-lti .mform .fitem
.fitemtitle{min-width:14em;padding-right:1em}#page-mod-lti-instructor_edit_tool_type .mform .fitem
.fitemtitle{min-width:18em;padding-right:1em}.path-mod-quiz
.statedetails{display:block;font-size:0.7em}#page-mod-quiz-attempt #page .controls,
#page-mod-quiz-summary #page .controls,
#page-mod-quiz-review #page
.controls{text-align:center;margin:8px
auto}#page-mod-quiz-attempt .submitbtns,
#page-mod-quiz-review
.submitbtns{clear:left;text-align:left;padding-top:1.5em}#page-mod-quiz-attempt.dir-rtl .submitbtns,
#page-mod-quiz-review.dir-rtl
.submitbtns{text-align:right}body.jsenabled
.questionflagcheckbox{display:none}#page-mod-quiz-attempt #connection-ok,
#page-mod-quiz-attempt #connection-error{position:fixed;top:0;width:80%;left:10%;color:#555;border-radius:0 0 10px 10px;box-shadow:5px 5px 20px 0 #666;padding:1em
1em 0;z-index:10000}#page-mod-quiz-attempt #connection-error{background-color:#fcc}#page-mod-quiz-attempt #connection-ok{background-color:#cfb;width:60%;left:20%}.generalbox#passwordbox{width:70%;margin-left:auto;margin-right:auto}#passwordform{margin:1em
0}#quiznojswarning{color:red}#quiznojswarning{font-size:0.7em;line-height:1.1}.jsenabled
#quiznojswarning{display:none}.path-mod-quiz #user-picture{margin:0.5em 0}.path-mod-quiz #user-picture
img{width:auto;height:auto;vertical-align:bottom}.path-mod-quiz
.qnbutton{display:block;position:relative;float:left;width:1.5em;height:1.5em;overflow:hidden;margin:0.3em 0.3em 0.3em 0;padding:0;border:1px
solid #bbb;background:#ddd;text-align:center;vertical-align:middle;line-height:1.5em !important;font-weight:bold;text-decoration:none}.path-mod-quiz.dir-rtl
.qnbutton{float:right}.path-mod-quiz .qnbutton .trafficlight,
.path-mod-quiz .qnbutton
.thispageholder{display:block;position:absolute;top:0;bottom:0;left:0;right:0}.path-mod-quiz
.qnbutton.thispage{border-color:#666}.path-mod-quiz .qnbutton.thispage
.thispageholder{border:1px
solid #666}.path-mod-quiz .qnbutton.flagged
.trafficlight{background:url(/moodle/theme/image.php?theme=clean&component=quiz&rev=1488795260&image=navflagged) no-repeat top right}.path-mod-quiz .qnbutton.notyetanswered,
.path-mod-quiz .qnbutton.requiresgrading,
.path-mod-quiz
.qnbutton.invalidanswer{background-color:white}.path-mod-quiz
.qnbutton.correct{background-color:#cfc}.path-mod-quiz .qnbutton.correct
.trafficlight{border-bottom:3px solid #080}.path-mod-quiz
.qnbutton.partiallycorrect{background-color:#ffa}.path-mod-quiz .qnbutton.notanswered,
.path-mod-quiz
.qnbutton.incorrect{background-color:#fcc}.path-mod-quiz .qnbutton.notanswered .trafficlight,
.path-mod-quiz .qnbutton.incorrect
.trafficlight{border-top:3px solid #800}.path-mod-quiz .qnbutton.free:hover{text-decoration:underline}.path-mod-quiz .qnbutton.free
span{cursor:pointer}.path-mod-quiz
.othernav{clear:both;margin:0.5em 0}.path-mod-quiz .othernav a,
.path-mod-quiz .othernav
input{display:block;margin:0.5em 0}#quiz-timer{display:none;margin-top:1em}#quiz-time-left{font-weight:bold}#quiz-timer.timeleft15{background:#fff}#quiz-timer.timeleft14{background:#fee}#quiz-timer.timeleft13{background:#fdd}#quiz-timer.timeleft12{background:#fcc}#quiz-timer.timeleft11{background:#fbb}#quiz-timer.timeleft10{background:#faa}#quiz-timer.timeleft9{background:#f99}#quiz-timer.timeleft8{background:#f88}#quiz-timer.timeleft7{background:#f77}#quiz-timer.timeleft6{background:#f66}#quiz-timer.timeleft5{background:#f55}#quiz-timer.timeleft4{background:#f44}#quiz-timer.timeleft3{background:#f33}#quiz-timer.timeleft2{background:#f22}#quiz-timer.timeleft1{background:#f11}#quiz-timer.timeleft0{background:#f00}#page-mod-quiz-mod #id_reviewoptionshdr
.fitem{width:23%;margin-left:10px}#page-mod-quiz-mod #id_reviewoptionshdr
fieldset.fgroup{width:100%;text-align:left;margin-left:0}#page-mod-quiz-edit div.question div.content .questiontext,
#categoryquestions
.questiontext{text-overflow:ellipsis;position:relative;zoom:1;padding-left:0.3em;max-width:40%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}#page-mod-quiz-edit div.question div.content .questionname,
#categoryquestions
.questionname{white-space:nowrap;overflow:hidden;zoom:1;position:relative;max-width:20%}#page-mod-quiz-edit div.editq div.question div.content .singlequestion a .questionname,
div.editq div.question div.content .singlequestion a
.questiontext{text-decoration:underline}#page-mod-quiz-edit.ie6 div.question div.content
.questiontext{width:50%}#page-mod-quiz-edit.ie6 div.question div.content
.questionname{width:20%}#page-mod-quiz-mod #id_reviewoptionshdr
.fitem{float:left;width:23%;clear:none}#page-mod-quiz-mod #id_reviewoptionshdr
.fitemtitle{width:100%;font-weight:bold;text-align:left;height:2.5em;margin-left:0}#page-mod-quiz-mod #id_reviewoptionshdr
fieldset.fgroup{clear:left;margin:0
0 1em}#page-mod-quiz-mod #id_reviewoptionshdr fieldset.fgroup>span{float:left;clear:left;line-height:1.7}#page-mod-quiz-mod #id_reviewoptionshdr fieldset.fgroup span
label{margin-left:0.4em}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitem{float:right}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr fieldset.fgroup
span{float:right;clear:right}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitemtitle{text-align:right}#page-mod-quiz-view .quizinfo,
#page-mod-quiz-view #page .quizgradefeedback,
#page-mod-quiz-view #page
.quizattempt{text-align:center}#page-mod-quiz-view #page .quizattemptsummary td
p{margin-top:0}table.quizattemptsummary .bestrow
td{background-color:#e8e8e8}table.quizattemptsummary
.noreviewmessage{color:gray}#page-mod-quiz-view
.generaltable.quizattemptsummary{margin-left:auto;margin-right:auto}#page-mod-quiz-view
.generalbox#feedback{width:70%;margin-left:auto;margin-right:auto;padding-bottom:15px}#page-mod-quiz-view .generalbox#feedback
h2{margin:0}#page-mod-quiz-view .generalbox#feedback
h3{text-align:left}#page-mod-quiz-view.dir-rtl .generalbox#feedback
h3{text-align:center}#page-mod-quiz-view .generalbox#feedback
.overriddennotice{text-align:center;font-size:0.7em}.quizstartbuttondiv.quizsecuremoderequired
input{display:none}.jsenabled .quizstartbuttondiv.quizsecuremoderequired
input{display:inline}.mod-quiz .gradedattempt,
.mod-quiz tr.gradedattempt
td{background-color:#e8e8e8}.quizattemptcounts{clear:left;text-align:center;display:inline;margin-left:20%}.dir-rtl
.quizattemptcounts{margin-left:0;margin-right:20%}#page-mod-quiz-view .quizattemptcounts,
.dir-rtl #page-mod-quiz-view
.quizattemptcounts{display:block;margin-left:0;margin-right:0}#page-mod-quiz-summary
#content{text-align:center}#page-mod-quiz-summary
.questionflag{vertical-align:text-bottom}#page-mod-quiz-summary #quiz-timer{text-align:center;margin-top:1em}#page-mod-quiz-summary
.submitbtns{margin-top:1.5em}@media
print{.quiz-secure-window
*{display:none !important}}table.quizreviewsummary{width:100%}table.quizreviewsummary
th.cell{padding:1px
0.5em 1px 1em;font-weight:bold;text-align:right;width:10em;background:#f0f0f0}table.quizreviewsummary
td.cell{padding:1px
1em 1px 0.5em;text-align:left;background:#fafafa}.dir-rtl table.quizreviewsummary
td.cell{text-align:right}#page-mod-quiz-comment
.mform{width:100%}#page-mod-quiz-comment .mform
fieldset{margin:0}#page-mod-quiz-comment
.que{margin:0}#page-mod-quiz-report
h2.main{clear:both}#page-mod-quiz-report div#commands,
#page-mod-quiz-report
.controls{text-align:center}#page-mod-quiz-report
.dubious{background-color:#fcc}#page-mod-quiz-report
.highlight{border:medium solid yellow;background-color:lightYellow}#page-mod-quiz-report
.negcovar{border:medium solid pink}#page-mod-quiz-report
.toggleincludeauto{text-align:center}#page-mod-quiz-report
.gradetheselink{font-size:0.8em}#page-mod-quiz-report .mform
fieldset{margin:0}#page-mod-quiz-report
fieldset.felement.fgroup{margin:0}#page-mod-quiz-report table
th{white-space:normal}#page-mod-quiz-report table#attempts td,
#page-mod-quiz-report table.quizresponseanalysis
td{word-wrap:break-word;max-width:20em}#page-mod-quiz-report table.titlesleft
td.c0{font-weight:bold}#page-mod-quiz-report table
.numcol{text-align:center;vertical-align:middle !important}#page-mod-quiz-report
table#attempts{clear:both;width:80%;margin:0.2em auto}#page-mod-quiz-report table#attempts .header,
#page-mod-quiz-report table#attempts
.cell{padding:4px}#page-mod-quiz-report table#attempts .header
.commands{display:inline}#page-mod-quiz-report table#attempts
.picture{width:40px}#page-mod-quiz-report table#attempts
td{border-left-width:1px;border-right-width:1px;border-left-style:solid;border-right-style:solid;vertical-align:middle}#page-mod-quiz-report table#attempts
.header{text-align:left}#page-mod-quiz-report table#attempts
.picture{text-align:center !important}#page-mod-quiz-report table#attempts.grades span.que,
#page-mod-quiz-report table#attempts
span.avgcell{white-space:nowrap}#page-mod-quiz-report table#attempts span.que
.requiresgrading{white-space:normal}#page-mod-quiz-report table#attempts
.questionflag{vertical-align:text-bottom;padding-left:6px}.dir-rtl#page-mod-quiz-report table#attempts
.questionflag{padding-right:6px;padding-left:0}#page-mod-quiz-report .graph.flexible-wrap{text-align:center;overflow:auto}#page-mod-quiz-report
#cachingnotice{margin-bottom:1em;padding:0.2em}#page-mod-quiz-report #cachingnotice
.singlebutton{margin:0.5em 0 0}#page-mod-quiz-report .bold
.reviewlink{font-weight:normal}#page-mod-quiz-report
tr.lastrowforattempt{border-bottom:lightgrey solid 0.2em}#page-mod-quiz-edit
h2.main{display:inline;padding-right:1em;clear:left}#categoryquestions>tbody>tr:nth-of-type(even){background:#e4e4e4}#categoryquestions>tbody>tr:nth-of-type(even).highlight{background-color:#AFA}#categoryquestions
.header{text-align:center;padding:0
2px;border:0
none}#categoryquestions th.modifiername .sorters,
#categoryquestions th.creatorname
.sorters{font-weight:normal;font-size:0.8em}table#categoryquestions{width:100%;overflow:hidden;table-layout:fixed}#categoryquestions
.iconcol{width:15px;text-align:center;padding:0}#categoryquestions
.checkbox{width:19px;text-align:center;padding:0}#categoryquestions
.qtype{text-align:center}#categoryquestions
.qtype{width:28px;padding:0}#categoryquestions .questiontext
p{margin:0}#page-mod-quiz-edit
div.quizcontents{float:left;width:70%;display:block;clear:left}#page-mod-quiz-edit
div.quizwhenbankcollapsed{width:100%}#page-mod-quiz-edit
div.quizpage{display:block;clear:both;width:100%}#page-mod-quiz-edit div.quizpage
span.pagetitle{margin-top:0.3em;float:left;display:block;color:#006}#page-mod-quiz-edit div.quizpage
.pagecontent{margin-top:0.3em;display:block;float:left;position:relative;margin-left:0.3em;margin-right:0.3em;margin-bottom:0.2em;border-left:thin solid #777;line-height:1.3em;border-radius:0.6em;border-bottom-left-radius:0;border-top-left-radius:0;width:88%;padding:0.15em 0 0.3em;background-color:#d6d6d6}#page-mod-quiz-edit div.quizpage .pagecontent
.pagestatus{border-bottom-right-radius:0.3em;border-top-right-radius:0.3em;margin:0.3em;padding:0.1em 0.1em 0.1em 0.3em;background-color:#eee;font-weight:bold}#page-mod-quiz-edit div.quizpage .pagecontent
form#addquestion{background-color:#fff}#page-mod-quiz-edit div.quizpage .pagecontent form.randomquestionform
div{display:inline-table}#page-mod-quiz-edit div.quizpage .pagecontent form.randomquestionform div
input{display:inline}#page-mod-quiz-edit
.addpage{clear:both;padding-top:0.3em;float:right;margin-right:2em}#page-mod-quiz-edit
.statusdisplay{background-color:#ffc;clear:both;margin:0.3em 1em 0.3em 0;padding:1px
}#page-mod-quiz-edit .statusdisplay
p{margin:0.4em}#page-mod-quiz-edit div.reorder
.reordercontrols{clear:both;padding-right:1em;margin-top:0.5em;padding-top:0.5em;padding-bottom:0.5em}#page-mod-quiz-edit div.reorder .reordercontrols
.moveselectedonpage{clear:right;float:right;padding:0.5em 0.3em;text-align:right}#page-mod-quiz-edit div.reorder .reordercontrols .addnewpagesafterselected,
#page-mod-quiz-edit
.repaginatecommand{float:right;clear:right;padding-right:1em}#page-mod-quiz-edit div.reorder .reordercontrols
.deleteselected{float:right;margin-right:1em}#page-mod-quiz-edit div.reorder
div.question{padding-top:0.2em}#page-mod-quiz-edit div.reorder div.question
div.qnum{width:2.9em;padding-top:0.1em}#page-mod-quiz-edit .reorder div.question
div.content{width:87%;float:left;position:relative;border-radius:0.3em;border-bottom-left-radius:0;border-top-left-radius:0;line-height:1.2em;padding:0.1em;background-color:#F9F9F9}#page-mod-quiz-edit .reorder .questioncontentcontainer
.quiz_randomquestion{position:relative}#page-mod-quiz-edit .reorder div.question div.content
div.quiz_randomquestion{line-height:1em}#page-mod-quiz-edit .reorder
.questioncontentcontainer{overflow:hidden;white-space:nowrap}#page-mod-quiz-edit .reorder .questioncontentcontainer
.randomquestioncategory{overflow:hidden;white-space:nowrap;display:inline;float:none}#page-mod-quiz-edit .reorder .questioncontentcontainer .randomquestioncategory
label{max-width:25%;overflow:hidden;padding-left:0.3em;white-space:nowrap;display:inline-block}#page-mod-quiz-edit .reorder .questioncontentcontainer .randomquestionfromcategory
label{overflow:hidden;white-space:nowrap;display:inline-block}#page-mod-quiz-edit .reorder .questioncontentcontainer .randomquestionfromcategory,
#page-mod-quiz-edit .reorder div.question div.content
.questionpreview{display:inline;float:none}#page-mod-quiz-edit .reorder
fieldset{display:inline}#page-mod-quiz-edit div.reorder div.question
div.qnum{text-align:right;font-size:1em}#page-mod-quiz-edit .questioncontentcontainer
div.randomquestionqlist{padding-left:0.2em;padding-right:0.2em;clear:both;margin:0.5em;margin-top:0.8em}#page-mod-quiz-edit .questioncontentcontainer div.randomquestionqlist
.totalquestionsinrandomqcategory{overflow:auto;white-space:normal}#page-mod-quiz-edit .questioncontentcontainer div.randomquestionqlist
ul{list-style-type:none;margin:0;padding:0}#page-mod-quiz-edit .questioncontentcontainer div.randomquestionqlist ul
li{clear:left;width:100%;overflow:hidden;white-space:nowrap}#page-mod-quiz-edit .questioncontentcontainer div.randomquestionqlist ul li
img{padding-right:0.3em}#page-mod-quiz-edit .questioncontentcontainer div.randomquestionqlist ul li
span{display:inline}#page-mod-quiz-edit .questioncontentcontainer
a{text-decoration:underline}#page-mod-quiz-edit .questioncontentcontainer div.singlequestion
a{text-decoration:underline}#page-mod-quiz-edit .questioncontentcontainer
.randomquestioncategory{font-weight:bold}#page-mod-quiz-edit
div.question{clear:left;width:100%}#page-mod-quiz-edit div.question
div.qnum{display:block;float:left;width:1.4em;padding-right:0.3em;padding-left:0;text-align:right;color:#333}#page-mod-quiz-edit div.question
div.questioncontainer{background-color:#ffc}#page-mod-quiz-edit div.editq div.question
div.content{width:87%;float:left;position:relative;border-radius:0.6em;border-bottom-left-radius:0;border-top-left-radius:0;line-height:1.4em;padding:0.5em}#page-mod-quiz-edit div.question div.content
div.points{top:0.5em;border-left:0.4em solid #FFF;width:8.5em;padding:0.2em;line-height:1em;max-width:30%;position:absolute;right:60px;border-radius:0.2em;border-bottom-left-radius:0;border-top-left-radius:0;display:block;margin:0;background-color:#ddf}#page-mod-quiz-edit div.question div.content div.points
input{width:2em;padding:0}#page-mod-quiz-edit div.question div.content div.points
input.pointssubmitbutton{width:auto}#page-mod-quiz-edit div.question div.content
div.qorder{line-height:1em;max-width:30%;position:absolute;right:60px;border-radius:0.2em;border-bottom-left-radius:0;border-top-left-radius:0;display:block;margin:0;background-color:#ddf}#page-mod-quiz-edit div.question div.content
.editicon{width:15px}#page-mod-quiz-edit div.question div.content .singlequestion .questionname,
#page-mod-quiz-edit div.question div.content .singlequestion
.questiontext{display:inline-block}#page-mod-quiz-edit div.question div.content .singlequestion
.questionpreview{background-color:#eee}#page-mod-quiz-edit div.question div.content
.questiontype{display:block;clear:left;float:left}#page-mod-quiz-edit.dir-rtl div.question div.content
.questiontype{clear:right;float:right}#page-mod-quiz-edit div.question div.content
.questionpreview{display:block;float:left;margin-left:0.3em;padding-left:0.2em;padding-right:0.2em}#page-mod-quiz-edit div.question div.content .questionpreview
a{background-color:#eee}#page-mod-quiz-edit div.question div.content div.quiz_randomquestion
.questionpreview{display:inline;float:none}#page-mod-quiz-edit div.question div.content
div.questioncontrols{float:right;width:55px;position:absolute;right:0.3em;top:0;display:block;padding:0.2em;background-color:#F9F9F9;text-align:right}#page-mod-quiz-edit div.question div.content div.questioncontrols
img.upwithoutdown{padding-right:12px;display:inline}#page-mod-quiz-edit div.question div.content
.questiontext{font-weight:bold}#page-mod-quiz-edit div.question div.content
.questiontype{font-style:italic}#page-mod-quiz-edit .editq div.question
div.qnum{padding-top:0.2em}#page-mod-quiz-edit .editq
div.question{padding-top:0.3em}#page-mod-quiz-edit .editq div.questioncontentcontainer  div.singlequestion
img{float:left;padding-top:0.3em;padding-right:0.3em}#page-mod-quiz-edit .editq div.question
div.content{background-color:#F9F9F9}#page-mod-quiz-edit .editq div.question div.content
.randomquestioncategory{margin-top:0.4em;position:relative;display:inline-block}#page-mod-quiz-edit .editq div.question div.content .randomquestioncategory
a{display:block;max-width:15em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;float:left;position:relative}#page-mod-quiz-edit .editq div.question div.content
.questionpreview{float:left}#page-mod-quiz-edit .editq div.question div.content .questionpreview
a{font-weight:normal;margin-left:0em;display:inline;float:none}#page-mod-quiz-edit .editq div.question div.content .randomquestioncategory .questionpreview
img{padding-right:0.3em}#page-mod-quiz-edit .editq div.question div.content .singlequestion .questioneditbutton .questionname,
#page-mod-quiz-edit .editq div.question div.content .singlequestion .questioneditbutton
.questiontext{float:left}#page-mod-quiz-edit .reorder div.question div.content .singlequestion.missingtype .questionname,
#page-mod-quiz-edit .editq div.question div.content .singlequestion.missingtype
.questionname{font-style:italic;max-width:75%}#page-mod-quiz-edit .editq div.question div.description div.content
.questiontext{max-width:75%}#page-mod-quiz-edit .editq div.question
div.qnum{font-size:1.5em}table#categoryquestions td,
#page-mod-quiz-edit table#categoryquestions
th{overflow:hidden;white-space:nowrap}.questionbankwindow.block{float:right;width:30%;right:0.3em;padding-bottom:0.5em;display:block;border-width:0}.questionbankwindow.block
.content{padding:0}.questionbankwindow .choosecategory,
.questionbankwindow
.createnewquestion{padding:0.3em}.questionbankwindow .createnewquestion
.singlebutton{display:inline}.questionbankwindow
#catmenu_jump{display:block}.questionbank div.categoryquestionscontainer,
.questionbank .categorysortopotionscontainer,
.questionbank .categorypagingbarcontainer,
.questionbank
.categoryselectallcontainer{padding-left:0.3em;padding-right:0.3em}.noquestionsincategory{clear:both;padding-top:1em;padding-bottom:1em}.modulespecificbuttonscontainer{padding-left:0.3em;padding-right:0.3em}.quizquestionlistcontrols{text-align:center}.categoryinfo{padding:0.3em}.path-mod-quiz
.gradingdetails{font-size:small}body #quizcontentsblock
#repaginatedialog{display:none}body.jsenabled #quizcontentsblock #repaginatedialog
.hd{display:block}body.jsenabled #quizcontentsblock #repaginatedialog
.bd{padding:1em}body.jsenabled #quizcontentsblock .repaginatecommand
#repaginatecommand{display:block}#page-mod-quiz-edit
#randomquestiondialog{display:none}#page-mod-quiz-edit
#qtypechoicecontainer{display:none}#page-mod-quiz-edit .questionbankwindow
select#catmenu_jump{width:100%}#page-mod-quiz-edit .questionbankwindow.block
div.header{background-color:#009;background-image:none;padding-top:0.2em;font-weight:bold;border:0
none}#page-mod-quiz-edit .questionbankwindow.block div.header div.title
h2{color:#FFF;text-align:center}#page-mod-quiz-edit .collapsed
.container{display:none}#page-mod-quiz-edit .questionbankwindow a#showbankcmd,
#page-mod-quiz-edit .questionbankwindow
a#hidebankcmd{color:#FFF;text-decoration:underline}#page-mod-quiz-edit .questionbankwindow a#showbankcmd:hover,
#page-mod-quiz-edit .questionbankwindow a#hidebankcmd:hover{color:#009;background-color:#fff;text-decoration:none}#page-mod-quiz-edit .questionbankwindow
#showbankcmd{display:none}#page-mod-quiz-edit .collapsed
#showbankcmd{display:inline}#page-mod-quiz-edit .questionbankwindow
#hidebankcmd{display:inline}#page-mod-quiz-edit .collapsed
#hidebankcmd{display:none}#page-mod-quiz-edit
.quizquestionlistcontrols{display:inline}#page-mod-quiz-edit
.quizpagedelete{position:absolute;top:0.2em;right:0.2em;display:inline}#page-mod-quiz-edit .quizpagedelete
img{background-color:#d6d6d6;padding:0.6em}#page-mod-quiz-edit
.pagecontrols{clear:both;margin-left:0.5em;margin-right:0.5em;padding-top:0.5em}#page-mod-quiz-edit .pagecontrols
.singlebutton{float:left;margin-left:1em}#page-mod-quiz-edit .pagecontrols
.helplink{float:left}#page-mod-quiz-edit
div#randomquestiondialog_c{width:90%}#page-mod-quiz-edit div#randomquestiondialog_c .mform,
#randomquestiondialog_c
select{width:100%}#page-mod-quiz-edit div#repaginatedialog
.mform{margin-left:auto;margin-right:auto}#page-mod-quiz-edit div.container
div.generalbox{position:relative;display:block;border:0
none;margin:0;padding:0}#page-mod-quiz-edit .questionbankwindow .createnewquestion select,
#page-mod-quiz-edit .questionbankwindow #catmenu select,
#page-mod-quiz-edit .questionbankwindow
#menucategory{width:100%}#page-mod-quiz-edit
.paging{margin-top:0;margin-bottom:0;display:block;background-color:#ddd}#page-mod-quiz-edit
.pagingbottom{padding-bottom:0.3em}#page-mod-quiz-edit .paging a:hover{background-color:#eef}#page-mod-quiz-edit #page-footer{clear:both;padding-top:1em}.ie6#page-mod-quiz-edit div.question div.content .questiontext,
.ie6#page-mod-quiz-edit #categoryquestions
.questionname{cursor:pointer}.ie6#page-mod-quiz-edit div.question div.content .questionname,
.ie6#page-mod-quiz-edit #categoryquestions
.questiontext{cursor:pointer}.ie6#page-mod-quiz-edit .reorder .questioncontentcontainer .randomquestioncategory
label{width:35%}.ie6#page-mod-quiz-edit .editq div.question div.content .randomquestioncategory
a{width:40%}#page-mod-quiz-edit #categoryquestions
.questiontext{font-weight:bold}#page-mod-quiz-edit
.categoryinfofield{font-style:italic}#page-mod-quiz-edit
.categorynamefield{font-weight:bold}#page-mod-quiz-edit
a.configurerandomquestion{font-size:small;text-decoration:underline}#page-mod-quiz-edit .questioncontentcontainer
div.randomquestionqlist{background-color:#eee}#page-mod-quiz-edit .questioncontentcontainer div.randomquestionqlist
ul{color:#555}#page-mod-quiz-edit .questioncontentcontainer div.randomquestionqlist
.totalquestionsinrandomqcategory{color:#000}#page-mod-quiz-edit
.categoryinfo{background-color:#eee;border-bottom:1px solid #bbb}#page-mod-quiz-edit
.questionsortoptions{background-color:#ddd}#page-mod-quiz-edit
div.questionbank{background-color:#e6e6ff}#page-mod-quiz-edit div.questionbank form
.invisiblefieldset{clear:both}#page-mod-quiz-edit div.questionbank
.categorysortopotionscontainer{padding-top:0.5em;margin-top:0.3em}#page-mod-quiz-edit div.questionbank .categoryquestionscontainer,
.questionbank .categorysortopotionscontainer,
.questionbank .categorypagingbarcontainer,
.questionbank
.categoryselectallcontainer{background-color:#FFF}#categoryquestions
.questiontext{width:50%}#categoryquestions
.questionname{width:50%}.ie6#page-mod-quiz-edit div.question div.content .questiontext,
.ie6#page-mod-quiz-edit #categoryquestions
.questionname{cursor:pointer}.ie6#page-mod-quiz-edit div.question div.content .questionname,
.ie6#page-mod-quiz-edit #categoryquestions
.questiontext{cursor:pointer}.ie6.path-mod-quiz div.tabtree a span
img.iconsmall{margin:0;vertical-align:baseline;position:relative;top:1px}.ie6#page-mod-quiz-edit div.question div.content
.questiontext{width:50%}.ie6#page-mod-quiz-edit div.question div.content
.questionname{width:20%}.ie6#page-mod-quiz-edit .editq div.question div.content .randomquestioncategory
a{width:40%}.ie6#page-mod-quiz-edit .reorder .questioncontentcontainer .randomquestioncategory
label{width:35%}.qnum
label{padding-right:0.25em}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitem{width:23%;float:right}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitemtitle{text-align:right}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr fieldset.fgroup
span{clear:right;float:right}#page-mod-quiz-edit.dir-rtl div.quizpage
span.pagetitle{float:right}#page-mod-quiz-edit.dir-rtl div.quizpage
.pagecontent{float:right}#page-mod-quiz-edit.dir-rtl
div.question{clear:right}#page-mod-quiz-edit.dir-rtl div.question
div.qnum{float:right}#page-mod-quiz-edit.dir-rtl div.editq div.question
div.content{float:right;height:40px}#page-mod-quiz-edit.dir-rtl div.question div.content
div.points{left:60px;right:auto}#page-mod-quiz-edit.dir-rtl div.question div.content
div.questioncontrols{float:left;left:0.3em;right:auto}#page-mod-quiz-edit.dir-rtl .editq div.question div.content .singlequestion .questioneditbutton .questionname,
#page-mod-quiz-edit.dir-rtl .editq div.question div.content .singlequestion .questioneditbutton
.questiontext{float:right;padding-right:0.3em}#page-mod-quiz-edit.dir-rtl div.question div.content .questiontext,
#page-mod-quiz-edit.dir-rtl #categoryquestions
.questiontext{padding-right:0.3em}#page-mod-quiz-edit.dir-rtl .editq div.questioncontentcontainer div.singlequestion
img{float:right}#page-mod-quiz-edit.dir-rtl .editq div.question div.content
.questionpreview{float:right}#page-mod-quiz-edit.dir-rtl div.question div.content
div.qorder{left:60px;right:auto}#page-mod-quiz-edit.dir-rtl .reorder div.question
div.content{float:right}#page-mod-quiz-edit.dir-rtl
.quizpagedelete{left:0.2em;right:auto}#page-mod-quiz-edit.dir-rtl
div.quizcontents{clear:right;float:right}#page-mod-quiz-edit.dir-rtl
.questionbankwindow.block{float:left}#page-question-edit.dir-rtl td.creatorname, #page-question-edit.dir-rtl
td.modifiername{text-align:center}.path-question.dir-rtl input[name="maxmark"],
.path-question-type.dir-rtl input[name="defaultmark"],
#page-mod-quiz-edit.dir-rtl div.points
input{direction:ltr;text-align:left}#page-mod-quiz-edit.dir-rtl .pagecontrols
.singlebutton{float:right;margin-left:0;margin-right:1em}.path-mod-resource
.resourcecontent{text-align:center}.path-mod-resource
.resourcedetails{font-size:0.8em;color:#555}.resourcelinkdetails{font-size:0.8em;color:#555}.path-mod-scorm
.top{vertical-align:top}.path-mod-scorm .scorm-left{text-align:left}.path-mod-scorm .scorm-center{text-align:center}.path-mod-scorm .scorm-right{text-align:right}.path-mod-scorm
.scoframe{position:relative;width:100%;height:100%}.ios #scormpage
#scorm_content{-webkit-overflow-scrolling:touch;overflow:scroll}#page-mod-scorm-player
#scormtop{position:relative;width:100%;height:30px}#page-mod-scorm-player
#scormbrowse{position:absolute;left:5px;top:0px}#page-mod-scorm-player
#scormnav{position:absolute;right:5px;top:0px;text-align:center;top:3px;width:100%}#page-mod-scorm-player
#scormbox{width:74%;height:100%;position:absolute;right:0px;top:0px}#page-mod-scorm-player
#scormpage{position:relative;width:100%;height:100%}#page-mod-scorm-player #scormpage
#toctree{position:relative;width:100%}#page-mod-scorm-player
#tocbox{position:relative;left:0px;width:100%;height:100%;font-size:0.8em}#page-mod-scorm-player
#toctree{overflow:visible}#page-mod-scorm-player
#tochead{position:relative;text-align:center;top:3px;height:30px}#page-mod-scorm-player #scormpage
.scoframe{frameborder:0}#page-mod-scorm-player #scormpage
#scorm_object{border:none;width:98%;height:98%}#page-mod-scorm-player #scormpage
#scorm_object.scorm_nav_under_content{height:95%}#page-mod-scorm-player #scormpage
#scorm_content{height:100%}#page-mod-scorm-player #scormpage
#scorm_toc{position:relative}#page-mod-scorm-player #scormpage
#scorm_toc_title{font-size:1.2em;font-weight:bold}#page-mod-scorm-player #scormpage
#scorm_tree{border-right:5px solid rgb(239, 245, 255)}#page-mod-scorm-player #scormpage
#scorm_navpanel{text-align:center}#page-mod-scorm-player .toc,
#page-mod-scorm-player .no-toc{width:100%}#page-mod-scorm-player
.structlist{list-style-type:none;white-space:nowrap}#page-mod-scorm-player
.structurelist{position:relative;list-style-type:none;width:96%;margin:0;padding:0}#page-mod-scorm-player .structurelist
ul{padding-left:0.5em;margin-left:0.5em}#page-mod-scorm-player #scormpage #scorm_toc.disabled,
#page-mod-scorm-player #scormpage
#scorm_toc_toggle.disabled{display:none}#page-mod-scorm-view
.structurelist{list-style-type:none;white-space:nowrap}#page-mod-scorm-view
.structurelist{list-style-type:none;white-space:nowrap}#page-mod-scorm-player
#altfinishlink{font-size:140%;border:0px;padding:0px}#page-mod-scorm-player
#scormmode{float:left;border:0px}#page-mod-scorm-player.pagelayout-popup #page-content .region-content{padding:0px}#page-mod-scorm-player.pagelayout-popup #page-wrapper{width:100%}#page-mod-scorm-player .yui-layout-scroll div.yui-layout-bd{overflow:visible}#page-mod-scorm-player .yui-layout-unit-left div.yui-layout-bd{overflow:auto}.path-mod-scorm.forcejavascript .scorm-center{display:none}.path-mod-scorm.forcejavascript
.toc{display:none}.path-mod-scorm.forcejavascript #scormpage
#tocbox{display:none}.path-mod-scorm.jsenabled
.forcejavascriptmessage{display:none}.path-mod-scorm.jsenabled .scorm-center{display:block}.path-mod-scorm.jsenabled
.toc{display:block}.path-mod-scorm.jsenabled #scormpage
#tocbox{display:block}#page-mod-scorm-report-userreporttracks table
.c1{word-wrap:break-word;word-break:break-all}#page-mod-scorm-player #scormpage span.yui3-treeview-icon{display:none}#page-mod-scorm-player #scormpage li.yui3-treeview-has-children>div.yui3-treeview-row>span.yui3-treeview-icon{display:block}#page-mod-scorm-player #scormpage div.yui3-u-1,
#page-mod-scorm-player #scormpage div.yui3-u-3-4,
#page-mod-scorm-player #scormpage div.yui3-u-1-5,
#page-mod-scorm-player #scormpage div.yui3-u-1-24{display:inline-block;*display:inline;zoom:1;letter-spacing:normal;word-spacing:normal;vertical-align:top;text-rendering:auto}#page-mod-scorm-player #scormpage div.yui3-u-1{display:block}#page-mod-scorm-player #scormpage div.yui3-u-3-4{width:75%}#page-mod-scorm-player #scormpage div.yui3-u-1-5{width:20%}#page-mod-scorm-player #scormpage div.yui3-u-1-24{width:4.1666%}#page-mod-scorm-player #scormpage div.yui3-g-r{*letter-spacing:normal;*word-spacing:-0.43em}#page-mod-scorm-player .opera-only :-o-prefocus,
#page-mod-scorm-player #scormpage div.yui3-g-r
img{max-width:100%}.path-mod-survey
.smalltext{font-size:0.75em}.path-mod-survey .surveytable .rblock
label{display:block}.path-mod-survey .surveytable .foundthat,
.path-mod-survey .surveytable
.preferthat{white-space:nowrap}.path-mod-survey .surveytable
.buttoncell{width:5%}.path-mod-survey .surveytable .optioncell,
.path-mod-survey .surveytable
.questioncell{width:50%;vertical-align:top}.path-mod-survey .surveytable
.whitecell{background-color:white}.path-mod-survey #surveyform
th{font-weight:normal;text-align:left}.path-mod-survey #surveyform
th.hresponse{text-align:center;width:9%}#page-mod-survey-report
.fullnamecell{width:10%;vertical-align:top;white-space:nowrap}.path-mod-url
.resourcecontent{text-align:center}.wiki_contentbox{width:80%;margin:auto;min-width:200px;min-height:100px}.wiki_editor{width:50%;margin:auto;margin-top:10px;margin-bottom:10px}.wiki_previewbox{width:50%;margin:auto;border:thin solid blue}.wiki_button{margin:5px}.wiki_warning{color:red}.emptycomments{color:red;display:inline}.wiki-toc{border:1px
solid #BBB;background:#EEE;margin:16px;padding:8px}.wiki-toc-title{color:#666;font-size:1.1em;font-variant:small-caps;text-align:center}.wiki-toc-section{padding:0;margin:2px
8px}.wiki-toc-section-2{padding-left:12px}.wiki-toc-section-3{padding-left:24px}.wiki_form-button{margin-left:0%}.wiki-form-center{text-align:center;margin:auto;width:320px}.wiki-upload-table{margin:8px
auto;clear:both}.wiki-upload-table
table{margin:auto}.wiki-upload-table
h3{margin:4px
0px;text-align:center}.wiki-upload-section{border:1px
solid #EEE;width:400px;margin:8px
auto}.wiki-upload-section
legend{font-weight:bold;font-size:0.9em;margin-left:16px}.wiki-tags{text-align:right}.wiki-tags
span{font-weight:bold}.wiki_modifieduser
p{line-height:35px}.wiki_modifieduser
img{border:thin solid black}.wiki_restore_yes, .wiki_deletecomment_yes,
.dir-rtl .wiki_restore_no, .dir-rtl
.wiki_deletecomment_no{float:left}.wiki_restore_no, .wiki_deletecomment_no,
.dir-rtl .wiki_restore_yes, .dir-rtl
.wiki_deletecomment_yes{float:right}.wiki_restoreform,.wiki_deletecommentform{width:10%;margin:auto}.wiki_versionuser{float:left}.wiki_diffuserleft,.wiki_diffuserright{font-weight:normal;padding-top:1%}.wiki_diffuserleft{float:right}.dir-rtl
.wiki_diffuserleft{float:left}.wiki_diffuserright{float:left}.wiki_compareheading{font-weight:normal}.wiki_restore,.wiki_diffview,.wiki_difftime,.wiki_headingtime{font-size:0.8em;font-weight:normal}.wiki_difftime,.wiki_headingtime{font-style:oblique;text-align:center}.wiki_diff_oldpaging{float:left;width:40%;min-width:200px;margin-left:5%}.wiki_diff_newpaging{float:right;width:40%;min-width:200px;margin-right:5%}.wiki_diff_old,.wiki_diff_new{float:left;min-width:200px;width:40%}.wiki_difftable
td{width:50%;float:left}.wiki_histdate{text-align:left}.wiki_histnewdate{border-top:1px dotted gray}.ouw_deleted{background:#FFA;color:red;text-decoration:line-through}.ouw_added{background:#CFC;color:red}a.wiki_newentry:link,a.wiki_newentry:visited{color:red;font-style:italic}.wiki_newentry
a{color:red;font-style:italic}#intro.generalbox{margin-top:10px;padding:5px}.wiki_navigation_container{margin:0
auto}.wiki_navigation_from{float:left;width:40%;min-width:200px;margin-left:5%}.wiki_navigation_to{float:left;width:40%;min-width:200px;margin-right:5%}.wiki_headingtitle{text-align:center}.wiki_clear{clear:both}.wiki_right{text-align:right}.wiki_index{text-align:right}.notunderlined{text-decoration:none}a.wiki_edit_section{font-size:0.6em;vertical-align:top;position:relative;float:right}.midpad{text-align:center;margin-top:0.4em;margin-bottom:0.4em}.block_wiki_search
ul{margin-top:0.5em;margin-bottom:3px}.wiki-attachment:before{content:url("/mod/wiki/pix/attachment.png");padding-right:2px}#wiki_printable_content{text-align:left}.dir-rtl
#wiki_printable_content{text-align:right}#wiki_printable_content
a{color:black}#wiki_printable_title{font-size:2.2em;text-decoration:underline}.wiki_diff_boxes{width:100%;clear:both}.wiki_diff_paging{width:100%;clear:both}.wiki_grayline{color:gray}.wikisearchresults{padding-left:50px;padding-top:20px}.wiki-diff-container{width:95%;margin:10px
auto}.wiki-diff-container .wiki-diff-leftside,
.wiki-diff-container .wiki-diff-rightside{width:49.5%;margin:0;padding:0;float:left}.wiki-diff-container .wiki-diff-rightside{margin-left:1%}.wiki-diff-container .wiki-diff-heading,
.wiki-diff-container .no-overflow{padding:10px;border:1px
solid #DDD}.wiki-diff-container .wiki-diff-rightside
.wiki_diffversion{text-align:right}.wikieditor-toolbar
img{width:22px;height:22px;vertical-align:middle}.path-mod-wiki
.printicon{background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fprint) no-repeat scroll 2px center transparent;padding-left:20px}#page-mod-wiki-prettyview
.displayprinticon{text-align:right}.path-mod-workshop
.collapsibleregion{margin-bottom:0.75em}.path-mod-workshop
.collapsibleregioncaption{font-weight:bold;font-size:120%}.path-mod-workshop
div.singlebutton{text-align:center;margin:0.75em auto}.path-mod-workshop #workshop-viewlet-assignedassessments div.singlebutton,
.path-mod-workshop #workshop-viewlet-allexamples div.singlebutton,
.path-mod-workshop #workshop-viewlet-examples
div.singlebutton{text-align:left}.path-mod-workshop
.groupwidget{text-align:center;margin:0.75em auto}.path-mod-workshop
.perpagewidget{text-align:center;margin:0.75em auto}.path-mod-workshop .submission-summary{position:relative;margin-bottom:10px}.path-mod-workshop .submission-summary .title,
.path-mod-workshop .submission-summary .author,
.path-mod-workshop .submission-summary .author .fullname,
.path-mod-workshop .submission-summary .author
.picture{display:inline}.path-mod-workshop .submission-summary .title,
.path-mod-workshop .submission-summary .userdate,
.path-mod-workshop .submission-summary .grade-status{margin:0px
0px 0px 40px}.path-mod-workshop .submission-summary
.author{margin-left:1ex}.path-mod-workshop .submission-summary.anonymous .title,
.path-mod-workshop .submission-summary.anonymous .author,
.path-mod-workshop .submission-summary.anonymous .userdate,
.path-mod-workshop .submission-summary.anonymous .grade-status{margin:0px
0px 0px 5px}.path-mod-workshop .submission-summary
.userdate{font-size:x-small;color:#333}.path-mod-workshop .submission-summary .userdate
span{font-style:italic}.path-mod-workshop .submission-summary .author
.picture{position:absolute;top:0px;left:0px}.path-mod-workshop .submission-full{border:1px
solid #ddd;margin:0px
0px 1em 0px}.path-mod-workshop .submission-full
.header{position:relative;background-color:#ddd;padding:3px;min-height:67px}.path-mod-workshop .submission-full .header .title,
.path-mod-workshop .submission-full .header .author,
.path-mod-workshop .submission-full .header
.userdate{margin:0px
0px 0px 80px}.path-mod-workshop .submission-full.anonymous .header .title,
.path-mod-workshop .submission-full.anonymous .header .author,
.path-mod-workshop .submission-full.anonymous .header
.userdate{margin:0px
0px 0px 5px}.path-mod-workshop .submission-full .header
.userdate.created{padding-right:10px}.path-mod-workshop .submission-full .header
.userdate.modified{padding-left:10px;margin-left:0px;border-left:1px solid #000}.path-mod-workshop .submission-full .header
.userdate{font-size:x-small;color:#333;display:inline}.path-mod-workshop .submission-full .header .userdate
span{font-style:italic}.path-mod-workshop .submission-full .header .author
.picture{position:absolute;top:3px;left:3px}.path-mod-workshop .submission-full .content,
.path-mod-workshop .submission-full
.attachments{padding:5px
10px}.path-mod-workshop .submission-full .attachments .files
img.icon{margin-right:5px}.path-mod-workshop .submission-full .attachments .images
div{display:inline-block;margin:5px;padding:5px;border:1px
solid #ddd}.path-mod-workshop .submission-summary.example .title,
.path-mod-workshop .submission-summary.example
.userdate{margin:0px
0px 0px 0px}.path-mod-workshop .submission-full.example
.header{min-height:0px}.path-mod-workshop .submission-full.example .header
.title{margin:0px
0px 0px 0px}.path-mod-workshop
.message{padding:5px
5em 5px 15px;margin:0px
auto 20px auto;width:60%;font-size:80%;position:relative}.path-mod-workshop .message
.singlebutton{text-align:left;margin:0px}.path-mod-workshop
.message.ok{color:#547c22;background-color:#e7f1c3}.path-mod-workshop
.message.error{color:#dd0221;background-color:#ffd3d9}.path-mod-workshop
.message.info{color:#1666a9;background-color:#d2ebff}.path-mod-workshop .allocation-init-results{margin:10px
auto;width:60%;font-size:80%}.path-mod-workshop .allocation-init-results
.indent{margin-left:20px}.path-mod-workshop .allocation-init-results
.ok{color:#547c22;background-color:#e7f1c3}.path-mod-workshop .allocation-init-results
.error{color:#dd0221;background-color:#ffd3d9}.path-mod-workshop .allocation-init-results
.info{color:#1666a9;background-color:#d2ebff}.path-mod-workshop .allocation-init-results
.debug{color:black;background-color:#ddd}.path-mod-workshop
.userplan{width:70%;margin:1em
auto 1em auto;font-size:80%;border-left:1px solid #ddd;border-right:1px solid #ddd}.path-mod-workshop .userplan
th{vertical-align:bottom;white-space:normal;color:#999;border-top:1px solid #ddd;border-bottom:1px solid #ddd;padding:3px}.path-mod-workshop .userplan
th.active{vertical-align:top;color:black;font-size:140%;border:1px
solid #ddd;border-bottom:0;background:#e7f1c3}.path-mod-workshop .userplan
td{width:20%;vertical-align:top;border-right:1px solid #ddd;background-color:#f5f5f5}.path-mod-workshop .userplan td,
.path-mod-workshop .userplan td a,
.path-mod-workshop .userplan td a:link,
.path-mod-workshop .userplan td a:hover,
.path-mod-workshop .userplan td a:visited,
.path-mod-workshop .userplan td a:active{color:#999}.path-mod-workshop .userplan td.active,
.path-mod-workshop .userplan td.active a,
.path-mod-workshop .userplan td.active a:link,
.path-mod-workshop .userplan td.active a:hover,
.path-mod-workshop .userplan td.active a:visited,
.path-mod-workshop .userplan td.active a:active{color:black}.path-mod-workshop .userplan
td.lastcol{border-right:0}.path-mod-workshop .userplan
td.active{border-left:1px solid #ddd;border-right:1px solid #ddd;background-color:#e7f1c3}.path-mod-workshop .userplan th
.actions{display:inline}.path-mod-workshop .userplan tr.phasetasks
li{background-image:url(/moodle/theme/image.php?theme=clean&component=mod_workshop&rev=1488795260&image=userplan%2Ftask-todo);background-position:top left;background-repeat:no-repeat;list-style-type:none;min-height:16px;margin: .3em 0}.path-mod-workshop .userplan tr.phasetasks
li.completed{background-image:url(/moodle/theme/image.php?theme=clean&component=mod_workshop&rev=1488795260&image=userplan%2Ftask-done)}.path-mod-workshop .userplan tr.phasetasks
li.fail{background-image:url(/moodle/theme/image.php?theme=clean&component=mod_workshop&rev=1488795260&image=userplan%2Ftask-fail)}.path-mod-workshop .userplan tr.phasetasks
li.info{background-image:url(/moodle/theme/image.php?theme=clean&component=mod_workshop&rev=1488795260&image=userplan%2Ftask-info)}.path-mod-workshop .userplan tr.phasetasks
.tasks{list-style:none;margin:3px;padding:0px}.path-mod-workshop .userplan tr.phasetasks
.title{padding:0px
10px 0px 20px}.path-mod-workshop .userplan tr.phasetasks
.details{padding:0px
10px 0px 25px;font-size:80%}.path-mod-workshop .assessment-full{border:1px
solid #ddd;margin:0px
auto 1em auto}.path-mod-workshop .assessment-full
.header{position:relative;background-color:#ddd;padding:3px;min-height:35px}.path-mod-workshop .assessment-full .header
.title{font-weight:bold}.path-mod-workshop .assessment-full .header .title,
.path-mod-workshop .assessment-full .header .reviewer,
.path-mod-workshop .assessment-full .header .grade,
.path-mod-workshop .assessment-full .header
.weight{margin:0px
0px 0px 40px}.path-mod-workshop .assessment-full.anonymous .header .title,
.path-mod-workshop .assessment-full.anonymous .header .reviewer,
.path-mod-workshop .assessment-full.anonymous .header .grade,
.path-mod-workshop .assessment-full.anonymous .header
.weight{margin:0px
0px 0px 5px}.path-mod-workshop .assessment-full .header .reviewer
.picture{position:absolute;top:3px;left:3px}.path-mod-workshop .assessment-full .header
.actions{position:absolute;top:5px;right:5px;text-align:right}.path-mod-workshop .assessment-full .header .actions .singlebutton,
.path-mod-workshop .assessment-full .header .actions .singlebutton form,
.path-mod-workshop .assessment-full .header .actions .singlebutton form
div{display:inline}.path-mod-workshop .assessment-full .assessment-form-wrapper,
.path-mod-workshop .assessment-full .overall-feedback-wrapper{margin-top:0.5em;padding:0px
1em}.path-mod-workshop .assessment-summary.graded .singlebutton input[type="submit"],
.path-mod-workshop .example-summary.graded .singlebutton input[type="submit"]{background-color:#e7f1c3}.path-mod-workshop .assessment-summary.notgraded .singlebutton input[type="submit"],
.path-mod-workshop .example-summary.notgraded .singlebutton input[type="submit"]{background-color:#ffd3d9}.path-mod-workshop .assessment-full .overallfeedback .content,
.path-mod-workshop .assessment-full .overallfeedback
.attachments{padding:5px
10px}.path-mod-workshop .assessment-full .overallfeedback .attachments .files
img.icon{margin-right:5px}.path-mod-workshop .assessment-full .overallfeedback .attachments .images
div{display:inline-block;margin:5px;padding:5px;border:1px
solid #ddd}.path-mod-workshop .assessmentform
.description{margin:0px
1em}.path-mod-workshop .grading-report{width:90%;margin:1em
auto 1em auto;font-size:80%;border:1px
solid #ddd}.path-mod-workshop .grading-report
.userpicture{margin:0px
3px;vertical-align:middle}.path-mod-workshop .grading-report
del{color:red;font-size:90%;text-decoration:line-through}.path-mod-workshop .grading-report
ins{color:green;font-weight:bold;text-decoration:underline}.path-mod-workshop .grading-report
th{white-space:normal}.path-mod-workshop .grading-report
td{vertical-align:top;border:1px
solid #ddd}.path-mod-workshop .grading-report tr.published
td.submission{background-color:#d2ebff}.path-mod-workshop .grading-report tr.published td.submission
a{font-weight:bold}.path-mod-workshop .grading-report
.assessmentdetails{white-space:nowrap}.path-mod-workshop .grading-report .receivedgrade span.grade,
.path-mod-workshop .grading-report .givengrade
span.gradinggrade{font-weight:bold}.path-mod-workshop .grading-report .submissiongrade.cell,
.path-mod-workshop .grading-report
.gradinggrade.cell{text-align:center;font-size:200%;white-space:nowrap}.path-mod-workshop .grading-report .givengrade.null .user,
.path-mod-workshop .grading-report .receivedgrade.null
.user{color:#e00}.path-mod-workshop #workshop-viewlet-yourgrades
.finalgrades{text-align:center}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade{border:1px
solid #ddd;margin:1em;padding:2em;display:inline-block;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade.submissiongrade{background-color:#d2ebff}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade.assessmentgrade{background-color:#eee}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades .grade
.gradevalue{font-weight:bold;font-size:x-large;margin:10px}#mod-workshop-editform fieldset.fgroup
*{vertical-align:top}.path-mod-workshop
.feedback{border:1px
solid #ddd;margin:0px
auto 1em auto;width:80%}.path-mod-workshop .feedback
.header{position:relative;background-color:#ddd;padding:3px;min-height:35px}.path-mod-workshop .feedback .header
.title{margin:0px
0px 0px 40px}.path-mod-workshop .feedback .header
.picture{position:absolute;top:3px;left:3px}.path-mod-workshop .feedback
.content{padding:5px
10px}.path-mod-workshop
div.buttonsbar{text-align:center}.path-mod-workshop div.buttonsbar
.singlebutton{display:inline}.path-mod-workshop
.toolboxaction{margin-right:1em}.path-mod-workshop .toolboxaction,
.path-mod-workshop .toolboxaction .singlebutton,
.path-mod-workshop .toolboxaction .singlebutton form,
.path-mod-workshop .toolboxaction .singlebutton form
div{display:inline}.path-mod-workshop div.buttonwithhelp
div{display:inline}.path-mod-workshop
#evaluationmethodchooser{margin:2em
auto;text-align:center}.path-mod-workshop .workshop-risk-dataloss{vertical-align:text-bottom}.block_blog_tags
.s20{font-size:1.5em;font-weight:bold}.block_blog_tags
.s19{font-size:1.5em}.block_blog_tags
.s18{font-size:1.4em;font-weight:bold}.block_blog_tags
.s17{font-size:1.4em}.block_blog_tags
.s16{font-size:1.3em;font-weight:bold}.block_blog_tags
.s15{font-size:1.3em}.block_blog_tags
.s14{font-size:1.2em;font-weight:bold}.block_blog_tags
.s13{font-size:1.2em}.block_blog_tags .s12,
.block_blog_tags
.s11{font-size:1.1em;font-weight:bold}.block_blog_tags .s10,
.block_blog_tags
.s9{font-size:1.1em}.block_blog_tags .s8,
.block_blog_tags
.s7{font-size:1em;font-weight:bold}.block_blog_tags .s6,
.block_blog_tags
.s5{font-size:1em}.block_blog_tags .s4,
.block_blog_tags
.s3{font-size:0.9em;font-weight:bold}.block_blog_tags .s2,
.block_blog_tags
.s1{font-size:0.9em}#page-blocks-community-communitycourse
.hubscreenshot{float:left}#page-blocks-community-communitycourse
.hubtitlelink{color:#999}#page-blocks-community-communitycourse
.hubsmalllogo{padding-left:3px;padding-right:7px;float:left}#page-blocks-community-communitycourse
.hubtext{display:block;width:68%;padding-left:165px}#page-blocks-community-communitycourse
.hubimgandtext{display:table}#page-blocks-community-communitycourse
.hubimage{float:left;display:block;width:100px}#page-blocks-community-communitycourse
.hubdescriptiontext{}#page-blocks-community-communitycourse
.hubstats{padding-top:10px}#page-blocks-community-communitycourse .hubstats
.iconhelp{float:left;padding-right:3px}#page-blocks-community-communitycourse
.hubadditionaldesc{color:#666;font-size:90%;display:block}#page-blocks-community-communitycourse
.hubscreenshot{margin-right:10px}#page-blocks-community-communitycourse
.hubnottrusted{}#page-blocks-community-communitycourse
.hubtrusted{display:inline}#page-blocks-community-communitycourse
.hubnottrusted{}#page-blocks-community-communitycourse
.trustedtr{background-color:#ffe1c3}#page-blocks-community-communitycourse
.prioritisetr{background-color:#ffd4ff}#page-blocks-community-communitycourse
.blockdescription{font-size:80%;color:#555}#page-blocks-community-communitycourse
.trusted{font-size:90%;color:#063;font-weight:normal;font-style:italic}#page-blocks-community-communitycourse
.additionaldesc{font-size:80%;color:#8B8989}#page-blocks-community-communitycourse .comment-link{font-size:80%;color:#555}#page-blocks-community-communitycourse
.coursescreenshot{text-align:center;cursor:pointer}#page-blocks-community-communitycourse
.hubcourseinfo{margin-left:15px}#page-blocks-community-communitycourse
.coursesitelink{}#page-blocks-community-communitycourse
.pagingbar{text-align:center}#page-blocks-community-communitycourse
.coursecomment{float:right}#page-blocks-community-communitycourse
.courseoperations{margin-top:9px;text-align:center}#page-blocks-community-communitycourse .hubcoursedownload:hover{background-color:#CDC9C9}#page-blocks-community-communitycourse
.courselinks{float:right;width:180px}#page-blocks-community-communitycourse
.ratingaggregate{float:left;padding-right:4px}#page-blocks-community-communitycourse
.hubcourserating{padding-top:3px;font-size:80%;color:#555}#page-blocks-community-communitycourse
.coursedescription{width:70%;float:left}#page-blocks-community-communitycourse
.fullhubcourse{margin-bottom:20px}#page-blocks-community-communitycourse
.hubcoursetitlepanel{margin-bottom:6px}#page-blocks-community-communitycourse
.hubcourseresult{background:none repeat scroll 0 0 #FFF;clear:both;margin:30px
auto 0;z-index:90;width:95%;padding:10px
10px 10px 10px;border-style:solid;border-width:1px}#page-blocks-community-communitycourse
.hubcoursetitle{-webkit-box-shadow:rgba(0, 0, 0, 0.546875) 0px 0px 4px;-moz-box-shadow:rgba(0, 0, 0, 0.546875) 0px 0px 4px;background:#8B8989;left:-15px;position:relative;z-index:0;border:0px;margin:0px;outline:0px;padding:0px;vertical-align:baseline;color:#fff;padding-top:6px;padding-bottom:6px;text-shadow:1px 1px 2px rgba(0,0,0,0.2);text-align:left;font-style:italic;font-weight:normal;line-height:1.2em;font-size:140%;color:#fff;width:102%;text-indent:15px}#page-blocks-community-communitycourse
.hubcoursedownload{display:inline-block;padding:5px
8px 6px;color:black;text-decoration:none;-moz-border-radius:6px;-webkit-border-radius:6px;-moz-box-shadow:0 1px 3px rgba(0,0,0,0.6);-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.6);border-bottom:1px solid rgba(0,0,0,0.25);position:relative;cursor:pointer;background-color:#EEE9E9;margin-left:6px;font-size:95%;margin-bottom:9px}#page-blocks-community-communitycourse .comment-list
li{background-color:#FFFAFA !important;-moz-border-radius:6px;-webkit-border-radius:6px;padding-right:4px;padding-bottom:2px}#page-blocks-community-communitycourse
.ratingcount{color:#8B8989;font-size:80%;vertical-align:top}#page-blocks-community-communitycourse
.norating{font-weight:bold;color:#8B8989;font-size:80%}#page-blocks-community-communitycourse .star-rating{list-style:none;margin:4px
0 4px;padding:0px;width:100px;height:20px;position:relative;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=i%2Fstar-rating) top left repeat-x;float:left}#page-blocks-community-communitycourse .star-rating
li{padding:0px;margin:0px;height:20px;width:20px;float:left}#page-blocks-community-communitycourse .star-rating li.current-rating{background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=i%2Fstar-rating) left bottom;position:absolute;height:20px;display:block;text-indent:-9000px;z-index:1}#page-blocks-community-communitycourse
.nocomments{font-weight:bold;color:#8B8989;font-size:80%}#page-blocks-community-communitycourse
.hubcommentator{float:left;font-weight:bold}#page-blocks-community-communitycourse
.hubcommentdate{font-weight:bold}#page-blocks-community-communitycourse
.hubcommenttext{margin-bottom:10px}#page-blocks-community-communitycourse
.hubnoscriptcoursecomments{margin-left:5px}#page-blocks-community-communitycourse .yui3-overlay-loading{top:-1000em;left:-1000em;position:absolute;z-index:1000}#page-blocks-community-communitycourse
.hubcoursecomments{display:inline-block;padding:3px
3px 3px 3px;color:white;text-decoration:none;-moz-border-radius:6px;-webkit-border-radius:6px;position:relative;cursor:pointer;background-color:#8B8989;margin-left:0px;font-size:80%;margin-top:15px}#page-blocks-community-communitycourse
.hubrateandcomment{font-size:80%}#page-blocks-community-communitycourse
.hubcourseoutcomes{}#page-blocks-community-communitycourse
.nextlink{text-align:center;margin-top:6px}#page-blocks-community-communitycourse
.textinfo{text-align:center}#ss-mask{z-index:10;position:fixed;top:0;left:0;bottom:0;right:0;opacity:0.35;filter:alpha(opacity=35);background:#000}.hiddenoverlay{display:none;text-align:center}.imagearrow{font-size:120%;display:inline;cursor:pointer}.imagetitle{display:inline;cursor:pointer}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue{-moz-border-radius:12px 12px 12px 12px;-moz-box-shadow:0 1px 3px rgba(0, 0, 0, 0.6);-webkit-border-radius:12px 12px 12px 12px;-webkit-box-shadow:0 1px 3px rgba(0, 0, 0, 0.6);border-width:0 0 0 0}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-wrap{-moz-border-radius:12px 12px 0px 0px;-webkit-border-radius:12px 12px 0px 0px;background-color:#FFF;border:1px
solid #555}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-hd{-moz-border-radius:12px 12px 0 0;-webkit-border-radius:12px 12px 0 0;background-color:#F6F6F6;border:1px
solid #CCC;overflow:auto;padding:7px
6px}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-bd{padding:0px;margin-bottom:-5px}#page-blocks-community-communitycourse .moodle-dialogue-base
.closebutton{margin-top:4px;margin-right:4px}.block_course_list
.footer{margin-top:5px}.block_course_list .content
li{margin-bottom: .3em}.block_course_overview
.coursechildren{font-weight:normal;font-style:italic}.block_course_overview
.content{margin:0
20px}.block_course_overview .content
.notice{margin:5px
0}.block_course_overview
.coursebox{padding:15px;width:auto}.block_course_overview
.profilepicture{float:left}.dir-rtl.block_course_overview
.profilepicture{float:right}.block_course_overview
.welcome_area{width:100%;padding-bottom:5px}.block_course_overview
.welcome_message{float:left;padding:10px;vertical-align:middle;border-collapse:separate;clear:none}.dir-rtl .block_course_overview
.welcome_message{float:right}.block_course_overview .content
h2.title{float:left;margin:0
0 .5em 0;position:relative}.dir-rtl .block_course_overview .content
h2.title{float:right}.block_course_overview
.course_title{position:relative}.editing .block_course_overview .coursebox
.cursor{cursor:move;margin-bottom:2px}.editing .block_course_overview
.move{float:left;padding:2px
10px 0 0}.dir-rtl.editing .block_course_overview
.move{float:right;padding:2px
10px}.block_course_overview
.course_list{width:100%}.block_course_overview
div.flush{clear:both}.block_course_overview
.activity_info{clear:both}.dir-rtl .block_course_overview
.activity_info{margin-right:25px}.block_course_overview
.activity_overview{padding:2px}.block_course_overview .activity_overview
img.iconlarge{vertical-align:text-bottom;margin-right:6px}.dir-rtl .block_course_overview .activity_overview
img.iconlarge{margin-left:6px;margin-right:0}.block_course_overview
.singleselect{text-align:left;margin:0}.dir-rtl .block_course_overview
.singleselect{text-align:right}.block_course_overview .content .course_list
.movehere{margin-bottom:15px}.block_course_summary
.content{padding:10px}.block_course_summary
.editbutton{text-align:right}.block_messages
.content{text-align:left;padding-top:5px}.block_messages .content .list
li.listentry{clear:both}.block_messages .content .list li.listentry
.user{float:left;position:relative}.block_messages .content .list li.listentry
.message{float:right}.block_messages .content
.info{text-align:center}.block_messages .content
.footer{clear:both}.dir-rtl .block_messages .content .list li.listentry
.user{float:right}.dir-rtl .block_messages .content .list li.listentry
.message{float:left}.block_myprofile
img.profilepicture{height:100px;width:100px}.block_myprofile
.myprofileitem.fullname{font-size:1.5em;font-weight:bold}.block_myprofile
.myprofileitem.edit{text-align:right}.block_navigation
.block_tree{margin:5px;padding-left:0px;overflow:visible}.block_navigation .block_tree
li{margin:3px;list-style:none;padding:0}.block_navigation .block_tree li.item_with_icon>p{position:relative;padding-left:21px}.block_navigation .block_tree li.item_with_icon > p img,
.block_navigation .block_tree .type_activity > p.tree_item.active_tree_node img,
.block_navigation .block_tree li > p.hasicon
img{vertical-align:middle;position:absolute;left:0;top:-1px;width:16px;height:16px}.block_navigation .block_tree li.item_with_icon.contains_branch > p
img{left:16px}.block_navigation .block_tree .type_activity > p.branch.hasicon,
.block_navigation .block_tree .type_activity > p.emptybranch.hasicon,
.block_navigation .block_tree li.item_with_icon.contains_branch>.tree_item{padding-left:37px}.block_navigation .block_tree li
ul{padding-left:0;margin:0}.block_navigation .block_tree li.depth_2
ul{padding-left:16px;margin:0}.block_navigation .block_tree .type_activity > p.tree_item.branch.hasicon.active_tree_node,
.block_navigation .block_tree
.tree_item{padding-left:21px;margin:3px
0px;text-align:left}.block_navigation .block_tree
.tree_item.branch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fexpanded);background-position:0 0;background-repeat:no-repeat}.block_navigation .block_tree
.tree_item.branch.navigation_node{background-image:none;padding-left:0}.block_navigation .block_tree .type_activity > .tree_item.emptybranch,
.block_navigation .block_tree .type_activity>.tree_item.branch{background-image:none;position:relative}.block_navigation .block_tree .type_activity > .tree_item.hasicon.emptybranch img,
.block_navigation .block_tree .type_activity > .tree_item.branch
img{left:16px}.block_navigation .block_tree
.root_node.leaf{padding-left:0px}.block_navigation .block_tree
.active_tree_node{font-weight:bold}.block_navigation .block_tree .depth_1.current_branch
ul{font-weight:normal}.dock .block_navigation
.tree_item{white-space:nowrap}.jsenabled .block_navigation .block_tree
.tree_item.branch{cursor:pointer}.jsenabled .block_navigation .block_tree
.tree_item.emptybranch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_empty);background-position:0 0;background-repeat:no-repeat}.jsenabled .block_navigation .block_tree .collapsed
ul{display:none}.jsenabled .block_navigation .block_tree .type_activity>.tree_item.branch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fexpanded)}.jsenabled .block_navigation .block_tree .collapsed
.tree_item.branch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed)}.jsenabled .block_navigation .block_tree
.tree_item.branch.loadingbranch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=i%2Floading_small)}.jsenabled .block_navigation.dock_on_load,
.block_navigation .block_tree_box
.requiresjs{display:none}.jsenabled .block_navigation .block_tree_box
.requiresjs{display:inline}.ie6 .block_navigation .block_tree
.tree_item{width:100%}.dir-rtl .block_navigation .block_tree li.depth_2
ul{padding-left:0;padding-right:16px;padding-left:0}.dir-rtl .block_navigation .block_tree .type_activity > p.tree_item.branch.hasicon.active_tree_node,
.dir-rtl .block_navigation .block_tree
.tree_item{padding-right:21px;text-align:right}.dir-rtl .block_navigation .block_tree
.tree_item.branch{background-position:center right}.dir-rtl .block_navigation .block_tree,
.dir-rtl .block_navigation .block_tree li ul,
.dir-rtl .block_navigation .block_tree .navigation_node.tree_item.branch,
.dir-rtl .block_navigation .block_tree
.root_node.leaf{padding-right:0}.dir-rtl .block_navigation .block_tree li.item_with_icon > p img,
.dir-rtl .block_navigation .block_tree .type_activity > p.tree_item.active_tree_node img,
.dir-rtl .block_navigation .block_tree li > p.hasicon
img{left:auto;right:0}.dir-rtl .block_navigation .block_tree li.item_with_icon.contains_branch > p
img{left:auto;right:16px}.dir-rtl .block_navigation .block_tree .type_activity > p.branch.hasicon,
.dir-rtl .block_navigation .block_tree li.item_with_icon.contains_branch>.tree_item{padding-right:37px;padding-left:0}.dir-rtl .block_navigation .block_tree .type_activity > .tree_item.branch
img{right:16px;left:auto}.jsenabled.dir-rtl .block_navigation .block_tree
.tree_item.emptybranch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_empty_rtl);background-position:center right}.jsenabled.dir-rtl .block_navigation .block_tree .collapsed
.tree_item.branch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_rtl)}.block_online_users .content .list
li.listentry{clear:both}.block_online_users .content .list li.listentry
.user{float:left;position:relative}.block_online_users .content .list li.listentry .user
.userpicture{vertical-align:text-bottom}.block_online_users .content .list li.listentry
.message{float:right;margin-top:3px}.block_online_users .content
.info{text-align:center}.dir-rtl .block_online_users .content .list li.listentry
.user{float:right}.dir-rtl .block_online_users .content .list li.listentry
.message{float:left}.block_private_files .content
table{table-layout:fixed;width:100%}.block_quiz_results{text-align:center}.block_quiz_results
h1{margin:4px;font-size:1.1em}.block_quiz_results
table.grades{text-align:left;width:100%}.block_quiz_results table.grades .number,
.block_quiz_results table.grades
.grade{text-align:right;width:10%}.block_quiz_results table.grades
caption{margin:1em
0px 0px 0px;border-bottom-width:1px;border-bottom-style:solid;font-weight:bold}.block_recent_activity .activitydate,
.block_recent_activity
.activityhead{text-align:center}.block_recent_activity .unlist
li{margin-bottom:1em}.block_recent_activity li .head
.date{float:right}.dir-rtl .block_recent_activity .content
h3{text-align:right}.block_rss_client .list li:first-child{border-top-width:0}.block_rss_client .list
li{border-top:1px solid;padding:5px}.block_search_forums
.searchform{text-align:center}.block_search_forums .searchform
img{vertical-align:middle}.block_search_forums .searchform
img.resize{width:1em;height:1.1em}.block_search_forums
.invisiblefieldset{display:block}.jsenabled .block_settings.dock_on_load,
.block_settings .block_tree_box
.requiresjs{display:none}.jsenabled .block_settings .block_tree_box
.requiresjs{display:inline}.block_settings
.block_tree{margin:5px;padding-left:0px;overflow:visible}.block_settings .block_tree
li{margin:0;list-style:none}.block_settings .block_tree li
ul{padding-left:18px;margin:0}.block_settings .block_tree li.item_with_icon>p{position:relative}.block_settings .block_tree li.item_with_icon > p
img{vertical-align:middle;position:absolute;left:0;top:-1px;width:16px;height:16px}.block_settings .block_tree
.tree_item{padding-left:21px;margin:3px
0px;text-align:left}.block_settings .block_tree
.tree_item.branch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fexpanded);background-position:0 10%;background-repeat:no-repeat}.block_settings .block_tree
.root_node.leaf{padding-left:0px}.block_settings .block_tree
.active_tree_node{font-weight:bold}.jsenabled .block_settings .block_tree
.tree_item.branch{cursor:pointer}.jsenabled .block_settings .block_tree
.tree_item.emptybranch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_empty);background-position:0 10%;background-repeat:no-repeat}.jsenabled .block_settings .block_tree .collapsed
ul{display:none}.jsenabled .block_settings .block_tree .collapsed
.tree_item.branch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed)}.ie6 .block_settings .block_tree
.tree_item{width:100%}.dir-rtl .block_settings
.block_tree{padding-right:0px}.dir-rtl .block_settings .block_tree li
ul{padding-left:0;padding-right:18px}.dir-rtl .block_settings .block_tree
.tree_item{padding-right:21px;padding-left:0;text-align:right}.dir-rtl .block_settings .block_tree
.tree_item.branch{background-position:center right}.dir-rtl .block_settings .block_tree
.root_node.leaf{padding-right:0px}.dir-rtl .block_settings .block_tree li.item_with_icon > p
img{right:0;left:auto}.jsenabled .block_settings .block_tree
.tree_item.branch.loadingbranch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=i%2Floading_small)}.jsenabled.dir-rtl .block_settings .block_tree
.tree_item.emptybranch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_empty_rtl);background-position:center right}.jsenabled.dir-rtl .block_settings .block_tree .collapsed
.tree_item.branch{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_rtl)}.block_simple_clock
.clockTable{width:100%;padding:0;margin:0}.block_simple_clock .clockTable
td{padding:2px;margin:0;vertical-align:top}.block_simple_clock
.clock{width:98%;border:0;text-align:right}.block_site_main_menu
li{clear:both}.block_site_main_menu li
.column{width:100%}.block_site_main_menu li
.buttons{float:right;margin:0}.dir-rtl .block_site_main_menu li
.buttons{float:left}.block_site_main_menu li .buttons a
img{vertical-align:text-bottom}.block_site_main_menu
.footer{margin-top:1em}.block_site_main_menu .section_add_menus noscript
div{display:inline}.block_social_activities
li{clear:both}.block_social_activities li
.column{width:100%}.block_social_activities li
.buttons{float:right;margin:0}.dir-rtl .block_social_activities li
.buttons{float:left}.block_social_activities li .buttons a
img{vertical-align:text-bottom}.block_tag_flickr .flickr-photos{padding:3px}.block_tag_youtube .youtube-thumb{padding:3px;padding-bottom:0.5em;display:block;float:left}.block_tag_youtube .yt-video-entry
li{clear:left}.block_tags{}.block_tags
#coursetag{}.block_tags #coursetag
.coursetag_form_wrapper{}.block_tags #coursetag .coursetag_form_wrapper
.coursetag_form_positioner{position:relative}.block_tags #coursetag .coursetag_form_wrapper .coursetag_form_positioner
.coursetag_form_input1{position:relative;top:0;left:0;z-index:1;width:100%}.block_tags #coursetag .coursetag_form_wrapper .coursetag_form_positioner
.coursetag_form_input2{position:absolute;top:0;left:0;z-index:2;width:100%}.block_tags #coursetag .coursetag_form_wrapper .coursetag_form_positioner
.coursetag_form_input3{position:absolute;top:3px;left:12.8em;display:none}.block_tags #coursetag .coursetag_form_wrapper .coursetag_form_positioner
.coursetag_form_input1a{background-color:white;border:1px
solid #999;width:12em;padding:2px}.block_tags #coursetag .coursetag_form_wrapper .coursetag_form_positioner
.coursetag_form_input2a{background-color:transparent;border:1px
solid #999;width:12em;color:#669954;padding:2px}.block_tags
.coursetag_morelink{}.block_tags
.coursetag_list{}#glossaryfilteroverlayprogress{position:fixed;top:50%;width:100%;text-align:center}.jsenabled
#MathJax_ZoomFrame{position:absolute}.mediaplugin_html5audio,.mediaplugin_html5video,.mediaplugin_swf,.mediaplugin_flv,.mediaplugin_real,.mediaplugin_youtube,.mediaplugin_vimeo,.mediaplugin_wmp,.mediaplugin_qt{display:block;margin-top:5px;margin-bottom:5px;text-align:center}.mediaplugin.mediaplugin_mp3
object{display:inline;height:15px;width:180px;margin-left:0.5em}.mp3flowplayer_backgroundColor{color:#000}.editor_atto_content_wrap{background-color:white;color:#333}.editor_atto_content{padding:4px;resize:vertical;overflow:auto}.editor_atto_content_wrap,.editor_atto+textarea{width:100%;padding:0;border:1px
solid #BBB;border-top:none}.editor_atto+textarea{border-radius:0;resize:vertical;margin-top:-1px}div.editor_atto_toolbar{display:block;background:#F2F2F2;min-height:35px;border:1px
solid #BBB;width:100%;padding:0
0 9px 0}div.editor_atto_toolbar
button{padding:4px
9px;background:none;border:0;margin:0;border-radius:0;cursor:pointer;line-height:initial}div.editor_atto_toolbar button+button{border-left:1px solid #CCC}div.editor_atto_toolbar button[disabled]{opacity: .45;background:none;cursor:default}.editor_atto_toolbar button:hover{background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%);background-color:#ebebeb}.editor_atto_toolbar button:active, .editor_atto_toolbar
button.highlight{background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%);background-color:#dfdfdf}div.editor_atto_toolbar button::-moz-focus-inner{border:0;padding:0}div.editor_atto_toolbar button
img.icon{padding:0px;margin:2px
0;vertical-align:text-bottom;width:auto;height:auto}div.editor_atto_toolbar
div.atto_group{display:inline-block;border:1px
solid #CCC;border-bottom:1px solid #B3B3B3;border-radius:4px;margin:9px
0 0 9px;background:#FFF}.editor_atto_content
img{resize:both;overflow:auto}.atto_hasmenu{white-space:nowrap}.atto_menuentry
img{width:16px;height:16px}.atto_menuentry{clear:left}.atto_menuentry h1,
.atto_menuentry h2,
.atto_menuentry
p{margin:4px}.atto_form
label.sameline{display:inline-block;min-width:10em}.atto_form textarea.fullwidth,
.atto_form
input.fullwidth{width:100%}.atto_form{padding-left:30px;padding-right:30px}.atto_form
label{display:block;margin:0
0 5px 0}body.dir-rtl div.editor_atto_toolbar button+button{border-left:0;border-right:1px solid #CCC}body.dir-rtl div.editor_atto_toolbar
img.icon{padding:0}body.dir-rtl div.editor_atto_toolbar
div.atto_group{margin:9px
9px 0 0}.atto_control{position:absolute;right:-6px;bottom:-6px;display:none;cursor:pointer}.atto_control
img{background-color:white}div.editor_atto_content:focus .atto_control,
div.editor_atto_content:hover
.atto_control{display:block}.editor_atto_menu.yui3-menu-hidden{display:none}.editor_atto_content img:-moz-broken{-moz-force-broken-image-icon:1;min-width:24px;min-height:24px}.moodle-dialogue-base .editor_atto_menu .moodle-dialogue-content .moodle-dialogue-bd{padding:0;z-index:1000}.editor_atto_menu .dropdown-menu>li>a{padding:3px
14px}.editor_atto_menu .open ul.dropdown-menu{padding-top:5px;padding-bottom:5px}@media (max-width: 480px){.mceToolbar
td{float:left;display:inline-block}.moodleSkin .mceLayout .mceToolbar
.mceWrap{clear:left;width:100%;height:4px}.moodleSkin .mceLayout .mceToolbar
.mceNoWrap{clear:none;width:0px}.o2k7Skin tr.mceLast .mceToolbar tr td.mceWrap,
.o2k7Skin tr.mceFirst .mceToolbar tr
td.mceWrap{margin-left:-3px}.dir-rtl .o2k7Skin tr.mceLast .mceToolbar tr td.mceWrap,
.dir-rtl .o2k7Skin tr.mceFirst .mceToolbar tr
td.mceWrap{margin-left:0px}}.format-singleactivity .tree_item.orphaned
a{color:red}.course-content
ul.topics{margin:0}.course-content ul.topics
li.section{list-style:none;margin:0
0 5px 0;padding:0}.course-content ul.topics li.section
.content{margin:0
40px}.course-content ul.topics li.section
.left{float:left}.course-content ul.topics li.section
.right{float:right}.course-content ul.topics li.section .left,
.course-content ul.topics li.section
.right{width:40px;text-align:center;padding:6px
0}.course-content ul.topics li.section .right
img.icon{padding:0
0 4px 0}.course-content ul.topics li.section .left .section-handle
img.icon{padding:0;vertical-align:baseline}.course-content
ul.weeks{margin:0}.course-content ul.weeks
li.section{list-style:none;margin:0
0 5px 0;padding:0}.course-content ul.weeks li.section
.content{margin:0
40px}.course-content ul.weeks li.section
.left{float:left}.course-content ul.weeks li.section
.right{float:right}.course-content ul.weeks li.section .left,
.course-content ul.weeks li.section
.right{width:40px;text-align:center;padding:6px
0}.course-content ul.weeks li.section .right
img.icon{padding:0
0 4px 0}.course-content ul.weeks li.section .left .section-handle
img.icon{padding:0;vertical-align:baseline}#page-report-completion-index table#completion-progress{margin-top:20px;margin-bottom:30px}#page-report-completion-index .export-actions{text-align:center}#page-report-completion-index.dir-rtl #completion-progress th
svg{direction:ltr}.report-eventlist-name{color:#888;font-size:0.75em}.report-eventlist-datatable-table>div>table{width:100%}#page-admin-report-eventlist-index
dt{float:left;text-align:right;width:20em}#page-admin-report-eventlist-index
dd{display:block;text-align:left;margin-left:21em}#page-admin-report-eventlist-index dd+dd{clear:left}@media (max-width : 767px){#page-admin-report-eventlist-index
dt{width:100%;text-align:left}#page-admin-report-eventlist-index
dd{margin-left:0}#page-admin-report-eventlist-index dd+dd{margin-left:0}}#page-admin-report-eventlist-index.dir-rtl
dt{float:right;text-align:left;width:20em}#page-admin-report-eventlist-index.dir-rtl
dd{display:block;text-align:right;margin-right:22em}#page-admin-report-eventlist-index.dir-rtl dd+dd{clear:right}@media (max-width : 767px){#page-admin-report-eventlist-index.dir-rtl
dt{width:100%;text-align:right}#page-admin-report-eventlist-index.dir-rtl
dd{margin-right:0em}#page-admin-report-eventlist-index.dir-rtl dd+dd{margin-right:0em}}#page-report-log-index
.info{margin:10px}#page-report-log-index
.logselectform{margin:10px
auto}#page-report-log-user
.info{margin:10px;text-align:center}#page-report-log-user
.graph{text-align:center}#page-report-loglive-index
.info{margin:10px}table.flexible>tbody>tr:nth-child(n).newrow>td{background:#D4D4D4}#page-report-outline-index
td.numviews{text-align:right}#page-report-outline-index
tr.section{text-align:center}#page-report-outline-index
td.lastaccess{font-size:0.8em}#page-report-outline-user .section
.content{margin-left:30px;margin-right:30px}#page-report-outline-user .section
h2{margin-top:0}#page-report-outline-user
.section{margin-left:30px;margin-right:30px;margin-bottom:20px}#page-report-outline-user
.section{border-width:1px;border-style:solid;padding:10px}#page-report-participation-index
.participationselectform{margin:10px
auto}#page-report-participation-index .participationselectform
label{margin-left:15px;margin-right:5px}#page-report-progress-index #completion-progress th,
#page-report-progress-index #completion-progress
td{padding:2px
4px;font-weight:normal;border-right:1px solid #EEE}#page-report-progress-index .progress-actions{text-align:center}#page-report-progress-index
.completion_pagingbar{margin:1em
0;text-align:center}#page-report-progress-index
.completion_prev{display:inline;margin-right:2em}#page-report-progress-index .completion_pagingbar
p{display:inline;margin:0}#page-report-progress-index
.completion_next{display:inline;margin-left:2em}#page-report-progress-index.dir-rtl #completion-progress th
svg{direction:ltr}#page-report-stats-index
.graph{margin-bottom:1em}.path-grade-report-grader .flexible
th{white-space:normal}.gradestable{margin-bottom:0}.gradestable th.user
img{width:20px;height:20px}.gradestable th
img{vertical-align:text-bottom;padding-bottom:0}.gradestable th
.grade_icons{margin-top: .3em}.gradestable th
img.sorticon{margin-left: .3em}.dir-rtl .gradestable th
img.sorticon{margin-left:0;margin-right: .3em}table#user-grades
.catlevel2{background-color:#f9f9f9}table#user-grades tr.range
td.cell{font-weight:700}table#user-grades tr.avg
td.cell{background-color:#efefff;font-weight:700;color:#00008B}table#user-grades tr.odd
td.cell{background-color:#efefef;white-space:nowrap}table#user-grades tr
td.overridden{background-color:#F3E4C0}table#user-grades tr.odd
td.overridden{background-color:#EFD9A4}table#user-grades tr
td.ajaxoverridden{background-color:#FFE3A0}table#user-grades tr.odd
td.ajaxoverridden{background-color:#FFDA83}table#user-grades tr.even
td.excluded{background-color:#EABFFF}table#user-grades tr.odd
td.excluded{background-color:#E5AFFF}table#user-grades tr.odd
th.header{background-color:#efefef;background-image:none}table#user-grades tr.even
th.header{background-image:none}table#user-grades tr.groupavg
td.cell{background-color:#efffef;font-weight:700;color:#006400}table#user-grades td.cat,
table#user-grades
td.course{font-weight:700}table#user-grades{font-size:10px;width:auto;background-color:transparent;border-style:solid;border-width:1px;margin:20px
0 0}.path-grade-report-grader #overDiv
table{margin:0}.path-grade-report-grader #overDiv table
td.feedback{border:0}.path-grade-report-grader #overDiv
.feedback{font-size:70%;background-color:#ABF;color:#000;font-family:Verdana;font-weight:400}.path-grade-report-grader #overDiv
.caption{font-size:70%;background-color:#56C;color:#CCF;font-family:Arial;font-weight:700}.path-grade-report-grader #overDiv
.intersection{font-size:70%;background-color:#ABF;color:#000;font-family:Verdana;font-weight:400}.path-grade-report-grader #overDiv
.intersectioncaption{background-color:#56C;color:#CCF;font-family:Arial;font-weight:700}.path-grade-report-grader
div.submit{margin-top:20px;text-align:center}table#user-grades
td{text-align:right;border-style:solid;border-width:0 1px 1px 0}table#user-grades
th.category{vertical-align:top;border-style:solid;border-width:1px 1px 0}table#user-grades
th.user{text-align:left;border-style:solid;border-width:1px 0}table#user-grades
th.userfield{border-style:solid;border-width:1px}table#user-grades th.categoryitem,
table#user-grades
td.topleft{vertical-align:bottom;border-style:solid;border-width:0 1px}.path-grade-report-grader td,.path-grade-report-grader
th{border-color:#CECECE}.path-grade-report-grader table#participants
th{vertical-align:top;width:auto}table#user-grades
td.fillerfirst{border-style:solid;border-width:0 0 0 1px}table#user-grades
td.fillerlast{border-style:solid;border-width:0 1px 0 0}table#user-grades th.item,
table#user-grades th.categoryitem,
table#user-grades
th.courseitem{border-bottom-color:#000;vertical-align:bottom;border-style:solid;border-width:1px}div.gradertoggle{display:inline;margin-left:20px}table#user-grades
th.range{text-align:right;border-style:solid;border-width:1px}table#user-grades
.userpic{display:inline;margin-right:10px}table#user-grades
.quickfeedback{border:1px
dashed #000;width:auto;margin:0;padding:0;margin-left:10px}.dir-rtl table#user-grades
.quickfeedback{margin-left:0;margin-right:10px}.path-grade-report-grader
#siteconfiglink{text-align:right}table#user-grades
.datesubmitted{font-size: .7em}table#user-grades
td.cell{padding-left:5px;padding-right:5px;vertical-align:middle}.path-grade-report-grader
table{border-collapse:collapse;background-color:#fff;border-color:#cecece}.path-grade-report-grader
th{padding:1px
10px}.path-grade-report-grader span.inclusion-links{margin:0
5px 0 10px}table#user-grades
.item{background-color:#e9e9e9}.path-grade-report-grader table tr.odd
th.header{background-color:#efefef;background-image:none;border-width:0 0 1px}.path-grade-report-grader table tr.heading
th.header{border-top:1px solid #cecece}table#user-grades tr.heading th.categoryitem,
table#user-grades tr.heading
th.courseitem{border-width:0 0 0 1px}table#user-grades
th.category.header.catlevel1{vertical-align:top;border-style:solid;border-width:1px 1px 0 0}.path-grade-report-grader div.left_scroller th.user
a{vertical-align:middle;margin:0;padding:0}table#user-grades th.categoryitem,
table#user-grades th.courseitem,
.path-grade-report-grader table
td.topleft{vertical-align:bottom;border-color:#cecece #cecece #000;border-style:solid;border-width:0 1px 1px}.path-grade-report-grader .left_scroller table
td.topleft{background-color:#fff;border-bottom-color:#cecece}table#user-grades
td.topleft{background-color:#fff}.path-grade-report-grader th.user
img.userpicture{border:3px
double #cecece;vertical-align:top;width:2.7em;height:2.7em;margin-right:10px}.path-grade-report-grader
a.quickedit{line-height:1em;display:block;float:right;clear:none;font-size:9px;background-color:transparent;margin: .1em 0 0}.path-grade-report-grader
a.quickedit2{display:block;float:right;clear:none;background-color:transparent;margin:1.3em 0 0}.path-grade-report-grader
table#quick_edit{border:1px
solid #cecece;margin:0
auto}.path-grade-report-grader table#quick_edit
td{vertical-align:middle;border:1px
solid #cecece;text-align:left;margin:0;padding:5px}.path-grade-report-grader table#quick_edit td
img{border:3px
double #cecece;vertical-align:middle;padding:0}.path-grade-report-grader td
input.text{border:1px
solid #666;width:auto;margin:0;padding:0}.path-grade-report-grader td
input.submit{margin:10px
10px 0px 10px}.path-grade-report-grader table#quick_edit
td.fullname{border-left:0;padding-left:5px}.path-grade-report-grader table#quick_edit
td.picture{border-right:0}.path-grade-report-grader table#quick_edit td.finalgrade
input{width:5em}.path-grade-report-grader
h1{text-align:center;clear:both}.path-grade-report-grader
input.center{margin:10px
auto 0}.path-grade-report-grader
.lefttbody{width:auto;vertical-align:middle}table#user-grades
th.fixedcolumn{border:1px
solid #cecece;vertical-align:middle}.path-grade-report-grader table#fixed_column
th{border:1px
solid #cecece;vertical-align:middle;border-right-color:#000}.path-grade-report-grader table#fixed_column
th.user{border-right-color:#cecece}.path-grade-report-grader
table#fixed_column{padding-top:20px;border-top:1px solid #cecece;background-color:#fff}.path-grade-report-grader
.left_scroller{float:left;clear:none;padding-top:20px}.path-grade-report-grader.dir-rtl
.left_scroller{float:right}.path-grade-report-grader
.right_scroller{width:auto;clear:none;overflow-x:scroll}.path-grade-report-grader table tr.avg,
.path-grade-report-grader table tr.groupavg td,
.path-grade-report-grader table tr.avg td,
.path-grade-report-grader table tr.groupavg th,
.path-grade-report-grader table tr.avg th,
.path-grade-report-grader table tr.controls_row,
.path-grade-report-grader table tr.controls_row th,
.path-grade-report-grader table tr.range_row,
.path-grade-report-grader table tr.range_row th,
div.right_scroller
tr{height:2em}table#user-grades tr.groupavg td.cell,
tr.groupavg
th.header{background-color:#efffef}.path-grade-report-grader form
td.excluded{color:red}.path-grade-report-grader
.excludedfloater{font-weight:700;color:red;font-size:9px;float:left}.path-grade-report-grader
span.gradepass{color:#298721}.path-grade-report-grader
span.gradefail{color:#890d0d}.path-grade-report-grader
.gradeweight{color:#461d7c;font-weight:700}.path-grade-report-grader td
select{font-size:100%;padding:0}.path-grade-report-grader .right_scroller td
select{font-size:86%;padding:0}.path-grade-report-grader tr.avg,
.path-grade-report-grader tr.controls,
.path-grade-report-grader td.controls,
.path-grade-report-grader th.controls,
.path-grade-report-grader tr.groupavg,
.path-grade-report-grader tr.range,
.path-grade-report-grader th.range,
.path-grade-report-grader td.range,
.path-grade-report-grader tr.heading
th.range{height:2em!important;white-space:nowrap}.path-grade-report-grader .heading_name_row
th{white-space:nowrap;width:2000px}.path-grade-report-grader heading_name_row th
span{white-space:nowrap}.path-grade-report-grader .grade_icons
img.ajax{float:right}.path-grade-report-grader .gradestable th.user,
.path-grade-report-grader .gradestable th.range,
.path-grade-report-grader .flexible th,
.path-grade-report-grader .flexible td,
.path-grade-report-grader .flexible th a,
.path-grade-report-grader .flexible td a,
.path-grade-report-grader .gradestable th.range,
.path-grade-report-grader
td{white-space:nowrap}table#user-grades .catlevel1,
table#user-grades .r1,
.path-grade-report-grader table tr.even td.cell,
.path-grade-report-grader table tr.even
th{background-color:#fff}table#user-grades .catlevel3,
.path-grade-report-grader table tr.odd
td.cell{background-color:#efefef}table#fixed_column tr.odd th ,
table#user-grades tr.odd
th{background-color:#efefef}table#user-grades td.vmarked,
table#user-grades tr.odd td.vmarked,
table#user-grades tr.avg td.vmarked,
table#user-grades tr.controls td.vmarked,
table#user-grades .catlevel1.vmarked,
table#user-grades .catlevel2.vmarked,
table#user-grades .catlevel3.vmarked,
table#user-grades tr.range td.vmarked,
table#user-grades tr.groupavg
td.vmarked{background-color:#fc3}table#user-grades td.hmarked,
table#user-grades tr.odd td.hmarked,
table#user-grades tr.even td.hmarked,
table#user-grades tr.odd th.hmarked,
table#user-grades tr.even
th.hmarked{background-color:#ff9}table#user-grades td.hmarked.vmarked,
table#user-grades tr.odd td.hmarked.vmarked,
table#user-grades tr.even
td.hmarked.vmarked{background-color:#fc9}table#user-grades tr.heading,
table#user-grades .heading
td{border-style:solid;border-width:0}table#user-grades td.userfield,
table#user-grades th,
.path-grade-report-grader div.gradeparent,
.path-grade-report-grader .ie6 form,
table#user-grades
td.ajax{text-align:left}.dir-rtl table#user-grades td.userfield,
.dir-rtl table#user-grades th,
.path-grade-report-grader.dir-rtl  div.gradeparent,
.path-grade-report-grader.dir-rtl  .ie6 form,
.dir-rtl table#user-grades
td.ajax{text-align:right}.path-grade-report-grader
.gradeparent{overflow:auto}table#user-grades td.controls,
.path-grade-report-grader table tr.avg .cell,
.path-grade-report-grader table tr.range
.cell{background-color:#f3ead8}.path-grade-report-grader div.left_scroller tr,
.path-grade-report-grader div.right_scroller tr,
.path-grade-report-grader div.left_scroller td,
.path-grade-report-grader div.right_scroller td,
.path-grade-report-grader div.left_scroller th,
.path-grade-report-grader div.right_scroller
th{height:4.5em;font-size:10px}.path-grade-report-grader table th.user,
.path-grade-report-grader table
td.userfield{text-align:left;vertical-align:middle}.path-grade-report-grader .usersuspended a:link,
.path-grade-report-grader .usersuspended a:visited{color:#666}.path-grade-report-grader table th.usersuspended
img.usersuspendedicon{vertical-align:text-bottom;margin-left: .45em}.path-grade-report-grader
.grade_icons{margin-bottom: .3em}.path-grade-report-grader tr.controls
.grade_icons{margin-bottom:0}.path-grade-report-grader .yui3-overlay{background-color:#FFEE69;border-color:#D4C237 #A6982B #A6982B;border-style:solid;border-width:1px;left:0;padding:2px
5px;font-size:0.7em}.path-grade-report-grader .yui3-overlay
.fullname{color:#5F3E00;font-weight:bold}.path-grade-report-grader .yui3-overlay
.itemname{color:#194F3E;font-weight:bold}.path-grade-report-grader .yui3-overlay
.feedback{color:#5F595E}.path-grade-report-grader
#tooltipPanel{text-align:left}.path-grade-report-grader .yui3-overlay a.container-close{margin-top:-3px}.path-grade-report-grader #hiddentooltiproot,.tooltipDiv{display:none}.path-grade-report-grader.ie
.right_scroller{overflow-y:hidden}.path-grade-report-grader.ie table#fixed_column
th{height:4.5em}.path-grade-report-grader.ie table#fixed_column tr.avg
th{height:2.1em}.path-grade-report-grader.ie div.left_scroller
td{height:4.5em}.path-grade-report-grader.ie6
div.right_scroller{margin-top:4em;width:auto;position:absolute}.path-grade-report-grader.ie6
.excludedfloater{font-size:7px}.path-grade-report-grader.dir-rtl table th.user,
.path-grade-report-grader.dir-rtl table
td.userfield{text-align:right}.dir-rtl table#user-grades th.category,
.dir-rtl table#user-grades th#studentheader,
.dir-rtl table#user-grades
th.user{text-align:right}.path-grade-report-grader.dir-rtl th.user
img.userpicture{margin-left:0.5em}.path-grade-report-grader .yui3-scrollview-scrollbar{opacity:1 !important}.path-grade-report-grader .yui3-scrollview-scrollbar-horiz{bottom:-2px}.path-grade-report-user .user-grade
.datesubmitted{font-size:0.7em}.path-grade-report-user .user-grade .courseitem,
.path-grade-report-user .user-grade
.categoryitem{font-weight:bold}.path-grade-report-user .user-grade
td.cell{padding-left:5px;padding-right:5px}#graded_users_selector{float:right;text-align:right}.path-grade-report-user .user-grade .hidden,
.path-grade-report-user .user-grade .hidden
a{color:#aaa}.user-grade{border:1px
solid black;margin:auto;padding:0.25em;font-size:0.8em}.user-grade
td{margin:1px;padding:0.25em;min-width:2em;vertical-align:top}.user-grade
thead{border-bottom:3px double black}.user-grade thead
th{padding:0.25em 0.75em}.user-grade tbody
th{text-align:left}.user-grade td.oddd1,
.user-grade
th.oddd1{background-color:#f3dfd0}.user-grade td.oddd2,
.user-grade
th.oddd2{background-color:#d0dbf3}.user-grade td.oddd3,
.user-grade
th.oddd3{background-color:#d0f3d6}.user-grade td.oddd4,
.user-grade
th.oddd4{background-color:#f0f0aa}.user-grade td.evend2,
.user-grade
th.evend2{background-color:#b0bbd3}.user-grade td.evend3,
.user-grade
th.evend3{background-color:#b0dfb6}.user-grade td.evend4,
.user-grade
th.evend4{background-color:#cac8be}.user-grade td.b1t,
.user-grade td.b2t,
.user-grade th.b1t,
.user-grade
th.b2t{border-top:2px solid black}.user-grade td.b1r,
.user-grade td.b2r,
.user-grade th.b1r,
.user-grade
th.b2r{border-right:2px solid black}.user-grade td.b1b,
.user-grade td.b2b,
.user-grade th.b1b,
.user-grade
th.b2b{border-bottom:2px solid black}.user-grade td.b1l,
.user-grade td.b2l,
.user-grade th.b1l,
.user-grade
th.b2l{border-left:2px solid black}.user-grade td.baggt,
.user-grade td.baggb,
.user-grade th.baggt,
.user-grade
th.baggb{font-style:italic;font-weight:bold}.user-grade td.baggt,
.user-grade
th.baggt{border-top:3px double black}.user-grade td.baggb,
.user-grade
th.baggb{border-bottom:3px double black}.user-grade td.item,
.user-grade
th.item{border-left:1px solid gray;border-right:1px solid gray}.user-grade
td.excluded{background-color:#666}.user-grade
td.hidden{color:#aaa}.user-grade
td.feedbacktext{max-width:600px;padding:2px
2px}.pagelayout-report .user-grade .feedbacktext .no-overflow{overflow:auto;padding:0.25em}table.user-grade
td.feedbacktext{text-align:left;width:40%;font-size:0.8em;white-space:normal}table.user-grade
td.itemcenter{text-align:center}.gradingform_guide-regrade{padding:10px;background:#FDD;border:1px
solid #F00;margin-bottom:10px}.gradingform_guide-restored{padding:10px;background:#FFD;border:1px
solid #FF0;margin-bottom:10px}.gradingform_guide-error{color:red;font-weight:bold}.gradingform_guide_editform
.status{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE}.gradingform_guide_editform
.status.ready{background-color:#e7f1c3;border-color:#AEA}.gradingform_guide_editform
.status.draft{background-color:#f3f2aa;border-color:#EE2}.gradingform_guide.editor .criterion .controls,
.gradingform_guide .criterion .description,
.gradingform_guide .criterion
.remark{vertical-align:top}.gradingform_guide.editor .criterion .controls,
.gradingform_guide.editor .criterion .description,
.gradingform_guide.editor .criterion
.remark{padding:3px}.gradingform_guide
.criteria{height:100%}.gradingform_guide
.criterion{border:1px
solid #DDD;overflow:hidden}.gradingform_guide
.criterion.even{background:#F0F0F0}.gradingform_guide .criterion
.description{width:100%}.gradingform_guide .criterion .description .criterionmaxscore
input{width:20px}.gradingform_guide .criterion .description
.criterionname{font-weight:bold}.gradingform_guide .criterion
label{font-weight:bold;padding-right:5px}.gradingform_guide
.plainvalue.empty{font-style:italic;color:#AAA}.gradingform_guide
.plainvalue.editname{font-weight:bold}.gradingform_guide.editor .criterion.first.last .controls .delete input,
.gradingform_guide.editor .criterion.first .controls .moveup input,
.gradingform_guide.editor .criterion.last .controls .movedown
input{display:none}.gradingform_guide.editor .delete input,
.gradingform_guide.editor .moveup input,
.gradingform_guide.editor .movedown
input{text-indent:-1000em;cursor:pointer;border:none}.gradingform_guide.editor .criterion .controls .delete
input{width:20px;height:16px;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fdelete) no-repeat center top;margin-top:4px}.gradingform_guide.editor .moveup
input{width:20px;height:15px;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fup) no-repeat center top;margin-top:4px}.gradingform_guide.editor .movedown
input{width:20px;height:15px;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fdown) no-repeat center top;margin-top:4px}.gradingform_guide.editor .addcriterion input,
.gradingform_guide.editor .addcomment
input{background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fadd) no-repeat;display:block;color:#555;font-weight:bold;text-decoration:none}.gradingform_guide.editor .addcriterion input,
.gradingform_guide.editor .addcomment
input{background-position:5px 8px;height:30px;line-height:29px;margin-bottom:14px;padding-left:20px;padding-right:10px}.gradingform_guide .options
.optionsheading{font-weight:bold;font-size:1.1em;padding-bottom:5px}.gradingform_guide .options
.option{padding-bottom:2px}.gradingform_guide .options .option
label{margin-left:5px}.gradingform_guide .options .option
.value{margin-left:5px;font-weight:bold}.gradingform_guide .criterion
.description.error{background:#FDD}.gradingform_guide.editor
.hiddenelement{display:none}.gradingform_guide.editor
.pseudotablink{background-color:transparent;border:0
solid;height:1px;width:1px;color:transparent;padding:0;margin:0;position:relative;float:right}.jsenabled .gradingform_guide
.markingguidecomment{cursor:pointer}.jsenabled .gradingform_guide .markingguidecomment:before{content:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fadd);padding-right:2px}.dir-rtl.jsenabled .gradingform_guide .markingguidecomment:before{padding-right:0;padding-left:2px}.gradingform_guide
.commentheader{font-weight:bold;font-size:1.1em;padding-bottom:5px}.jsenabled .gradingform_guide
.criterionnamelabel{display:none}.jsenabled .gradingform_guide
.criterionshortname{font-weight:bold}.gradingform_guide
table{width:100%}.gradingform_guide
.descriptionreadonly{vertical-align:top}.gradingform_guide
.criteriondescriptionmarkers{width:300px}.gradingform_guide
.markingguideremark{margin:0;width:100%;-moz-box-sizing:border-box;box-sizing:border-box}.gradingform_guide
.criteriondescriptionscore{display:inline}.gradingform_guide .score
label{display:block}.gradingform_guide .score
input{margin:0;width:auto}.gradingform_rubric_editform
.status{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE}.gradingform_rubric_editform
.status.ready{background-color:#e7f1c3;border-color:#AEA}.gradingform_rubric_editform
.status.draft{background-color:#f3f2aa;border-color:#EE2}.gradingform_rubric{overflow:auto;padding-bottom:1.5em;max-width:720px;position:relative}.gradingform_rubric.editor .criterion .controls,
.gradingform_rubric .criterion .description,
.gradingform_rubric .criterion .levels,
.gradingform_rubric.editor .criterion .addlevel,
.gradingform_rubric .criterion .remark,
.gradingform_rubric .criterion .levels
.level{vertical-align:top}.gradingform_rubric.editor .criterion .controls,
.gradingform_rubric .criterion .description,
.gradingform_rubric.editor .criterion .addlevel,
.gradingform_rubric .criterion .remark,
.gradingform_rubric .criterion .levels
.level{padding:3px}.gradingform_rubric
.criteria{height:100%}.gradingform_rubric
.criterion{border:1px
solid #DDD;overflow:hidden}.gradingform_rubric
.criterion.even{background:#F0F0F0}.gradingform_rubric .criterion
.description{width:150px;font-weight:bold}.gradingform_rubric .criterion .levels
table{width:100%;height:100%}.gradingform_rubric .criterion .levels,
.gradingform_rubric .criterion .levels table,
.gradingform_rubric .criterion .levels table
tbody{padding:0;margin:0}.gradingform_rubric .criterion .levels
.level{border-left:1px solid #DDD;max-width:150px}.gradingform_rubric .criterion .levels .level .level-wrapper{position:relative}.gradingform_rubric .criterion .levels
.level.last{border-right:1px solid #DDD}.gradingform_rubric
.plainvalue.empty{font-style:italic;color:#AAA}.gradingform_rubric.editor .criterion .levels .level
.delete{position:absolute;right:0}.gradingform_rubric .criterion .levels .level
.score{font-style:italic;color:#575;font-weight:bold;margin-top:5px;white-space:nowrap}.gradingform_rubric .criterion .levels .level .score
.scorevalue{padding-right:5px}.gradingform_rubric.editor .criterion.first .controls .moveup input,
.gradingform_rubric.editor .criterion.last .controls .movedown
input{display:none}.gradingform_rubric .criterion .levels
.level.currentchecked{background:#fff0f0}.gradingform_rubric .criterion .levels
.level.checked{background:#d0ffd0;border:1px
solid #555}.gradingform_rubric.evaluate .criterion .levels .level:hover{background:#30ff30}.gradingform_rubric.editor .delete input,
.gradingform_rubric.editor .moveup input,
.gradingform_rubric.editor .movedown
input{text-indent:-1000em;cursor:pointer;border:none}.gradingform_rubric.editor .criterion .controls .delete
input{width:12px;height:12px;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fdelete) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .levels .level .delete
input{width:12px;height:16px;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fdelete) no-repeat center center}.dir-rtl .gradingform_rubric.editor .levels .level .delete
input{margin-right: .45em;margin-left:0}.gradingform_rubric.editor .moveup
input{width:12px;height:12px;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fup) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .movedown
input{width:12px;height:12px;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fdown) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .addcriterion input,
.gradingform_rubric.editor .addlevel
input{background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fadd) no-repeat top left;display:block;color:#555;font-weight:bold;text-decoration:none}.gradingform_rubric.editor .addcriterion
input{background-position:5px 8px;height:30px;line-height:29px;margin-bottom:14px;padding-left:20px;padding-right:10px}.gradingform_rubric.editor .addlevel
input{background-position:5px 5px;height:25px;line-height:24px;margin-bottom:45px;padding-left:18px;padding-right:8px}.gradingform_rubric .options
.optionsheading{font-weight:bold;font-size:1.1em;padding-bottom:5px}.gradingform_rubric .options
.option{padding-bottom:2px}.gradingform_rubric .options .option
label{margin-left:5px}.gradingform_rubric .options .option
.value{margin-left:5px;font-weight:bold}.gradingform_rubric .criterion
.levels.error{border:1px
solid red}.gradingform_rubric .criterion .description.error,
.gradingform_rubric .criterion .levels .level .definition.error,
.gradingform_rubric .criterion .levels .level
.score.error{background:#FDD}.gradingform_rubric-regrade{padding:10px;background:#FDD;border:1px
solid #F00;margin-bottom:10px}.gradingform_rubric-restored{padding:10px;background:#FFD;border:1px
solid #FF0;margin-bottom:10px}.gradingform_rubric-error{color:red;font-weight:bold}.gradingform_rubric.editor
.hiddenelement{display:none}.gradingform_rubric.editor
.pseudotablink{background-color:transparent;border:0
solid;height:1px;width:1px;color:transparent;padding:0;margin:0;position:relative;float:right}.path-admin-mnet-service-enrol
.singlebutton{text-align:center}.path-admin-mnet-service-enrol table.remotehosts,
.path-admin-mnet-service-enrol table.otherenrolledusers,
.path-admin-mnet-service-enrol
table.remotecourses{margin:0px
auto 1em auto}.path-admin-mnet-service-enrol table.remotecourses
th.categoryname{text-align:left;background-color:#f6f6f6}.path-admin-mnet-service-enrol table.remotecourses
td.c1{font-weight:bold}.path-admin-mnet-service-enrol table.remotecourses th.categoryname
img{margin-right:1em}.path-admin-mnet-service-enrol
.collapsibleregioncaption{font-size:110%;font-weight:bold;text-align:center}.path-admin-mnet-service-enrol
.collapsibleregioninner{border:1px
solid #ddd;padding:1em}.path-admin-mnet-service-enrol
.collapsibleregion.remotecourse.summary{margin:0px
10em}.path-admin-mnet-service-enrol
.roleassigntable{margin:1em
auto}.repository_alfresco .fp-toolbar .fp-tb-search{width:auto}.repository_alfresco .fp-toolbar .fp-tb-search .alfresco-workplace{width:140px;height:32px;padding:2px
1px 1px 1px;background-color:#fff;border-radius:4px;border-color:#bbb}.qbehaviour_deferredcbm_slightlyunderconfident,.qbehaviour_deferredcbm_slightlyoverconfident{font-weight:bold;color:#600}.qbehaviour_deferredcbm_underconfident,.qbehaviour_deferredcbm_overconfident{font-weight:bold;color:#c00}.qbehaviour_deferredcbm_judgementok{font-weight:bold;color:#080}.qbehaviour_deferredcbm_actual_percentage{font-weight:bold}.qbehaviour_deferredcbm_summary_heading{margin:0}.que.deferredcbm .certaintychoices input[type="radio"]{margin-left:0.5em}.que.deferredcbm .certaintychoices
label{white-space:nowrap}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable
.c0{display:none}#page-admin-tool-assignmentupgrade-listnotupgraded.jsenabled .tool_assignmentupgrade_upgradetable
.c0{display:table-cell}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable tr.selectedrow
td{background-color:#fec}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable tr.unselectedrow
td{background-color:white}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_paginationform
.hidden{display:none}.steps-definitions{border-style:solid;border-width:1px;border-color:#BBB;padding:5px;margin:auto;width:50%}.steps-definitions
.step{margin:10px
0px 10px 0px}.steps-definitions
.stepdescription{color:#bf8c12}.steps-definitions
.steptype{color:#1467a6;margin-right:5px}.steps-definitions
.stepregex{color:#060}.path-admin-tool-capability
.comparisontable{margin-top:150px}.path-admin-tool-capability .comparisontable th,
.path-admin-tool-capability .comparisontable
td{vertical-align:middle;padding:0.4em 0.5em 0.3em}.path-admin-tool-capability .comparisontable thead
th{vertical-align:bottom;background:none}.path-admin-tool-capability .comparisontable thead th
div{position:relative}.path-admin-tool-capability .comparisontable thead th div>a{position:absolute;top:-1.75em;left:1em;width:150px;text-align:left;margin-bottom:1em;text-indent:-1.45em;-webkit-transform-origin:top left;-moz-transform-origin:top left;-ms-transform-origin:top left;-o-transform-origin:top left;-webkit-transform:rotate(315deg);-moz-transform:rotate(315deg);-ms-transform:rotate(315deg);-o-transform:rotate(315deg)}.path-admin-tool-capability .comparisontable tbody
th{background-color:#EEE;text-align:right;border:1px
solid #DFDFDF}.path-admin-tool-capability .comparisontable tbody th
span{display:block;color:#666;font-size:80%}.path-admin-tool-capability .comparisontable tbody
td{border:1px
solid #DFDFDF}.path-admin-tool-capability .comparisontable
.inherit{color:#666}.path-admin-tool-capability .comparisontable
.allow{color:#060;font-weight:bold}.path-admin-tool-capability .comparisontable
.prevent{color:#ad6704;font-weight:bold}.path-admin-tool-capability .comparisontable
.prohibit{color:#800;font-weight:bold}.path-admin-tool-customlang .langselectorbox,
.path-admin-tool-customlang fieldset.buttonsbar,
.path-admin-tool-customlang
.menu{margin:5px
auto;text-align:center}.path-admin-tool-customlang .menu .singlebutton,
.path-admin-tool-customlang .menu .singlebutton form,
.path-admin-tool-customlang .menu .singlebutton form
div{display:inline}.path-admin-tool-customlang
.mform.filterform{width:70%;margin-left:auto;margin-right:auto}.path-admin-tool-customlang .mform.filterform .fitem
.fitemtitle{width:30%}.path-admin-tool-customlang .mform.filterform .fitem
.felement{width:60%;margin-left:31%}.path-admin-tool-customlang
#translator{width:100%}.path-admin-tool-customlang #translator .standard,
.path-admin-tool-customlang #translator
.local{min-width:35%}.path-admin-tool-customlang #translator
.customized{background-color:#e7f1c3}.path-admin-tool-customlang #translator
.customized.outdated{background-color:#f3f2aa}.path-admin-tool-customlang #translator
.modified{background-color:#ffd3d9}.path-admin-tool-customlang #translator
.customized.modified{background-color:#d2ebff}.path-admin-tool-customlang #translator
textarea{width:100%;min-height:4em}.path-admin-tool-customlang #translator
.placeholderinfo{text-align:center;border:1px
dotted #ddd;background-color:#f6f6f6;margin-top:0.5em}#page-admin-tool-customlang-index
.continuebutton{margin-top:1em}.path-admin-tool-customlang #translator
.standard.master.cell.c2{word-break:break-all}.path-admin-tool-health
div#healthnoproblemsfound{width:60%;margin:auto;padding:1em;border:1px
solid black;-moz-border-radius:6px}.path-admin-tool-health
dl.healthissues{width:60%;margin:auto}.path-admin-tool-health dl.critical dt,
.path-admin-tool-health dl.critical
dd{background-color:#a71501}.path-admin-tool-health dl.significant dt,
.path-admin-tool-health dl.significant
dd{background-color:#d36707}.path-admin-tool-health dl.annoyance dt,
.path-admin-tool-health dl.annoyance
dd{background-color:#dba707}.path-admin-tool-health dl.notice dt,
.path-admin-tool-health dl.notice
dd{background-color:#e5db36}.path-admin-tool-health dt.solution,
.path-admin-tool-health dd.solution,
.path-admin-tool-health
div#healthnoproblemsfound{background-color:#5BB83E !important}.path-admin-tool-health dl.healthissues dt,
.path-admin-tool-health dl.healthissues
dd{margin:0px;padding:1em;border:1px
solid black}.path-admin-tool-health dl.healthissues
dt{font-weight:bold;border-bottom:0;padding-bottom:0.5em}.path-admin-tool-health dl.healthissues
dd{border-top:0;padding-top:0.5em;margin-bottom:10px}.path-admin-tool-health dl.healthissues dd
form{margin-top:0.5em;text-align:right}.path-admin-tool-health
form#healthformreturn{text-align:center;margin:2em}.path-admin-tool-health dd.solution
p{padding:0px;margin:1em
0px}.path-admin-tool-health dd.solution
li{margin-top:1em}#page-admin-tool-installaddon-index
#installfromrepobox{text-align:center;padding-top:2em;padding-bottom:2em}#page-admin-tool-installaddon-index #installfromrepobox
.singlebutton{display:inline-block}#page-admin-tool-installaddon-index #installfromrepobox .singlebutton input[type=submit]{padding:1em}#page-admin-tool-installaddon-validate
.validationresult{margin:2em
auto;text-align:center}#page-admin-tool-installaddon-validate .validationresult
.verdict{margin:0em
0.5em;padding:0.5em;border:2px
solid;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;font-weight:bold}#page-admin-tool-installaddon-validate .validationresult.success
.verdict{background-color:#e7f1c3;border-color:#aea}#page-admin-tool-installaddon-validate .validationresult.failure
.verdict{background-color:#ffd3d9;border-color:#eaa}#page-admin-tool-installaddon-validate
.validationmessages{margin:0px
auto}#page-admin-tool-installaddon-validate .validationmessages .level-error
.msgstatus{background-color:#ffd3d9}#page-admin-tool-installaddon-validate .validationmessages .level-warning
.msgstatus{background-color:#f3f2aa}#page-admin-tool-installaddon-validate .validationmessages .level-info
.msgstatus{background-color:#e7f1c3}#page-admin-tool-installaddon-validate .validationmessages .level-debug
.msgstatus{background-color:#d2ebff}#page-admin-tool-installaddon-validate
.postvalidationbuttons{text-align:center;margin:1em
auto}#page-admin-tool-installaddon-validate .postvalidationbuttons
.singlebutton{display:inline-block;margin:1em
1em}#page-admin-tool-langimport-index .generalbox
table{margin:auto;width:100%}#page-admin-tool-langimport-index .generalbox,
#page-admin-tool-langimport-index .generalbox
table{text-align:center}.path-admin-tool-profiling .profilingruntable
.label{font-weight:bold}.path-admin-tool-profiling
.profiling_worse{color:red}.path-admin-tool-profiling
.profiling_better{color:green}.path-admin-tool-profiling
.profiling_same{color:dimgrey}.path-admin-tool-profiling .profiling_important,
.path-admin-tool-profiling .flexible
.referencerun{font-weight:bold}.path-admin-tool-profiling .flexible .r1
.cell{background-color:whitesmoke}.path-admin-tool-profiling
.flexible{margin-left:auto;margin-right:auto}#page-admin-tool-task-scheduledtasks .task-class{display:block;padding:0
0.5em;color:#888;font-size:0.75em}.assignfeedback_editpdf_widget .toolbar
ul{display:none}.assignfeedback_editpdf_widget .toolbar
li{list-style-type:none}.assignfeedback_editpdf_widget
.drawingcanvas{position:relative;min-width:817px;min-height:1169px;cursor:crosshair}.assignfeedback_editpdf_widget{user-select:none;-moz-user-select:none;-webkit-user-select:none;-o-user-select:none}.assignfeedback_editpdf_widget
.pageheader{background-color:#ebebeb;border-bottom:1px solid #ccc;padding:0px;padding-left:20px;padding-right:20px;min-height:50px}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_widget .moodle-dialogue-bd{padding:0px}.assignfeedback_editpdf_unsavedchanges.haschanges{display:block}.assignfeedback_editpdf_unsavedchanges{display:none;margin-top:1em}.yui3-colourpicker-hidden,.yui3-commentsearch-hidden,.yui3-commentmenu-hidden{display:none}.assignfeedback_editpdf_widget .pageheader button
img{padding-top:3px;vertical-align:top}.assignfeedback_editpdf_widget .pageheader button:active{background-color:#ccc}.assignfeedback_editpdf_widget .pageheader select,
.assignfeedback_editpdf_widget .pageheader
button{background:none;padding:4px
7px;border:0px;border-radius:0px;margin:0px;height:30px;line-height:30px;vertical-align:top;cursor:pointer}.assignfeedback_editpdf_widget .pageheader
select{vertical-align:top;-webkit-appearance:none;-moz-appearance:menulist-text;background-color:#fff;padding:0px
10px}.assignfeedback_editpdf_widget .pageheader select::-ms-expand{display:none}.assignfeedback_editpdf_widget .pageheader .navigation button + button,
.assignfeedback_editpdf_widget .pageheader .toolbar button + button,
.assignfeedback_editpdf_widget .pageheader .navigation select + button,
.assignfeedback_editpdf_widget .pageheader .toolbar select+button{border-left:1px solid #ccc;border-right:0px}.assignfeedback_editpdf_widget .pageheader .navigation
button{border-right:1px solid #ccc}.assignfeedback_editpdf_widget .pageheader .toolbar,
.assignfeedback_editpdf_widget .pageheader .navigation-search,
.assignfeedback_editpdf_widget .pageheader
.navigation{border:1px
solid #ccc;border-bottom-color:#b3b3b3;border-radius:4px;margin:10px
4px;background-color:white;height:30px;line-height:30px;padding:0px}.assignfeedback_editpdf_commentsearch
ul{max-height:400px;overflow-y:auto;padding:1em}.assignfeedback_editpdf_commentsearch ul li
pre{background-color:#efefef}.assignfeedback_editpdf_commentsearch ul li pre:hover{background-color:#ddd}.assignfeedback_editpdf_commentsearch ul
li{line-height:0px;margin:2px}.assignfeedback_editpdf_commentsearch a
pre{font-family:helvetica;margin:0px;padding:4px}.assignfeedback_editpdf_widget .navigation-search,
.assignfeedback_editpdf_widget
.navigation{float:left}.dir-rtl .assignfeedback_editpdf_widget .navigation-search,
.dir-rtl .assignfeedback_editpdf_widget
.navigation{float:right}.assignfeedback_editpdf_widget .toolbar
button{box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none}.assignfeedback_editpdf_widget
.toolbar{float:right}.dir-rtl .assignfeedback_editpdf_widget
.toolbar{float:left}.assignfeedback_editpdf_widget .navigation,
.assignfeedback_editpdf_widget .navigation-search,
.assignfeedback_editpdf_widget
.toolbar{display:inline-block}.assignfeedback_editpdf_colourpicker
ul{margin:0px}.assignfeedback_editpdf_commentmenu
li.quicklist_comment{width:150px}.assignfeedback_editpdf_commentmenu li.quicklist_comment
a{white-space:nowrap;display:inline-block;max-width:130px;overflow:hidden;text-overflow:ellipsis}.assignfeedback_editpdf_commentmenu
a.delete_quicklist_comment{float:right}.dir-rtl .assignfeedback_editpdf_commentmenu
a.delete_quicklist_comment{float:left}.assignfeedback_editpdf_dropdown
button{border:0px;background:none;padding:6px
7px;border-radius:0px;border-top:1px solid #ccc}.assignfeedback_editpdf_dropdown li:first-child
button{border-top:0px}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_dropdown .moodle-dialogue-wrap{box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none;margin-left:0px;margin-right:0px;margin-top:0px;border-radius:4px}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_dropdown .moodle-dialogue-bd{padding:0px}.assignfeedback_editpdf_dropdown .moodle-dialogue-hd,
.assignfeedback_editpdf_dropdown .moodle-dialogue-ft{display:none}.assignfeedback_editpdf_menu li
hr{margin:0px}.assignfeedback_editpdf_menu li
a{text-decoration:none;color:#555;margin:10px}.assignfeedback_editpdf_menu li:hover,
.assignfeedback_editpdf_menu li:hover a,
.assignfeedback_editpdf_menu li a:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%)}ul.assignfeedback_editpdf_menu{margin:0px}.assignfeedback_editpdf_menu
li{list-style-type:none;margin:0px;border-radius:4px}.assignfeedback_editpdf_menu li
img{height:auto}.assignfeedback_editpdf_menu li
button{margin:0px;background:none}.assignfeedback_editpdf_widget .pageheader button:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%)}.assignfeedback_editpdf_widget .pageheader button.assignfeedback_editpdf_selectedbutton:hover,
.assignfeedback_editpdf_widget .pageheader
button.assignfeedback_editpdf_selectedbutton{background-color:#dfdfdf;background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%)}.assignfeedback_editpdf_widget .commentdrawable
img{padding:1px}.assignfeedback_editpdf_widget .commentdrawable
a{float:right;position:relative;left:-17px;top:2px;height:14px;background-color:white;border-left:1px solid #ccc;border-bottom:1px solid #ccc;line-height:14px}.dir-rtl .assignfeedback_editpdf_widget .commentdrawable
a{float:left;left:none;right:-17px;border-left:0px;border-right:1px solid #ccc}.assignfeedback_editpdf_widget .commentdrawable
textarea{padding:4px;padding-right:20px;resize:none;overflow:hidden;color:black;border:2px
solid #ccc;border-radius:4px;font-size:16px;font-family:helvetica;min-height:1.2em}.assignfeedback_editpdf_widget
.commentdrawable{display:inline-block}.dir-rtl .assignfeedback_editpdf_widget .commentdrawable
textarea{padding-left:20px;padding-right:4px}.assignfeedback_editpdf_widget .drawingcanvas .loading
.progressbarlabel{text-align:center}#page-mod-quiz-report
#manualgradingform{width:100%}#page-mod-quiz-report #manualgradingform.mform
br{clear:none}#page-mod-quiz-report #manualgradingform.mform .clearfix:after{clear:none}#page-mod-quiz-report #manualgradingform
.que{margin-bottom:0.7em}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper,
.path-mod-workshop .assessmentform.rubric #id_rubric-grid-wrapper{border:none}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper legend,
.path-mod-workshop .assessmentform.rubric #id_rubric-grid-wrapper
legend{display:none}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper th,
.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper td,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper th,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
td{border:1px
solid #ddd;padding:5px;vertical-align:top}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
.criterion{text-align:center}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
.fitem{text-align:center}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem .fitemtitle,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem
.fitemtitle{display:none}.path-mod-workshop #id_rubric-grid-wrapper .rubric-grid{margin-left:auto;margin-right:auto}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem .felement,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem
.felement{width:100%;margin-left:auto;margin-right:auto}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem
.felement{border:none}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem .felement
span{display:block;text-align:center}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem .felement span
label{display:block;text-align:center}.path-mod-workshop .mform.frozen .fitem.description.rubric + .fitem .fitemtitle,
.path-mod-workshop .assessmentform.rubric.list #id_rubric-grid-wrapper .fitem
.fitemtitle{display:none}.path-mod-workshop .mform.frozen .fitem.description.rubric + .fitem .fitemtitle + .felement,
.path-mod-workshop .assessmentform.rubric.list .fitem
.felement{width:auto;border:none}.path-mod-workshop .assessmentform.rubric.list .fitem .felement
span{display:block}.path-mod-workshop .assessmentform.rubric.list .fitem .felement span
input{display:block;float:left}.path-mod-workshop .assessmentform.rubric.list .fitem .felement.fgroup span
label{display:block;margin-left:30px}.path-mod-workshop .manual-allocator
.allocations{margin:0px
auto}.path-mod-workshop .manual-allocator .allocations
.r0{background-color:#eee}.path-mod-workshop .manual-allocator .allocations .r0.highlightreviewerof,
.path-mod-workshop .manual-allocator .allocations
.r0.highlightreviewedby{background-color:inherit}.path-mod-workshop .manual-allocator .allocations .peer
.image{margin-right:5px;vertical-align:middle}.path-mod-workshop .manual-allocator .allocations .reviewedby .image,
.path-mod-workshop .manual-allocator .allocations .reviewerof
.image{margin-right:3px;vertical-align:middle}.path-mod-workshop .manual-allocator .allocations .highlightreviewedby .reviewedby,
.path-mod-workshop .manual-allocator .allocations .highlightreviewerof
.reviewerof{background-color:#fff3d2}.path-mod-workshop .manual-allocator .allocations tr
td{vertical-align:top;padding:5px}.path-mod-workshop .manual-allocator .allocations tr td
ul{margin:0px}.path-mod-workshop .manual-allocator .allocations tr td ul
li{list-style:none}.path-mod-workshop .manual-allocator .allocations tr
td.peer{border-left:1px solid #ccc;border-right:1px solid #ccc}.path-mod-workshop .manual-allocator .allocations .reviewedby .info,
.path-mod-workshop .manual-allocator .allocations .peer .info,
.path-mod-workshop .manual-allocator .allocations .reviewerof
.info{font-size:80%;color:#888;font-style:italic}.path-mod-workshop .manual-allocator .allocations .peer
.submission{font-size:90%;margin-top:1em}.path-mod-workshop .random-allocator
.warning{width:80%;margin:0px
auto 15px auto}.accessibilitywarnings
img{max-width:32px;max-height:32px}.atto_backcolor_button .dropdown-menu{min-width:inherit}.atto_charmap_selector
button{width:2em;padding:0
3px}@media (max-width: 768px){.toolbarbreak{display:none}}.atto_emoticon_map
ul{padding:0;margin:0;display:table;width:100%}.atto_emoticon_map
li{display:table-row;white-space:nowrap}.atto_emoticon_map li
div{display:table-cell;padding:0
1em}.atto_equation_library .yui3-tabview-list{border:none}.atto_equation_library .yui3-tab-selected .yui3-tab-label, .yui3-skin-sam #atto_equation_library .yui3-tab-selected .yui3-tab-label:focus, .yui3-skin-sam #atto_equation_library .yui3-tab-selected .yui3-tab-label:hover{background:none;color:black;border-top-left-radius:4px;border-top-right-radius:4px}.atto_equation_library
button{margin:0.25%;min-width:12%}#page-admin-setting-atto_equation_settings .form-defaultinfo{max-height:10em;overflow:auto;padding:5px;min-width:206px}.atto_form
.atto_equation_preview{margin-bottom:0px}.atto_fontcolor_button .dropdown-menu{min-width:inherit}.atto_image_preview{width:100%;height:100%;margin-left:auto;margin-right:auto}.atto_image_preview_box{max-height:200px;margin-bottom:1em;overflow:auto}.editor_atto_content
img{cursor:pointer}.atto_image_size{display:inline-block}.atto_image_size input[type=checkbox]{margin-left:1em;margin-right:1em}.atto_image_size input[type=text]{width:3em}.atto_image_size
label{display:inline-block}#atto_managefiles_manageform
#id_deletefileshdr{display:none}#atto_managefiles_manageform.has-unused-files
#id_deletefileshdr{display:block}#atto_managefiles_manageform
#id_missingfileshdr{display:none}#atto_managefiles_manageform.has-missing-files
#id_missingfileshdr{display:block}div.editor_atto_content td,
div.editor_atto_content th,
div.editor_atto_content
caption{border:1px
dashed #BBB;position:relative;min-width:30px;height:13px}div.editor_atto_content
caption{height:auto}#tinymce_managefiles_manageform.hasunusedfiles
.managefilesstatus{display:none}#tinymce_managefiles_manageform.hasmissingfiles
.managefilesstatus{display:inline}#tinymce_managefiles_manageform
#id_deletefiles{display:none}#tinymce_managefiles_manageform.hasunusedfiles
#id_deletefiles{display:block}#tinymce_managefiles_manageform #id_deletefiles
.felement.fcheckbox{display:none}#tinymce_managefiles_manageform #id_deletefiles
.felement.fcheckbox.isunused{display:block}.layout-option-noheader #page-header,.layout-option-nonavbar #page-navbar,.layout-option-nofooter #page-footer,.layout-option-nocourseheader .course-content-header,.layout-option-nocoursefooter .course-content-footer{display:none}.empty-region-side-pre #block-region-side-pre,.empty-region-side-post #block-region-side-post,.jsenabled.docked-region-side-post #block-region-side-post,.jsenabled.docked-region-side-pre #block-region-side-pre{display:none}.content-only #region-main.span9,.empty-region-side-post #region-bs-main-and-pre.span9,.empty-region-side-pre #region-bs-main-and-post.span9,.empty-region-side-post #region-bs-main-and-post.span9 #region-main.span8,.jsenabled.docked-region-side-post #region-bs-main-and-pre.span9,.jsenabled.docked-region-side-post #region-bs-main-and-post.span9 #region-main.span8,.jsenabled.docked-region-side-pre #region-bs-main-and-post.span9{width:100%}.empty-region-side-pre #region-bs-main-and-pre.span9 #region-main,.jsenabled.docked-region-side-pre #region-bs-main-and-pre.span9 #region-main{float:none;width:100%}.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:74.46808510638297%;*width:74.41489361702126%}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4{width:23.404255319148934%;*width:23.351063829787233%}.empty-region-side-pre #region-bs-main-and-post.span9 #region-main.span8,.jsenabled.docked-region-side-pre #region-bs-main-and-post.span9 #region-main.span8{float:right}.dir-ltr,.mdl-left,.dir-rtl .mdl-right{text-align:left}.dir-rtl,.mdl-right,.dir-rtl .mdl-left{text-align:right}#add,#remove,.centerpara,.mdl-align{text-align:center}a.dimmed,a.dimmed:link,a.dimmed:visited,a.dimmed_text,a.dimmed_text:link,a.dimmed_text:visited,.dimmed_text,.dimmed_text a,.dimmed_text a:link,.dimmed_text a:visited,.usersuspended,.usersuspended a,.usersuspended a:link,.usersuspended a:visited,.dimmed_category,.dimmed_category
a{color:#999}.activity.label
.dimmed_text{opacity:.5;filter:alpha(opacity=50)}.unlist,.unlist li,.inline-list,.inline-list li,.block .list,.block .list li,.section li.activity,.section li.movehere,.tabtree
li{padding:0;margin:0;list-style:none}.inline,.inline-list
li{display:inline}.notifytiny{font-size:10.5px}.notifytiny li,.notifytiny
td{font-size:100%}.red,.notifyproblem{color:#b94a48}.green,.notifysuccess{color:#468847}.highlight{background:#d9edf7}.reportlink{text-align:right}a.autolink.glossary:hover{cursor:help}.collapsibleregioncaption{white-space:nowrap}.collapsibleregioncaption
img{vertical-align:middle}.jsenabled
.hiddenifjs{display:none}.visibleifjs{display:none}.jsenabled
.visibleifjs{display:inline}.jsenabled
.collapsibleregion{overflow:hidden}.jsenabled .collapsed
.collapsibleregioninner{visibility:hidden}.collapsible-actions{display:none;text-align:right}.dir-rtl .collapsible-actions{text-align:left}.jsenabled .collapsible-actions{display:block}.collapsible-actions
.collapseexpand{padding-left:20px;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed) 2px center no-repeat}.dir-rtl .collapsible-actions
.collapseexpand{padding-right:20px;padding-left:0;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_rtl) right center no-repeat}.collapsible-actions .collapse-all,.dir-rtl .collapsible-actions .collapse-all{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fexpanded)}.yui-overlay .yui-widget-bd{position:relative;top:0;left:0;z-index:1;padding:2px
5px;color:#000;background-color:#ffee69;border:1px
solid #a6982b;border-top-color:#d4c237}.clearer{display:block;height:1px;padding:0;margin:0;clear:both;background:transparent;border-width:0}.bold,.warning,.errorbox .title,.pagingbar .title,.pagingbar
.thispage{font-weight:bold}img.resize{width:1em;height:1em}.block img.resize,.breadcrumb
img.resize{width:.8em;height:.9em}img.icon{width:16px;height:16px;padding-right:6px;vertical-align:text-bottom}.dir-rtl
img.icon{padding-right:0;padding-left:6px}img.iconsmall{width:12px;height:12px;margin-right:3px;vertical-align:middle}img.iconhelp,.helplink
img{width:16px;height:16px;padding-left:3px;vertical-align:text-bottom}h1 img.iconhelp,h1 img.icon,h2 img.iconhelp,h2 img.icon,h3 img.iconhelp,h3 img.icon,h4 img.iconhelp,h4 img.icon,h5 img.iconhelp,h5 img.icon,h6 img.iconhelp,h6
img.icon{padding:4px;vertical-align:middle}.dir-rtl img.iconhelp,.dir-rtl .helplink
img{padding-right:3px;padding-left:0}img.iconlarge{width:24px;height:24px;vertical-align:middle}img.iconsort{padding-left:.3em;margin-bottom:.15em;vertical-align:text-bottom}.dir-rtl
img.iconsort{padding-right:.3em;padding-left:0}img.icontoggle{width:50px;height:17px;vertical-align:middle}img.iconkbhelp{width:49px;height:17px}img.icon-pre,.dir-rtl img.icon-post{padding-right:3px;padding-left:0}img.icon-post,.dir-rtl img.icon-pre{padding-right:0;padding-left:3px}.boxaligncenter{margin-right:auto;margin-left:auto}.boxalignright{margin-right:0;margin-left:auto}.boxalignleft{margin-right:auto;margin-left:0}.boxwidthnarrow{width:30%}.boxwidthnormal{width:50%}.boxwidthwide{width:80%}.headermain{font-weight:bold}#maincontent{display:block;height:1px;overflow:hidden}img.uihint{cursor:help}#addmembersform
table{margin-right:auto;margin-left:auto}table.flexible
.emptyrow{display:none}img.emoticon{width:15px;height:15px;vertical-align:middle}form.popupform,form.popupform
div{display:inline}.arrow_button
input{overflow:hidden}.action-icon
img.smallicon{margin:0
.3em;vertical-align:text-bottom}.no-overflow{padding-bottom:1px;overflow:auto}.pagelayout-report .no-overflow{overflow:visible}.no-overflow>.generaltable{margin-bottom:0}.accesshide{position:absolute;left:-10000px;font-size:1em;font-weight:normal}.dir-rtl
.accesshide{top:-30000px;left:auto}span.hide,div.hide{display:none}a.skip-block,a.skip{position:absolute;top:-1000em;font-size:.85em;text-decoration:none}a.skip-block:focus,a.skip-block:active,a.skip:focus,a.skip:active{position:static;display:block}.skip-block-to{display:block;height:1px;overflow:hidden}.addbloglink{text-align:center}.blog_entry
.audience{padding-right:4px;text-align:right}.blog_entry
.tags{margin-top:15px}.blog_entry .tags .action-icon
img.smallicon{width:16px;height:16px}.blog_entry
.content{margin-left:43px}#page-group-index
#groupeditform{text-align:center}#doc-contents
h1{margin:1em
0 0 0}#doc-contents
ul{width:90%;padding:0;margin:0}#doc-contents ul
li{list-style-type:none}.groupmanagementtable
td{vertical-align:top}.groupmanagementtable #existingcell,.groupmanagementtable
#potentialcell{width:42%}.groupmanagementtable
#buttonscell{width:16%}.groupmanagementtable #buttonscell p.arrow_button
input{width:auto;min-width:80%;margin:0
auto}.groupmanagementtable #removeselect_wrapper,.groupmanagementtable
#addselect_wrapper{width:100%}.groupmanagementtable #removeselect_wrapper label,.groupmanagementtable #addselect_wrapper
label{font-weight:normal}.dir-rtl .groupmanagementtable
p{text-align:right}#group-usersummary{width:14em}.groupselector{display:inline-block;margin-top:3px;margin-bottom:3px}.groupselector
label{display:inline-block}.loginbox{margin:15px;overflow:visible}.loginbox.twocolumns{margin:15px}.loginbox h2,.loginbox
.subcontent{padding:10px;margin:5px;text-align:center}.loginbox .loginpanel
.desc{padding:0;margin:0;margin-top:15px;margin-bottom:5px}.loginbox .signuppanel
.subcontent{text-align:left}.dir-rtl .loginbox .signuppanel
.subcontent{text-align:right}.loginbox
.loginsub{margin-right:0;margin-left:0}.loginbox .guestsub,.loginbox .forgotsub,.loginbox
.potentialidps{margin:5px
12%}.loginbox .potentialidps
.potentialidplist{margin-left:40%}.loginbox .potentialidps .potentialidplist
div{text-align:left}.loginbox
.loginform{margin-top:1em;text-align:left}.loginbox .loginform .form-label{float:left;width:44%;text-align:right;white-space:nowrap;direction:rtl}.dir-rtl .loginbox .loginform .form-label{float:left;width:44%;text-align:right;white-space:nowrap;direction:ltr}.loginbox .loginform .form-input{float:right;width:55%}.loginbox .loginform .form-input
input{width:6em}.loginbox
.signupform{margin-top:1em;text-align:center}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{display:block;float:left;width:48%;min-height:30px;padding:0;padding-bottom:2000px;margin:0;margin-bottom:-2000px;margin-left:2.76243%;border:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.dir-rtl .loginbox.twocolumns .loginpanel,.dir-rtl .loginbox.twocolumns
.signuppanel{float:right}.loginbox .potentialidp
.smallicon{margin:0
.3em;vertical-align:text-bottom}.notepost{margin-bottom:1em}.notepost
.userpicture{float:left;margin-right:5px}.notepost .content,.notepost
.footer{clear:both}.notesgroup{margin-left:20px}.path-my .coursebox
.overview{margin:15px
30px 10px 30px}.path-my .coursebox
.info{float:none;margin:0}.mod_introbox{padding:10px}table.mod_index{width:100%}.comment-ctrl{display:none;padding:0;margin:0;font-size:12px}.comment-ctrl
h5{padding:5px;margin:0}.comment-area{max-width:400px;padding:5px}.comment-area
textarea{width:100%;overflow:auto}.comment-area
.fd{text-align:right}.comment-meta
span{color:gray}.comment-link
img{vertical-align:text-bottom}.comment-list{padding:0;margin:0;overflow:auto;font-size:11px;list-style:none}.comment-list
li{position:relative;padding:.3em;margin:2px;margin-bottom:5px;clear:both;list-style:none}.comment-list
li.first{display:none}.comment-paging{text-align:center}.comment-paging
.pageno{padding:2px}.comment-paging
.curpage{border:1px
solid #CCC}.comment-message
.picture{float:left;width:20px}.dir-rtl .comment-message
.picture{float:right}.comment-message
.text{padding:0;margin:0}.comment-message .text
p{padding:0;margin:0
18px 0 0}.comment-delete{position:absolute;top:0;right:0;margin:.3em}.dir-rtl .comment-delete{position:absolute;right:auto;left:0;margin:.3em}.comment-report-selectall{display:none}.comment-link{display:none}.jsenabled .comment-link{display:block}.jsenabled
.showcommentsnonjs{display:none}.jsenabled .comment-report-selectall{display:inline}.completion-expired{background:#f2dede}.completion-expected{font-size:10.5px}.completion-sortchoice,.completion-identifyfield{font-size:10.5px;vertical-align:bottom}.completion-progresscell{text-align:right}.completion-expired .completion-expected{font-weight:bold}#page-tag-coursetags_edit
.coursetag_edit_centered{position:relative;width:600px;margin:20px
auto}#page-tag-coursetags_edit
.coursetag_edit_row{clear:both}#page-tag-coursetags_edit .coursetag_edit_row
.coursetag_edit_left{float:left;width:50%;text-align:right}#page-tag-coursetags_edit .coursetag_edit_row
.coursetag_edit_right{margin-left:50%}#page-tag-coursetags_edit
.coursetag_edit_input3{display:none}#page-tag-coursetags_more
.coursetag_more_large{font-size:120%}#page-tag-coursetags_more
.coursetag_more_small{font-size:80%}#page-tag-coursetags_more
.coursetag_more_link{font-size:80%}#tag-description,#tag-blogs{width:100%}#tag-management-box{margin-bottom:10px;line-height:20px}#tag-user-table{width:100%;padding:3px;clear:both}#tag-user-table{*zoom:1}#tag-user-table:before,#tag-user-table:after{display:table;line-height:0;content:""}#tag-user-table:after{clear:both}img.user-image{width:100px;height:100px}#small-tag-cloud-box{width:300px;margin:0
auto}#big-tag-cloud-box{float:none;width:600px;margin:0
auto}ul#tag-cloud-list{padding:5px;margin:0;list-style:none}ul#tag-cloud-list
li{display:inline;margin:0;list-style-type:none}#tag-search-box{margin:10px
auto;text-align:center}#tag-search-results-container{width:100%;padding:0}#tag-search-results{display:block;float:left;width:60%;padding:0;margin:15px
20% 0 20%}#tag-search-results
li{float:left;width:30%;padding-right:1%;padding-left:1%;line-height:20px;text-align:left;list-style:none}span.flagged-tag,span.flagged-tag
a{color:#b94a48}table#tag-management-list{width:100%;text-align:left}table#tag-management-list td,table#tag-management-list
th{padding:4px;text-align:left;vertical-align:middle}.tag-management-form{text-align:center}#relatedtags-autocomplete-container{width:100%;min-height:4.6em;margin-right:auto;margin-left:auto}#relatedtags-autocomplete{position:relative;display:block;width:60%;margin-right:auto;margin-left:auto}#relatedtags-autocomplete .yui-ac-content{position:absolute;left:20%;z-index:9050;width:420px;overflow:hidden;background:#fff;border:1px
solid rgba(0,0,0,0.2)}#relatedtags-autocomplete
.ysearchquery{position:absolute;right:10px;z-index:10;color:#808080}#relatedtags-autocomplete .yui-ac-shadow{position:absolute;z-index:9049;width:100%;margin:.3em;background:#a0a0a0}#relatedtags-autocomplete
ul{width:100%;padding:0;margin:0;list-style-type:none}#relatedtags-autocomplete
li{padding:0
5px;white-space:nowrap;cursor:default}#relatedtags-autocomplete li.yui-ac-highlight{color:#fff;background:#0070a8}h2.tag-heading,div#tag-description,div#tag-blogs,body.tag
.managelink{padding:5px}.tag_cloud
.s20{font-size:1.5em;font-weight:bold}.tag_cloud
.s19{font-size:1.5em}.tag_cloud
.s18{font-size:1.4em;font-weight:bold}.tag_cloud
.s17{font-size:1.4em}.tag_cloud
.s16{font-size:1.3em;font-weight:bold}.tag_cloud
.s15{font-size:1.3em}.tag_cloud
.s14{font-size:1.2em;font-weight:bold}.tag_cloud
.s13{font-size:1.2em}.tag_cloud .s12,.tag_cloud
.s11{font-size:1.1em;font-weight:bold}.tag_cloud .s10,.tag_cloud
.s9{font-size:1.1em}.tag_cloud .s8,.tag_cloud
.s7{font-size:1em;font-weight:bold}.tag_cloud .s6,.tag_cloud
.s5{font-size:1em}.tag_cloud .s4,.tag_cloud
.s3{font-size:.9em;font-weight:bold}.tag_cloud .s2,.tag_cloud
.s1{font-size:.9em}.tag_cloud
.s0{font-size:.8em}#webservice-doc-generator
td{text-align:left;border:0
solid black}.smartselect{position:absolute}.smartselect
.smartselect_mask{background-color:#fff}.smartselect
ul{padding:0;margin:0}.smartselect ul
li{list-style:none}.smartselect
.smartselect_menu{margin-right:5px}.safari .smartselect
.smartselect_menu{margin-left:2px}.smartselect .smartselect_menu,.smartselect
.smartselect_submenu{display:none;background-color:#FFF;border:1px
solid #000}.smartselect .smartselect_menu.visible,.smartselect
.smartselect_submenu.visible{display:block}.smartselect .smartselect_menu_content ul
li{position:relative;padding:2px
5px}.smartselect .smartselect_menu_content ul li
a{color:#333;text-decoration:none}.smartselect .smartselect_menu_content ul li
a.selectable{color:inherit}.smartselect
.smartselect_submenuitem{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed);background-position:100%;background-repeat:no-repeat}.smartselect.spanningmenu
.smartselect_submenu{position:absolute;top:-1px;left:100%}.smartselect.spanningmenu .smartselect_submenu
a{padding-right:16px;white-space:nowrap}.smartselect.spanningmenu .smartselect_menu_content ul li a.selectable:hover{text-decoration:underline}.smartselect.compactmenu
.smartselect_submenu{position:relative;z-index:1010;display:none;margin:2px
-3px;margin-left:10px;border-width:0}.smartselect.compactmenu
.smartselect_submenu.visible{display:block}.smartselect.compactmenu
.smartselect_menu{z-index:1000;overflow:hidden}.smartselect.compactmenu .smartselect_submenu
.smartselect_submenu{z-index:1020}.smartselect.compactmenu .smartselect_submenuitem:hover>.smartselect_menuitem_label{font-weight:bold}#page-admin-registration-register
.registration_textfield{width:300px}.userenrolment{width:100%;border-collapse:collapse}.userenrolment
tr{vertical-align:top}.userenrolment
td{height:41px;padding:0}.userenrolment
.subfield{margin-right:5px}.userenrolment .col_userdetails
.subfield_picture{float:left}.userenrolment
.col_lastseen{width:150px}.userenrolment
.col_role{width:262px}.userenrolment .col_role .roles,.userenrolment .col_group
.groups{margin-right:30px}.userenrolment .col_role .role,.userenrolment .col_group
.group{float:left;padding:3px;margin:3px;white-space:nowrap}.userenrolment .col_role .role a,.userenrolment .col_group .group
a{margin-left:3px;cursor:pointer}.userenrolment .col_role .addrole,.userenrolment .col_group
.addgroup{float:right;padding:3px;margin:3px}.userenrolment .col_role .addrole>*:hover,.userenrolment .col_group .addgroup>*:hover{border-bottom:1px solid #666}.userenrolment .col_role .addrole img,.userenrolment .col_group .addgroup
img{vertical-align:baseline}.dir-rtl .userenrolment .col_role
.role{float:right}.userenrolment .hasAllRoles .col_role
.addrole{display:none}.userenrolment .col_enrol
.enrolment{float:left;padding:3px;margin:3px}.userenrolment .col_enrol .enrolment
a{float:right;margin-left:3px}#page-enrol-users
.enrol_user_buttons{float:right}#page-enrol-users .enrol_user_buttons
.enrolusersbutton{display:inline}#page-enrol-users .enrol_user_buttons .enrolusersbutton div,#page-enrol-users .enrol_user_buttons .enrolusersbutton
form{display:inline;margin-right:0}#page-enrol-users
#filterform{display:inline-block;min-height:20px;padding:19px;padding:9px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-webkit-border-radius:3px;-moz-border-radius:4px;-moz-border-radius:3px;border-radius:4px;border-radius:3px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}#page-enrol-users #filterform
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}#page-enrol-users #filterform
.fitem{display:inline-block;margin-right:.3em;line-height:40px;white-space:nowrap}#page-enrol-users #filterform .fitem
label{display:inline;padding-right:.3em;line-height:20px}#page-enrol-users #filterform .fitem :before,#page-enrol-users #filterform .fitem:after{display:inline}#page-enrol-users #filterform div,#page-enrol-users #filterform
fieldset{display:inline;float:none;width:auto;margin:0;clear:none}#page-enrol-users #filterform select,#page-enrol-users #filterform .ftext
input{width:7em}#page-enrol-users #filterform input,#page-enrol-users #filterform
select{margin-bottom:0}#page-enrol-users .user-enroller-panel .uep-search-results .user
.details{width:237px}.dir-rtl#page-enrol-users .col_userdetails
.subfield_picture{float:right}.dir-rtl#page-enrol-users
.enrol_user_buttons{float:left}.dir-rtl#page-enrol-users .enrol_user_buttons
.enrolusersbutton{margin-right:1em;margin-left:0}.dir-rtl#page-enrol-users .enrol_user_buttons .enrolusersbutton
div{margin-left:0}.dir-rtl#page-enrol-users #filterform
.fitem{margin-right:0;margin-left:.3em}.dir-rtl#page-enrol-users #filterform .fitem
label{padding-right:0;padding-left:.3em}.dir-rtl
.headermain{float:right}.dir-rtl
.headermenu{float:left}.dir-rtl .loginbox .loginform .form-label{float:right;text-align:left}.dir-rtl .loginbox .loginform .form-input{text-align:right}.dir-rtl .yui3-menu-hidden{left:0}#page-admin-roles-define.dir-rtl #rolesform
.felement{margin-right:180px}#page-message-edit.dir-rtl table.generaltable
th.c0{text-align:right}.corelightbox{position:absolute;top:0;left:0;width:100%;height:100%;text-align:center;background-color:#CCC}.corelightbox
img{position:fixed;top:50%;left:50%}.mod-indent-outer{display:table}.mod-indent{display:table-cell}.label .mod-indent{float:left;padding-top:20px}.mod-indent-1{width:30px}.mod-indent-2{width:60px}.mod-indent-3{width:90px}.mod-indent-4{width:120px}.mod-indent-5{width:150px}.mod-indent-6{width:180px}.mod-indent-7{width:210px}.mod-indent-8{width:240px}.mod-indent-9{width:270px}.mod-indent-10{width:300px}.mod-indent-11{width:330px}.mod-indent-12{width:360px}.mod-indent-13{width:390px}.mod-indent-14{width:420px}.mod-indent-15,.mod-indent-huge{width:420px}.resourcecontent .mediaplugin_mp3
object{width:600px;height:25px}.resourcecontent
audio.mediaplugin_html5audio{width:600px}.resourceimage{max-width:100%}.mediaplugin_mp3
object{width:300px;height:15px}audio.mediaplugin_html5audio{width:300px}.core_media_preview.pagelayout-embedded
#content{padding:0}.core_media_preview.pagelayout-embedded
#maincontent{height:0}body#page-lib-editor-tinymce-plugins-moodlemedia-preview{min-width:0;padding:0;margin:0;background:0}.dir-rtl .ygtvtn,.dir-rtl .ygtvtm,.dir-rtl .ygtvtmh,.dir-rtl .ygtvtmhh,.dir-rtl .ygtvtp,.dir-rtl .ygtvtph,.dir-rtl .ygtvtphh,.dir-rtl .ygtvln,.dir-rtl .ygtvlm,.dir-rtl .ygtvlmh,.dir-rtl .ygtvlmhh,.dir-rtl .ygtvlp,.dir-rtl .ygtvlph,.dir-rtl .ygtvlphh,.dir-rtl .ygtvdepthcell,.dir-rtl .ygtvok,.dir-rtl .ygtvok:hover,.dir-rtl .ygtvcancel,.dir-rtl .ygtvcancel:hover{width:18px;height:22px;cursor:pointer;background-image:url(/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=yui2-treeview-sprite-rtl);background-repeat:no-repeat}.dir-rtl
.ygtvtn{background-position:0 -5600px}.dir-rtl
.ygtvtm{background-position:0 -4000px}.dir-rtl .ygtvtmh,.dir-rtl
.ygtvtmhh{background-position:0 -4800px}.dir-rtl
.ygtvtp{background-position:0 -6400px}.dir-rtl .ygtvtph,.dir-rtl
.ygtvtphh{background-position:0 -7200px}.dir-rtl
.ygtvln{background-position:0 -1600px}.dir-rtl
.ygtvlm{background-position:0 0}.dir-rtl .ygtvlmh,.dir-rtl
.ygtvlmhh{background-position:0 -800px}.dir-rtl
.ygtvlp{background-position:0 -2400px}.dir-rtl .ygtvlph,.dir-rtl
.ygtvlphh{background-position:0 -3200px}.dir-rtl
.ygtvdepthcell{background-position:0 -8000px}.dir-rtl
.ygtvok{background-position:0 -8800px}.dir-rtl .ygtvok:hover{background-position:0 -8844px}.dir-rtl
.ygtvcancel{background-position:0 -8822px}.dir-rtl .ygtvcancel:hover{background-position:0 -8866px}.dir-rtl.yui-skin-sam .yui-panel
.hd{text-align:right}.dir-rtl .yui-skin-sam .yui-layout .yui-layout-unit div.yui-layout-bd{text-align:right}.dir-rtl .clearlooks2.ie9 .mceAlert .mceMiddle span,.dir-rtl .clearlooks2 .mceConfirm .mceMiddle
span{top:44px}.dir-rtl .o2k7Skin table,.dir-rtl .o2k7Skin tbody,.dir-rtl .o2k7Skin a,.dir-rtl .o2k7Skin img,.dir-rtl .o2k7Skin tr,.dir-rtl .o2k7Skin div,.dir-rtl .o2k7Skin td,.dir-rtl .o2k7Skin iframe,.dir-rtl .o2k7Skin span,.dir-rtl .o2k7Skin *,.dir-rtl .o2k7Skin .mceText,.dir-rtl .o2k7Skin .mceListBox
.mceText{text-align:right}.path-rating
.ratingtable{width:100%;margin-bottom:1em}.path-rating .ratingtable
th.rating{width:100%}.path-rating .ratingtable td.rating,.path-rating .ratingtable
td.time{text-align:center;white-space:nowrap}.initialbar a,.initialbar
strong{padding-right:3px;padding-left:3px}.moodle-dialogue-base .moodle-dialogue-lightbox{background-color:#AAA}.moodle-dialogue-base .hidden,.moodle-dialogue-base .moodle-dialogue-hidden{display:none}.no-scrolling{overflow:hidden}.moodle-dialogue-base .moodle-dialogue-fullscreen{position:fixed;top:0;right:0;bottom:-50px;left:0}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-content{overflow:auto}.moodle-dialogue-base .moodle-dialogue-fullscreen
.closebutton{width:28px;height:16px;background-size:100%}.moodle-dialogue-base .moodle-dialogue{z-index:600;padding:0;margin:0;background:0;border:0;outline:#000 dotted 0}.moodle-dialogue-base .moodle-dialogue-wrap{margin-top:-3px;margin-left:-3px;background-color:#fff;border:1px
solid #ccc;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd,.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd.yui3-widget-hd{padding:5px;margin:0;font-size:12px;font-weight:normal;letter-spacing:1px;color:#333;text-align:center;text-shadow:1px 1px 1px #fff;background:#ccc;background-color:#ebebeb;background-image:-moz-linear-gradient(top,#fff,#ccc);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#ccc));background-image:-webkit-linear-gradient(top,#fff,#ccc);background-image:-o-linear-gradient(top,#fff,#ccc);background-image:linear-gradient(to bottom,#fff,#ccc);background-repeat:repeat-x;border-bottom:1px solid #bbb;-webkit-border-radius:10px 10px 0 0;-moz-border-radius:10px 10px 0 0;border-radius:10px 10px 0 0;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffcccccc',GradientType=0);filter:0}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd
h1{display:inline;padding:0;margin:0;font-size:100%;font-weight:bold}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd .yui3-widget-buttons{padding:5px}.moodle-dialogue-base
.closebutton{display:inline-block;float:right;width:25px;height:15px;padding:0;vertical-align:middle;cursor:pointer;background-image:url(/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=sprite);background-repeat:no-repeat;border-style:none}.dir-rtl .moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd .yui3-widget-buttons{right:auto;left:0}.moodle-dialogue-base .moodle-dialogue .moodle-dialogue-bd{padding:1em;font-size:12px;line-height:2em;color:#555}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-content{padding:0;background:#FFF}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-hd{padding:10px;font-size:16px}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-content{position:absolute;top:0;right:0;bottom:50px;left:0;margin:0;overflow:auto;border:0}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-hd,.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-wrap{border-radius:0}.moodle-dialogue-confirm .confirmation-dialogue{text-align:center}.moodle-dialogue-confirm .confirmation-dialogue
input{text-align:center}.moodle-dialogue-exception .moodle-exception-message{text-align:center}.moodle-dialogue-exception .moodle-exception-param
label{font-weight:bold}.moodle-dialogue-exception .param-stacktrace
label{background-color:#EEE;border:1px
solid #ccc;border-bottom-width:0}.moodle-dialogue-exception .param-stacktrace
pre{background-color:#fff;border:1px
solid #ccc}.moodle-dialogue-exception .param-stacktrace .stacktrace-file{font-size:11.9px;color:navy}.moodle-dialogue-exception .param-stacktrace .stacktrace-line{font-size:11.9px;color:#b94a48}.moodle-dialogue-exception .param-stacktrace .stacktrace-call{font-size:90%;color:#333;border-bottom:1px solid #eee}.moodle-dialogue-base .moodle-dialogue .moodle-dialogue-content .moodle-dialogue-ft{padding:0;margin:.7em 1em;font-size:12px;text-align:right;background-color:#FFF}.moodle-dialogue-confirm .confirmation-message{margin:.5em 1em}.moodle-dialogue-confirm .confirmation-dialogue
input{min-width:80px}.moodle-dialogue-exception .moodle-exception-message{margin:1em}.moodle-dialogue-exception .moodle-exception-param{margin-bottom:.5em}.moodle-dialogue-exception .moodle-exception-param
label{width:150px}.moodle-dialogue-exception .param-stacktrace
label{display:block;padding:4px
1em;margin:0}.moodle-dialogue-exception .param-stacktrace
pre{display:block;height:200px;overflow:auto}.moodle-dialogue-exception .param-stacktrace .stacktrace-file{display:inline-block;margin:4px
0}.moodle-dialogue-exception .param-stacktrace .stacktrace-line{display:inline-block;width:50px;margin:4px
1em}.moodle-dialogue-exception .param-stacktrace .stacktrace-call{padding-bottom:4px;padding-left:25px;margin-bottom:4px}.moodle-dialogue .moodle-dialogue-bd .content-lightbox{top:0;left:0;width:100%;height:100%;padding:10% 0;text-align:center;background-color:white;opacity:.75;filter:alpha(opacity=75)}.moodle-dialogue
.tooltiptext{max-height:300px}.moodle-dialogue-base .moodle-dialogue.moodle-dialogue-tooltip{z-index:3001}.moodle-dialogue-base .moodle-dialogue.moodle-dialogue-tooltip .moodle-dialogue-bd{overflow:auto}#page-question-edit.dir-rtl a.container-close{right:auto;left:6px}.chooserdialoguebody,.choosertitle{display:none}.moodle-dialogue.chooserdialogue .moodle-dialogue-content .moodle-dialogue-ft{margin:0}.chooserdialogue .moodle-dialogue-wrap .moodle-dialogue-bd{padding:0;background:#f2f2f2;-webkit-border-bottom-right-radius:10px;border-bottom-right-radius:10px;-webkit-border-bottom-left-radius:10px;border-bottom-left-radius:10px;-moz-border-radius-bottomright:10px;-moz-border-radius-bottomleft:10px}.choosercontainer #chooseform
.submitbuttons{padding:.7em 0;text-align:center}@media(max-height:639px){.ios.safari .choosercontainer #chooseform
.submitbuttons{padding:45px
0}}.choosercontainer #chooseform .submitbuttons
input{min-width:100px;margin:0
.5em}.choosercontainer #chooseform
.options{position:relative;border-bottom:1px solid #bbb}.jschooser .choosercontainer #chooseform
.alloptions{max-width:20.3em;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:inset 0 0 30px 0 #ccc;-moz-box-shadow:inset 0 0 30px 0 #ccc;box-shadow:inset 0 0 30px 0 #ccc}.dir-rtl.jschooser .choosercontainer #chooseform
.alloptions{max-width:18.3em}.choosercontainer #chooseform .moduletypetitle,.choosercontainer #chooseform .option,.choosercontainer #chooseform
.nonoption{padding:0
1.6em 0 1.6em;margin-bottom:0}.choosercontainer #chooseform
.moduletypetitle{padding-top:1.2em;padding-bottom:.4em;text-transform:uppercase}.choosercontainer #chooseform .option .typename,.choosercontainer #chooseform .option span.modicon img.icon,.choosercontainer #chooseform .nonoption .typename,.choosercontainer #chooseform .nonoption span.modicon
img.icon{padding:0
0 0 .5em}.dir-rtl .choosercontainer #chooseform .option .typename,.dir-rtl .choosercontainer #chooseform .option span.modicon img.icon,.dir-rtl .choosercontainer #chooseform .nonoption .typename,.dir-rtl .choosercontainer #chooseform .nonoption span.modicon
img.icon{padding:0
.5em 0 0}.chooserdialogue-course-modchooser .choosercontainer #chooseform .option span.modicon img.icon,.chooserdialogue-course-modchooser .choosercontainer #chooseform .nonoption span.modicon
img.icon{width:24px;height:24px}.choosercontainer #chooseform .option input[type=radio],.choosercontainer #chooseform .option span.typename,.choosercontainer #chooseform .option
span.modicon{vertical-align:middle}.choosercontainer #chooseform .option
label{display:block;padding:.3em 0 .1em 0;border-bottom:1px solid #fff}.choosercontainer #chooseform
.nonoption{padding-top:.3em;padding-bottom:.1em;padding-left:2.7em}.dir-rtl .choosercontainer #chooseform
.nonoption{padding-right:2.7em;padding-left:0}.choosercontainer #chooseform
.subtype{padding:0
1.6em 0 3.2em;margin-bottom:0}.dir-rtl .choosercontainer #chooseform
.subtype{padding:0
3.2em 0 1.6em}.choosercontainer #chooseform .subtype
.typename{margin:0
0 0 .2em}.dir-rtl .choosercontainer #chooseform .subtype
.typename{margin:0
.2em 0 0}.jschooser .choosercontainer #chooseform .instruction,.jschooser .choosercontainer #chooseform
.typesummary{position:absolute;top:0;right:0;bottom:0;left:20.3em;display:none;padding:1.6em;margin:0;overflow-x:hidden;overflow-y:auto;line-height:2em;background-color:#fff}.dir-rtl.jschooser .choosercontainer #chooseform .instruction,.dir-rtl.jschooser .choosercontainer #chooseform
.typesummary{right:18.5em;left:0;border-right:1px solid grey}.jschooser .choosercontainer #chooseform .instruction,.choosercontainer #chooseform .selected
.typesummary{display:block}.choosercontainer #chooseform
.selected{background-color:#fff;-webkit-box-shadow:0 0 10px 0 #ccc;-moz-box-shadow:0 0 10px 0 #ccc;box-shadow:0 0 10px 0 #ccc}.section-modchooser-link
img.smallicon{padding:3px}.formlistingradio{padding-right:10px;padding-bottom:25px}.formlistinginputradio{float:left}.formlistingmain{min-height:225px}.formlisting{position:relative;padding:1px
19px 14px;margin:15px
0;background-color:white;border:1px
solid #DDD;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.formlistingmore{position:absolute;right:-1px;bottom:-1px;padding:3px
7px;font-size:12px;font-weight:bold;color:#9da0a4;cursor:pointer;background-color:whiteSmoke;border:1px
solid #ddd;-webkit-border-radius:4px 0 4px 0;-moz-border-radius:4px 0 4px 0;border-radius:4px 0 4px 0}.formlistingall{padding:0;margin:15px
0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.formlistingrow{top:50%;left:50%;float:left;width:150px;min-height:34px;padding:6px;cursor:pointer;background-color:#f7f7f9;border-right:1px solid #e1e1e8;border-bottom:1px solid;border-left:1px solid #e1e1e8;border-color:#e1e1e8;-webkit-border-radius:0 0 4px 4px;-moz-border-radius:0 0 4px 4px;border-radius:0 0 4px 4px}body.jsenabled
.formlistingradio{display:none}body.jsenabled
.formlisting{display:block}table.collection{width:100%;margin-bottom:20px;border:1px
solid #ddd;border-collapse:separate;*border-collapse:collapse;border-left:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}table.collection th,table.collection
td{padding:8px;line-height:20px;text-align:left;vertical-align:top;border-top:1px solid #ddd}table.collection
th{font-weight:bold}table.collection thead
th{vertical-align:bottom}table.collection caption+thead tr:first-child th,table.collection caption+thead tr:first-child td,table.collection colgroup+thead tr:first-child th,table.collection colgroup+thead tr:first-child td,table.collection thead:first-child tr:first-child th,table.collection thead:first-child tr:first-child
td{border-top:0}table.collection tbody+tbody{border-top:2px solid #ddd}table.collection
.table{background-color:#fff}table.collection th,table.collection
td{border-left:1px solid #ddd}table.collection caption+thead tr:first-child th,table.collection caption+tbody tr:first-child th,table.collection caption+tbody tr:first-child td,table.collection colgroup+thead tr:first-child th,table.collection colgroup+tbody tr:first-child th,table.collection colgroup+tbody tr:first-child td,table.collection thead:first-child tr:first-child th,table.collection tbody:first-child tr:first-child th,table.collection tbody:first-child tr:first-child
td{border-top:0}table.collection thead:first-child tr:first-child>th:first-child,table.collection tbody:first-child tr:first-child>td:first-child,table.collection tbody:first-child tr:first-child>th:first-child{-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topleft:4px}table.collection thead:first-child tr:first-child>th:last-child,table.collection tbody:first-child tr:first-child>td:last-child,table.collection tbody:first-child tr:first-child>th:last-child{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-moz-border-radius-topright:4px}table.collection thead:last-child tr:last-child>th:first-child,table.collection tbody:last-child tr:last-child>td:first-child,table.collection tbody:last-child tr:last-child>th:first-child,table.collection tfoot:last-child tr:last-child>td:first-child,table.collection tfoot:last-child tr:last-child>th:first-child{-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px}table.collection thead:last-child tr:last-child>th:last-child,table.collection tbody:last-child tr:last-child>td:last-child,table.collection tbody:last-child tr:last-child>th:last-child,table.collection tfoot:last-child tr:last-child>td:last-child,table.collection tfoot:last-child tr:last-child>th:last-child{-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px}table.collection tfoot+tbody:last-child tr:last-child td:first-child{-webkit-border-bottom-left-radius:0;border-bottom-left-radius:0;-moz-border-radius-bottomleft:0}table.collection tfoot+tbody:last-child tr:last-child td:last-child{-webkit-border-bottom-right-radius:0;border-bottom-right-radius:0;-moz-border-radius-bottomright:0}table.collection caption+thead tr:first-child th:first-child,table.collection caption+tbody tr:first-child td:first-child,table.collection colgroup+thead tr:first-child th:first-child,table.collection colgroup+tbody tr:first-child td:first-child{-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topleft:4px}table.collection caption+thead tr:first-child th:last-child,table.collection caption+tbody tr:first-child td:last-child,table.collection colgroup+thead tr:first-child th:last-child,table.collection colgroup+tbody tr:first-child td:last-child{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-moz-border-radius-topright:4px}table.collection tbody>tr:nth-child(odd)>td,table.collection tbody>tr:nth-child(odd)>th{background-color:#f9f9f9}table.collection
.name{text-align:left;vertical-align:middle}table.collection
.awards{width:10%;text-align:center;vertical-align:middle}table.collection
.criteria{width:40%;text-align:left;vertical-align:top}table.collection .badgeimage,table.collection
.status{width:15%;text-align:center;vertical-align:middle}table.collection
.description{width:25%;text-align:left}table.collection
.actions{width:11em;text-align:center;vertical-align:middle}a.criteria-action{float:right;padding:0
3px}table.issuedbadgebox{width:750px;background-color:#f5f5f5}table.badgeissuedimage{width:150px;text-align:center}table.badgeissuedinfo{width:600px}table.badgeissuedinfo
.bvalue{text-align:left;vertical-align:middle}table.badgeissuedinfo
.bfield{width:125px;font-style:italic;text-align:left}.dir-rtl table.badgeissuedinfo .bvalue,.dir-rtl table.badgeissuedinfo
.bfield{text-align:right}ul.badges{margin:0;list-style:none}.badges
li{position:relative;display:inline-block;width:150px;padding-bottom:2em;text-align:center;vertical-align:top}.badges li .badge-name{display:block;padding:5px}.badges li>img{position:absolute}.badges li .badge-image{top:0;left:10px;z-index:1;width:90px;height:90px}.badges li .badge-actions{position:relative}div.badge{position:relative;display:block}div.badge
.expireimage{top:0;left:20px;width:100px;height:100px}.expireimage{position:absolute;top:0;left:30px;z-index:10;width:90px;height:90px;opacity:.85;filter:alpha(opacity=85)}.badge-profile{vertical-align:top}.connected{color:#468847}.notconnected{color:#b94a48}.connecting{color:#c09853}#page-badges-award .recipienttable tr
td{vertical-align:top}#page-badges-award .recipienttable tr td.actions
.actionbutton{width:100%;padding:.5em 0;margin:.3em 0}#page-badges-award .recipienttable tr td.existing,#page-badges-award .recipienttable tr
td.potential{width:42%}.statustable{margin-bottom:0}.statusbox.active{background-color:#dff0d8}.statusbox.inactive{background-color:#fcf8e3}.activatebadge{margin:0;text-align:left;vertical-align:middle}.dir-rtl
.activatebadge{text-align:right}img#persona_signin{cursor:pointer}.addcourse{float:right}.invisiblefieldset{display:inline;padding:0;margin:0;border-width:0}.breadcrumb-nav{float:left;margin-bottom:10px}.dir-rtl .breadcrumb-nav{float:right}.breadcrumb-button .singlebutton
div{margin-right:0}.breadcrumb-nav
.breadcrumb{margin:0}.moodle-actionmenu,.moodle-actionmenu>ul,.moodle-actionmenu>ul>li{display:inline-block}.moodle-actionmenu
ul{padding:0;margin:0;list-style-type:none}.moodle-actionmenu .toggle-display,.moodle-actionmenu .menu-action-text{display:none}.jsenabled .moodle-actionmenu[data-enhance]{display:block}.jsenabled .moodle-actionmenu[data-enhance] .menu{display:none}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display{display:inline;opacity:.5;filter:alpha(opacity=50)}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu{display:block;padding-right:4px;padding-left:4px;margin-left:4px}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.iconsmall{padding:8px
4px 0 2px;margin:4px
4px 4px 0;vertical-align:text-bottom}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-top:8px;margin-left:2px;border-top-color:#777}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu .caret:hover,.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu .caret:active{border-top-color:#555}.jsenabled .moodle-actionmenu[data-enhanced] .toggle-display{opacity:1;filter:alpha(opacity=100)}.jsenabled .moodle-actionmenu[data-enhanced] .menu-action-text{display:inline}.jsenabled.dir-rtl .moodle-actionmenu[data-enhance] .toggle-display.textmenu{margin-right:4px;margin-left:initial}.jsenabled.dir-rtl .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-right:2px;margin-left:initial}.moodle-actionmenu[data-enhanced].show{position:relative}.moodle-actionmenu[data-enhanced].show
.menu{position:absolute;z-index:1000;display:block;text-align:left;background-color:#fff;border:1px
solid rgba(0,0,0,0.2);-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}.moodle-actionmenu[data-enhanced].show .menu
a{display:block;padding:2px
1em 2px 28px;color:#333}.moodle-actionmenu[data-enhanced].show .menu a:hover{color:#fff;background-color:#0070a8}.moodle-actionmenu[data-enhanced].show .menu a:first-child{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topright:4px;-moz-border-radius-topleft:4px}.moodle-actionmenu[data-enhanced].show .menu a:last-child{-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-moz-border-radius-bottomright:4px;-moz-border-radius-bottomleft:4px}.moodle-actionmenu[data-enhanced].show .menu
a.hidden{display:none}.moodle-actionmenu[data-enhanced].show .menu
img{vertical-align:middle}.moodle-actionmenu[data-enhanced].show .menu
.iconsmall{margin:4px
4px 4px -24px}.moodle-actionmenu[data-enhanced].show .menu>li{display:block}.moodle-actionmenu[data-enhanced].show .menu.align-tl-bl{top:100%;left:0;margin-top:4px}.moodle-actionmenu[data-enhanced].show .menu.align-tr-bl{top:100%;right:100%}.moodle-actionmenu[data-enhanced].show .menu.align-bl-bl{bottom:100%;left:0}.moodle-actionmenu[data-enhanced].show .menu.align-br-bl{right:100%;bottom:100%}.moodle-actionmenu[data-enhanced].show .menu.align-tl-br{top:100%;left:100%}.moodle-actionmenu[data-enhanced].show .menu.align-tr-br{top:100%;right:0;margin-top:4px}.moodle-actionmenu[data-enhanced].show .menu.align-bl-br{bottom:100%;left:100%}.moodle-actionmenu[data-enhanced].show .menu.align-br-br{right:0;bottom:100%}.moodle-actionmenu[data-enhanced].show .menu.align-tl-tl{top:0;left:0}.moodle-actionmenu[data-enhanced].show .menu.align-tr-tl{top:0;right:100%;margin-right:4px}.moodle-actionmenu[data-enhanced].show .menu.align-bl-tl{bottom:100%;left:0;margin-bottom:4px}.moodle-actionmenu[data-enhanced].show .menu.align-br-tl{right:100%;bottom:100%}.moodle-actionmenu[data-enhanced].show .menu.align-tl-tr{top:0;left:100%;margin-left:4px}.moodle-actionmenu[data-enhanced].show .menu.align-tr-tr{top:0;right:0}.moodle-actionmenu[data-enhanced].show .menu.align-bl-tr{bottom:100%;left:100%}.moodle-actionmenu[data-enhanced].show .menu.align-br-tr{right:0;bottom:100%;margin-bottom:4px}.block .moodle-actionmenu{text-align:right}.dir-rtl .moodle-actionmenu[data-enhanced].show
.menu{right:auto;left:0;text-align:right}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu
.iconsmall{margin-right:0;margin-left:8px}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-bl{right:0;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-bl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-bl{right:0;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-bl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-br{right:100%;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-br{right:auto;left:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-br{right:100%;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-br{right:auto;left:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-tl{right:0;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-tl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-tl{right:0;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-tl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-tr{right:100%;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-tr{right:auto;left:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-tr{right:100%;left:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-tr{right:auto;left:0}.dir-rtl .block .moodle-actionmenu{text-align:right}ul.dragdrop-keyboard-drag
li{list-style-type:none}.block-control-actions .moodle-core-dragdrop-draghandle
img{width:12px;height:12px}a.disabled:hover,a.disabled{font-style:italic;color:#808080;text-decoration:none;cursor:default}body.lockscroll{height:100%;overflow:hidden}.dir-rtl ul,.dir-rtl
ol{margin-right:25px;margin-left:0}.formtable tbody
th{font-weight:normal;text-align:right}.path-admin
#assignrole{width:60%;margin-right:auto;margin-left:auto}.path-admin .admintable
.leftalign{text-align:left}.environmenttable
p.warn{color:#c09853;background-color:#fcf8e3}.environmenttable .error,.environmenttable span.warn,.environmenttable
.ok{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);white-space:nowrap;vertical-align:baseline;background-color:#999;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.environmenttable .error:empty,.environmenttable span.warn:empty,.environmenttable .ok:empty{display:none}.environmenttable .error-important,.environmenttable span.warn-important,.environmenttable .ok-important{background-color:#b94a48}.environmenttable .error-important[href],.environmenttable span.warn-important[href],.environmenttable .ok-important[href]{background-color:#953b39}.environmenttable .error-warning,.environmenttable span.warn-warning,.environmenttable .ok-warning{background-color:#f89406}.environmenttable .error-warning[href],.environmenttable span.warn-warning[href],.environmenttable .ok-warning[href]{background-color:#c67605}.environmenttable .error-success,.environmenttable span.warn-success,.environmenttable .ok-success{background-color:#468847}.environmenttable .error-success[href],.environmenttable span.warn-success[href],.environmenttable .ok-success[href]{background-color:#356635}.environmenttable .error-info,.environmenttable span.warn-info,.environmenttable .ok-info{background-color:#3a87ad}.environmenttable .error-info[href],.environmenttable span.warn-info[href],.environmenttable .ok-info[href]{background-color:#2d6987}.environmenttable .error-inverse,.environmenttable span.warn-inverse,.environmenttable .ok-inverse{background-color:#333}.environmenttable .error-inverse[href],.environmenttable span.warn-inverse[href],.environmenttable .ok-inverse[href]{background-color:#1a1a1a}.environmenttable
.error{background-color:#b94a48}.environmenttable
span.warn{background-color:#f89406}.environmenttable
.ok{background-color:#468847}.path-admin .admintable.environmenttable .name,.path-admin .admintable.environmenttable .info,.path-admin #assignrole .admintable .role,.path-admin #assignrole .admintable .userrole,.path-admin #assignrole .admintable
.roleholder{white-space:nowrap}.path-admin .incompatibleblockstable
td.c0{font-weight:bold}#page-admin-course-category
.addcategory{padding:10px}#page-admin-course-index
.editcourse{margin:20px
auto}#page-admin-course-index .editcourse th,#page-admin-course-index .editcourse
td{padding-right:10px;padding-left:10px}.timewarninghidden{display:none}.statusok,.statuswarning,.statusserious,.statuscritical{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);white-space:nowrap;vertical-align:baseline;background-color:#999;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.statusok:empty,.statuswarning:empty,.statusserious:empty,.statuscritical:empty{display:none}.statusok-important,.statuswarning-important,.statusserious-important,.statuscritical-important{background-color:#b94a48}.statusok-important[href],.statuswarning-important[href],.statusserious-important[href],.statuscritical-important[href]{background-color:#953b39}.statusok-warning,.statuswarning-warning,.statusserious-warning,.statuscritical-warning{background-color:#f89406}.statusok-warning[href],.statuswarning-warning[href],.statusserious-warning[href],.statuscritical-warning[href]{background-color:#c67605}.statusok-success,.statuswarning-success,.statusserious-success,.statuscritical-success{background-color:#468847}.statusok-success[href],.statuswarning-success[href],.statusserious-success[href],.statuscritical-success[href]{background-color:#356635}.statusok-info,.statuswarning-info,.statusserious-info,.statuscritical-info{background-color:#3a87ad}.statusok-info[href],.statuswarning-info[href],.statusserious-info[href],.statuscritical-info[href]{background-color:#2d6987}.statusok-inverse,.statuswarning-inverse,.statusserious-inverse,.statuscritical-inverse{background-color:#333}.statusok-inverse[href],.statuswarning-inverse[href],.statusserious-inverse[href],.statuscritical-inverse[href]{background-color:#1a1a1a}.statusok{background-color:#468847}.statuswarning{background-color:#c09853}.statusserious{background-color:#f89406}.statuscritical{background-color:#b94a48}#page-admin-report-capability-index
#capabilitysearch{width:30em}#page-admin-report-backups-index .backup-error,#page-admin-report-backups-index .backup-unfinished{color:#b94a48}#page-admin-report-backups-index .backup-skipped,#page-admin-report-backups-index .backup-ok,#page-admin-report-backups-index .backup-notyetrun{color:#468847}#page-admin-report-backups-index .backup-warning{color:#c09853}#page-admin-qtypes .disabled,#page-admin-qbehaviours
.disabled{color:#999}#page-admin-qtypes #qtypes div,#page-admin-qtypes #qtypes form,#page-admin-qbehaviours #qbehaviours div,#page-admin-qbehaviours #qbehaviours
form{display:inline}#page-admin-qtypes #qtypes img.spacer,#page-admin-qbehaviours #qbehaviours
img.spacer{width:16px}img.iconsmall{padding:.3em;margin:0}#page-admin-qbehaviours .cell.c3,#page-admin-qtypes
.cell.c3{font-size:10.5px}#page-admin-lang .generalbox,#page-admin-course-index .singlebutton,#page-admin-course-index .addcategory,#page-course-index .buttons,#page-course-index-category .buttons,#page-admin-course-category .addcategory,#page-admin-stickyblocks .generalbox,#page-admin-maintenance .buttons,#page-admin-course-index .buttons,#page-admin-course-category .buttons,#page-admin-index .copyright,#page-admin-index .copyrightnotice,#page-admin-index .adminerror .singlebutton,#page-admin-index .adminwarning .singlebutton,#page-admin-index #layout-table
.singlebutton{margin-bottom:1em;text-align:center}.path-admin-roles
.capabilitysearchui{margin-right:auto;margin-left:auto;text-align:left}#page-admin-roles-define
.topfields{margin:1em
0 2em}#page-admin-roles-define
.capdefault{background-color:#f5f5f5;border:1px
solid #ddd}#page-filter-manage .backlink,.path-admin-roles
.backlink{margin-top:1em}#page-admin-roles-explain #chooseuser h3,#page-admin-roles-usersroles
.contextname{margin-top:0}#page-admin-roles-explain
#chooseusersubmit{margin-top:0;text-align:center}#page-admin-roles-usersroles
p{margin:0}#page-admin-roles-override .cell.c1,#page-admin-roles-assign .cell.c3,#page-admin-roles-assign
.cell.c1{padding-top:.75em}#page-admin-roles-override .overridenotice,#page-admin-roles-define
.definenotice{margin:1em
10% 2em 10%;text-align:left}#notice{width:60%;min-width:220px;margin:auto}#page-admin-index .releasenoteslink,#page-admin-index .adminwarning,#page-admin-index
.adminerror{width:60%;min-width:220px;padding:8px
35px 8px 14px;margin:auto;margin-bottom:20px;color:#c09853;text-shadow:0 1px 0 rgba(255,255,255,0.5);background-color:#fcf8e3;border:1px
solid #fbeed5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}#page-admin-index
.adminerror{color:#b94a48;background-color:#f2dede;border-color:#eed3d7}#page-admin-index
.releasenoteslink{color:#3a87ad;background-color:#d9edf7;border-color:#bce8f1}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo
span{display:block}#page-admin-index .updateplugin div,#page-admin-plugins .updateplugin
div{margin-bottom:.5em}#page-admin-index .updateplugin .updatepluginconfirmexternal,#page-admin-plugins .updateplugin
.updatepluginconfirmexternal{padding:1em;background-color:#f2dede;border:1px
solid #eed3d7}#page-admin-user-user_bulk #users
.fgroup{white-space:nowrap}#page-admin-report-stats-index
.graph{margin-bottom:1em;text-align:center}#page-admin-report-courseoverview-index
.graph{margin-bottom:1em;text-align:center}#page-admin-lang
.translator{border-style:solid;border-width:1px}.path-admin
.roleassigntable{width:100%}.path-admin .roleassigntable
td{padding:.2em .3em;vertical-align:top}.path-admin .roleassigntable
p{margin:.2em 0;text-align:left}.path-admin .roleassigntable #existingcell,.path-admin .roleassigntable
#potentialcell{width:42%}.path-admin .roleassigntable #existingcell p>label:first-child,.path-admin .roleassigntable #potentialcell p>label:first-child{font-weight:bold}.path-admin .roleassigntable
#buttonscell{width:16%}.path-admin .roleassigntable #buttonscell
#assignoptions{font-size:10.5px}.path-admin .roleassigntable #removeselect_wrapper,.path-admin .roleassigntable
#addselect_wrapper{width:100%}.path-admin table.rolecap tr.rolecap
th{font-weight:normal;text-align:left}.path-admin.dir-rtl table.rolecap tr.rolecap
th{text-align:right}.path-admin .rolecap
.hiddenrow{display:none}.path-admin #defineroletable .rolecap .inherit,.path-admin #defineroletable .rolecap .allow,.path-admin #defineroletable .rolecap .prevent,.path-admin #defineroletable .rolecap
.prohibit{min-width:3.5em;padding:0;text-align:center}.path-admin .rolecap .cap-name,.path-admin .rolecap
.note{display:block;font-size:10.5px;font-weight:normal;white-space:nowrap}.path-admin .rolecap
label{display:block;padding:.5em;margin:0;text-align:center}.plugincheckwrapper{width:100%}.environmentbox{margin-top:1em}#mnetconfig
table{margin-right:auto;margin-left:auto}.environmenttable
.cell{padding:.15em .5em}.environmenttable
img.iconhelp{padding-right:.3em}.dir-rtl .environmenttable
img.iconhelp{padding-right:0;padding-left:.3em}#trustedhosts
.generaltable{width:500px;margin-right:auto;margin-left:auto}#trustedhosts
.standard{width:auto}#adminsettings
legend{display:none}#adminsettings
fieldset.error{margin:.2em 0 .5em 0}#adminsettings fieldset.error
legend{display:block}.dir-rtl #admin-spelllanguagelist textarea,#page-admin-setting-editorsettingstinymce.dir-rtl .form-textarea
textarea{text-align:left;direction:ltr}.adminsettingsflags{float:right}.dir-rtl
.adminsettingsflags{float:left}.adminsettingsflags
label{margin-right:7px}.dir-rtl .adminsettingsflags
label{margin-left:7px}.form-description{clear:right}.dir-rtl .form-description{clear:left}.form-item .form-setting .form-htmlarea{display:inline;width:640px}.form-item .form-setting .form-htmlarea
.htmlarea{display:block;width:640px}.form-item .form-setting .form-multicheckbox
ul{padding:0;margin:7px
0 0 0;list-style:none}.form-item .form-setting
.defaultsnext{display:inline;margin-right:.5em}.dir-rtl .form-item .form-setting
.defaultsnext{margin-right:0;margin-left:.5em}.form-item .form-setting .locked-checkbox{display:inline;margin-right:.2em;margin-left:.5em}.dir-rtl .form-item .form-setting .locked-checkbox{display:inline;margin-right:.5em;margin-left:.2em}.form-item .form-setting .form-password .unmask,.form-item .form-setting .form-defaultinfo{display:inline-block}.form-item .pathok,.form-item
.patherror{margin-left:.5em}#admin-emoticons td
input{width:8em}#admin-emoticons td.c0
input{width:4em}#adminthemeselector .selectedtheme
td.c0{border:1px
solid #000;border-right-width:0}#adminthemeselector .selectedtheme
td.c1{border:1px
solid #000;border-left-width:0}.admin_colourpicker,.admin_colourpicker_preview{display:none}.jsenabled
.admin_colourpicker_preview{display:inline}.jsenabled
.admin_colourpicker{display:block;width:410px;height:102px;margin-bottom:10px}.admin_colourpicker
.loadingicon{margin-left:auto;vertical-align:middle}.admin_colourpicker
.colourdialogue{float:left;border:1px
solid #000}.admin_colourpicker
.previewcolour{margin-left:301px;border:1px
solid #000}.admin_colourpicker
.currentcolour{margin-left:301px;border:1px
solid #000;border-top-width:0}.dir-rtl .form-item .form-setting,.dir-rtl .form-item .form-label,.dir-rtl .form-item .form-description,.dir-rtl.path-admin .roleassigntable
p{text-align:right}#page-admin-index #notice
.checkforupdates{text-align:center}#plugins-check-info{margin:1em;text-align:center}#plugins-check .displayname
.pluginicon{width:16px}#plugins-check .status-new
.status{background-color:#dff0d8}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity200 .info.release,#plugins-check .status-upgrade .status,#plugins-check .status-delete
.status{background-color:#d9edf7}#plugins-control-panel .extension .source,#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity100 .info.release,#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity150 .info.release,.pluginupdateinfo.maturity100,.pluginupdateinfo.maturity150,#plugins-check .extension
.source{background-color:#fcf8e3}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity50 .info.release,.pluginupdateinfo.maturity50,#plugins-check .requires-failed,#plugins-check .missingfromdisk .displayname,#plugins-check .status-missing .status,#plugins-check .status-downgrade
.status{background-color:#f2dede}#plugins-control-panel
.statusmsg{padding:3px;background-color:#eee;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px}#plugins-control-panel .status-missing
.pluginname{background-color:#f2dede}#plugins-control-panel .status-missing
.statusmsg{color:#b94a48}#plugins-control-panel .status-new
.pluginname{background-color:#dff0d8}#plugins-control-panel .status-new
.statusmsg{color:#468847}#plugins-control-panel .disabled
.availability{background-color:#eee}#plugins-check .standard .source,#plugins-check .status-nodb .status,#plugins-check .status-uptodate .status,#plugins-check .requires-ok{color:#999}#plugins-check .requires
ul{margin:0;font-size:10.5px}#plugins-check .status
.pluginupdateinfo{padding:5px
10px;margin:10px;background-color:#d9edf7;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px}#plugins-check .status .pluginupdateinfo span,#plugins-check .status .pluginupdateinfo
a{padding-right:1em}#page-admin-index
.upgradepluginsinfo{text-align:center}#page-admin-plugins
.checkforupdates{margin:0
auto 1em;text-align:center}#plugins-control-panel .requiredby,#plugins-control-panel .pluginname
.componentname{font-size:11.9px;color:#999}#plugins-control-panel .pluginname
.componentname{margin-left:22px}#plugins-overview-filter .filter-item,#plugins-overview-panel
.info{padding:0
10px}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo .separator,#plugins-check .status .pluginupdateinfo .separator,#page-admin-plugins
.separator{border-left:1px dotted #999}#plugins-control-panel .msg
td{text-align:center}#plugins-overview-filter,#plugins-overview-panel{margin:1em
auto;text-align:center}#plugins-overview-panel
.info.updatable{margin-left:10px;font-weight:bold;background-color:#d9edf7;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px}#plugins-overview-filter .filter-item.active{font-weight:bold}#plugins-control-panel .displayname
img.icon{padding-top:0;padding-bottom:0}#plugins-control-panel .uninstall
a{color:#b94a48}#plugins-control-panel .notes
.pluginupdateinfo{padding:5px
10px;margin:10px;background-color:#d9edf7;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px}#plugins-control-panel .notes .pluginupdateinfo span,#plugins-control-panel .notes .pluginupdateinfo
a{padding-right:1em}.dir-rtl #plugins-check
.pluginupdateinfo{text-align:center;direction:ltr}.dir-rtl #plugins-check .rootdir,.dir-rtl #plugins-check .requires-ok{text-align:left;direction:ltr}#page-admin-mnet-peers
.box.deletedhosts{margin-bottom:1em;font-size:11.9px}#page-admin-mnet-peers .mform
.deletedhostinfo{padding:4px;margin-bottom:5px;background-color:#f2dede;border:2px
solid #eed3d7}#core-cache-plugin-summaries table,#core-cache-store-summaries
table{width:100%}#core-cache-lock-summary table,#core-cache-definition-summaries table,#core-cache-mode-mappings
table{margin:0
auto}#core-cache-store-summaries .default-store
td{font-style:italic}#core-cache-rescan-definitions,#core-cache-mode-mappings .edit-link,#core-cache-lock-summary .new-instance{margin-top:.5em;text-align:center}.tinymcesubplugins
img.icon{padding-top:0;padding-bottom:0}.maintenancewarning{position:fixed;right:0;bottom:0;z-index:1;padding:3px
1em;overflow:hidden;text-align:center}.maintenancewarning.error{font-weight:bold;color:#b94a48;background-color:#f2dede;border:2px
solid #eed3d7}.maintenancewarning.warning{color:#c09853;background-color:#fcf8e3;border:2px
solid #fbeed5}#adminsettings .form-overridden{color:#3a87ad;background-color:#d9edf7}.calendar_event_course{background-color:#ffd3bd}.calendar_event_global{background-color:#d6f8cd}.calendar_event_group{background-color:#fee7ae}.calendar_event_user{background-color:#dce7ec}.path-calendar
.calendartable{width:100%}.path-calendar .calendartable th,.path-calendar .calendartable
td{width:14%;text-align:center;vertical-align:top;border:0}.path-calendar .calendar-controls .previous,.path-calendar .calendar-controls .next,.path-calendar .calendar-controls
.current{display:block;float:left;width:12%}.path-calendar .calendar-controls
.previous{text-align:left}.path-calendar .calendar-controls
.current{width:76%;text-align:center}.path-calendar .calendar-controls
.next{text-align:right}.path-calendar .filters
table{width:100%;border-collapse:separate;border-spacing:2px}.path-calendar .cal_courses_flt
label{margin-right:.45em}.path-calendar
.maincalendar{padding:0;vertical-align:top}.path-calendar .maincalendar
.bottom{padding:5px
0 0 0;text-align:center}.path-calendar .maincalendar
.heightcontainer{position:relative;height:100%}.path-calendar .maincalendar
.calendarmonth{width:98%;margin:10px
auto}.path-calendar .maincalendar .calendarmonth
ul{margin:0}.path-calendar .maincalendar .calendarmonth ul
li{margin-top:4px;list-style-type:none}.path-calendar .maincalendar .calendarmonth
td{height:5em}.path-calendar .maincalendar .calendar-controls .previous,.path-calendar .maincalendar .calendar-controls
.next{width:30%}.path-calendar .maincalendar .calendar-controls
.current{width:39.95%}.path-calendar .maincalendar
.controls{width:98%;margin:10px
auto}.path-calendar .maincalendar .calendar_event_course,.path-calendar .maincalendar .calendar_event_global,.path-calendar .maincalendar .calendar_event_group,.path-calendar .maincalendar
.calendar_event_user{border-style:solid;border-width:1px 1px 1px 12px}.path-calendar .maincalendar
.calendar_event_course{border-color:#ffd3bd}.path-calendar .maincalendar
.calendar_event_global{border-color:#d6f8cd}.path-calendar .maincalendar
.calendar_event_group{border-color:#fee7ae}.path-calendar .maincalendar
.calendar_event_user{border-color:#dce7ec}.path-calendar .maincalendar .calendar-event-panel{background-color:#eee;border:2px
solid #eee}.path-calendar .maincalendar .calendar-event-panel .yui3-overlay-content{padding:19px;background-color:#fdfdfd;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.path-calendar .maincalendar .calendar-controls
.current{font-family:inherit;font-size:25px;font-weight:bold;line-height:1.2;color:inherit}.path-calendar .maincalendar .calendartable td,.path-calendar .maincalendar .calendartable
li{padding:5px}.path-calendar .maincalendar .calendartable
li{padding-left:10px;text-align:left}.path-calendar .maincalendar
.header{overflow:hidden}.path-calendar .maincalendar .header
.buttons{float:right}.path-calendar .maincalendar .eventlist
.event{position:relative;width:100%;padding:19px;margin-bottom:20px;background-color:#fdfdfd;border:1px
solid #e3e3e3;border-collapse:separate;border-spacing:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.path-calendar .maincalendar .eventlist .event
.picture{vertical-align:text-top}.path-calendar .maincalendar .eventlist .event .topic
.name{float:left;font-size:17.5px;font-weight:200;line-height:24px}.path-calendar .maincalendar .eventlist .event .topic .name,.path-calendar .maincalendar .eventlist .event .topic
.course{margin-bottom:5px}.path-calendar .maincalendar .eventlist .event .topic
.date{float:right}.path-calendar .maincalendar .eventlist .event .course,.path-calendar .maincalendar .eventlist .event
.subscription{float:left;clear:left}.path-calendar .maincalendar .eventlist .event
.side{width:22px}.path-calendar .maincalendar .eventlist .event
.description{padding:5px;background-color:#fff}.path-calendar .maincalendar .eventlist .event .description
.commands{position:absolute;top:0;right:0;margin:3px}.path-calendar .maincalendar .eventlist .event .commands
a{margin:0
3px}.dir-rtl.path-calendar .cal_courses_flt
label{margin-right:0;margin-left:.45em}.dir-rtl.path-calendar .maincalendar .calendar_event_course,.dir-rtl.path-calendar .maincalendar .calendar_event_global,.dir-rtl.path-calendar .maincalendar .calendar_event_group,.dir-rtl.path-calendar .maincalendar
.calendar_event_user{border-right-width:12px;border-left-width:1px}.dir-rtl.path-calendar .maincalendar .calendar-controls
.next{text-align:left}.dir-rtl.path-calendar .maincalendar .calendar-controls
.previous{text-align:right}.dir-rtl.path-calendar .maincalendar .calendartable td,.dir-rtl.path-calendar .maincalendar .calendartable
li{text-align:right}.dir-rtl.path-calendar .maincalendar .calendartable
li{padding-right:10px;padding-left:5px}.dir-rtl.path-calendar .maincalendar .header
.buttons{float:left}.dir-rtl.path-calendar .maincalendar .eventlist .event .topic
.name{float:right}.dir-rtl.path-calendar .maincalendar .eventlist .event .topic
.date{float:left}.dir-rtl.path-calendar .maincalendar .eventlist .event .description
.commands{right:inherit;left:0}.dir-rtl.path-calendar .maincalendar .eventlist .event .course,.dir-rtl.path-calendar .maincalendar .eventlist .event
.subscription{float:right;clear:right}#page-calendar-export
.indent{padding-left:20px}.block
.minicalendar{width:100%;max-width:280px;margin:0
auto}.block .minicalendar th,.block .minicalendar
td{padding:2px;font-size:.8em;text-align:center}.block .minicalendar
td.weekend{color:#999}.block .calendar-event-panel{background-color:#eee;border:1px
solid #eee}.block .calendar-event-panel .yui3-overlay-content{padding:19px;background-color:#fdfdfd;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.block .calendar-event-panel .yui3-overlay-content
h2.eventtitle{font-size:18px;line-height:1.2}.block .calendar-event-panel .yui3-overlay-content .eventcontent
img{padding-right:5px}.block .calendar-controls .previous,.block .calendar-controls .current,.block .calendar-controls
.next{display:block;float:left}.block .calendar-controls
.previous{width:12%;text-align:left}.block .calendar-controls
.current{width:76%;text-align:center}.block .calendar-controls
.next{width:12%;text-align:right}.block .calendar_filters
ul{margin:0;list-style:none}.block .calendar_filters
li{margin-bottom:.2em}.block .calendar_filters li span
img{padding:0
.2em}.block .calendar_filters
.eventname{padding-left:.2em}.block .content
h3.eventskey{margin-top:.5em}.dir-rtl .block .calendar_filters
.eventname{padding-right:.2em;padding-left:0}.dir-rtl .block .calendar-event-panel .yui3-overlay-content .eventcontent
img{padding-right:0;padding-left:5px}@media(min-width:768px){#page-calender-view .container-fluid{min-width:1024px}}.section_add_menus{text-align:right}.dir-rtl
.section_add_menus{text-align:left}.section_add_menus .horizontal div,.section_add_menus .horizontal
form{display:inline}.section_add_menus
optgroup{font-style:italic;font-weight:normal}.section_add_menus
.urlselect{margin-left:.4em}.dir-rtl .section_add_menus
.urlselect{margin-right:.4em;margin-left:0}.section_add_menus .urlselect
select{margin-left:.2em}.dir-rtl .section_add_menus .urlselect
select{margin-right:.2em;margin-left:0}.section_add_menus .urlselect
img.iconhelp{padding:0;margin:0;vertical-align:text-bottom}.sitetopic
ul.section{margin:0}.course-content
ul.section{margin:1em}.section
.spinner{width:16px;height:16px}.section .activity
.spinner{position:absolute;left:100%;vertical-align:text-bottom}.section .activity
.editing_move{position:absolute;top:0;left:0}.section .activity .mod-indent-outer{padding-left:32px}.section .activity
.actions{position:absolute;top:0;right:0}.section .activity .contentwithoutlink,.section .activity
.activityinstance{display:table-cell;min-width:40%;min-height:2em;padding-right:4px}.section .activity .contentwithoutlink .dimmed img.activityicon,.section .activity .activityinstance .dimmed
img.activityicon{opacity:.5;filter:alpha(opacity=50)}.section .label .contentwithoutlink,.section .label
.activityinstance{display:block;height:inherit;padding-right:32px}.section .label .mod-indent-outer{display:block;padding-left:24px}.section
.filler{display:inline-block;width:16px;height:16px;padding:.3em}.section .activity.editor_displayed a.editing_title,.section .activity.editor_displayed .moodle-actionmenu{display:none}.section .activity.editor_displayed
div.activityinstance{padding-right:initial}.section .activity.editor_displayed div.activityinstance
input{padding-top:initial;padding-bottom:initial;margin-bottom:initial;vertical-align:text-bottom}.dir-rtl .section .activity
.spinner{right:100%;left:auto}.dir-rtl .section .activity .mod-indent-outer{padding-right:32px;padding-left:initial}.dir-rtl .section .activity
.actions{right:auto;left:0}.dir-rtl .section .activity .contentwithoutlink,.dir-rtl .section .activity
.activityinstance{padding-right:initial;padding-left:4px}.dir-rtl.editing .section .activity
.editing_move{right:0;left:auto}.dir-rtl.editing .section .activity.editor_displayed
div.activityinstance{padding-left:initial}.activity
img.activityicon{margin-right:6px;vertical-align:text-bottom}.dir-rtl .section .activity
img.activityicon{margin-right:0;margin-left:6px}.section .activity .activityinstance,.section .activity .activityinstance
div{display:inline-block}.editing .section .activity .contentwithoutlink,.editing .section .activity
.activityinstance{padding-right:200px}.dir-rtl.editing .section .activity .contentwithoutlink,.dir-rtl.editing .section .activity
.activityinstance{padding-right:0;padding-left:200px}.editing_show+.editing_assign,.editing_hide+.editing_assign{margin-left:20px}.section .activity
.commands{display:inline;white-space:nowrap}.section
.activity.modtype_label.label{padding:.2em;font-weight:normal}.section
li.activity{padding:.2em;clear:both}.section .activity .activityinstance
.groupinglabel{padding-left:30px}.dir-rtl .section .activity .activityinstance
.groupinglabel{padding-right:30px}.section .activity .availabilityinfo,.section .activity
.contentafterlink{margin-top:.5em;margin-left:30px}.dir-rtl .section .activity .availabilityinfo,.dir-rtl .section .activity
.contentafterlink{margin-right:30px;margin-left:0}.section .activity .contentafterlink
p{margin:.5em 0}.editing .section .activity:hover,.editing .section .activity.action-menu-shown{background-color:#eee}.course-content
.current{background-color:#d9edf7}.course-content .section-summary{margin-top:5px;list-style:none;border:1px
solid #ddd}.course-content .section-summary .section-title{margin:2px
5px 10px 5px}.course-content .section-summary
.summarytext{margin:2px
5px 2px 5px}.course-content .section-summary .section-summary-activities .activity-count{display:inline-block;margin:3px;font-size:11.9px;color:#999;white-space:nowrap}.course-content .section-summary
.summary{margin-top:5px}.course-content .single-section{margin-top:1em}.course-content .single-section .section-navigation{display:block;padding:.5em;margin-bottom:-0.5em}.course-content .single-section .section-navigation
.title{clear:both;font-size:108%;font-weight:bold}.course-content .single-section .section-navigation .mdl-left{float:left;margin-right:1em;font-weight:normal}.dir-rtl .course-content .single-section .section-navigation .mdl-left{float:right}.course-content .single-section .section-navigation .mdl-left
.larrow{margin-right:.1em}.course-content .single-section .section-navigation .mdl-right{float:right;margin-left:1em;font-weight:normal}.dir-rtl .course-content .single-section .section-navigation .mdl-right{float:left}.course-content .single-section .section-navigation .mdl-right
.rarrow{margin-left:.1em}.course-content .single-section .section-navigation .mdl-bottom{margin-top:0}.course-content ul
li.section.main{margin-top:0;border-bottom:2px solid #ddd}.course-content ul
li.section.hidden{opacity:.5}.course-content ul.topics li.section .content,.course-content ul.weeks li.section
.content{padding:0;margin-right:20px;margin-left:20px}.course-content{margin-top:0}.course-content ul.topics
li.section{padding-bottom:20px}.course-content ul.topics li.section
.summary{margin-left:25px}.path-course-view
.completionprogress{margin-left:25px}.path-course-view
.completionprogress{position:relative;z-index:1000;display:block;float:right;height:20px}#page-site-index
.subscribelink{text-align:right}#site-news-forum h2,#frontpage-course-list h2,#frontpage-category-names h2,#frontpage-category-combo
h2{margin-bottom:9px}.path-course-view a.reduce-sections{padding-left:.2em}.path-course-view
.subscribelink{text-align:right}.path-course-view
.unread{margin-left:30px}.dir-rtl.path-course-view
.unread{margin-right:30px}.path-course-view .block.drag
.header{cursor:move}.path-course-view
.completionprogress{text-align:right}.dir-rtl.path-course-view
.completionprogress{text-align:left}.path-course-view .single-section
.completionprogress{margin-right:5px}.path-course-view .section
.summary{line-height:normal}.path-site li.activity>div,.path-course-view li.activity>div{position:relative;padding:0
16px 0 0}.dir-rtl.path-site li.activity>div,.dir-rtl.path-course-view li.activity>div{position:relative;padding:0
0 0 16px}.path-course-view li.activity span.autocompletion
img{vertical-align:text-bottom}.path-course-view li.activity form.togglecompletion
img{max-width:none}.path-course-view li.activity form.togglecompletion
.ajaxworking{position:absolute;top:3px;right:22px;width:16px;height:16px;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=i%2Fajaxloader) no-repeat}.dir-rtl.path-course-view
.completionprogress{float:none}.dir-rtl.path-course-view li.activity form.togglecompletion
.ajaxworking{right:-22px}li.section.hidden span.commands a.editing_hide,li.section.hidden span.commands
a.editing_show{cursor:default}ul.weeks
h3.sectionname{white-space:nowrap}.editing ul.weeks
h3.sectionname{white-space:normal}.single-section
h3.sectionname{clear:both;text-align:center}.section
img.movetarget{width:80px;height:16px}input.titleeditor{width:330px;vertical-align:text-bottom}span.editinstructions{position:absolute;top:0;z-index:9999;padding:.1em .4em;margin-top:-22px;margin-left:30px;font-size:11.9px;line-height:16px;color:#3a87ad;text-decoration:none;background-color:#d9edf7;border:1px
solid #bce8f1;-webkit-box-shadow:2px 2px 5px 1px #ccc;-moz-box-shadow:2px 2px 5px 1px #ccc;box-shadow:2px 2px 5px 1px #ccc}#dndupload-status{position:fixed;left:0;z-index:1;width:40%;padding:6px;margin:0
30%;color:#3a87ad;text-align:center;background:#d9edf7;border:1px
solid #bce8f1;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;-webkit-box-shadow:2px 2px 5px 1px #ccc;-moz-box-shadow:2px 2px 5px 1px #ccc;box-shadow:2px 2px 5px 1px #ccc}.dndupload-preview{padding:.3em;margin-top:.2em;color:#909090;list-style:none;border:1px
dashed #909090}.dndupload-preview
img.icon{padding:0;vertical-align:text-bottom}.dndupload-progress-outer{height:20px;margin-bottom:20px;overflow:hidden;background-color:#f7f7f7;background-image:-moz-linear-gradient(top,#f5f5f5,#f9f9f9);background-image:-webkit-gradient(linear,0 0,0 100%,from(#f5f5f5),to(#f9f9f9));background-image:-webkit-linear-gradient(top,#f5f5f5,#f9f9f9);background-image:-o-linear-gradient(top,#f5f5f5,#f9f9f9);background-image:linear-gradient(to bottom,#f5f5f5,#f9f9f9);background-repeat:repeat-x;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5',endColorstr='#fff9f9f9',GradientType=0);-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);box-shadow:inset 0 1px 2px rgba(0,0,0,0.1)}.dndupload-progress-inner{float:left;width:0;height:100%;font-size:12px;color:#fff;text-align:center;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#0e90d2;background-image:-moz-linear-gradient(top,#149bdf,#0480be);background-image:-webkit-gradient(linear,0 0,0 100%,from(#149bdf),to(#0480be));background-image:-webkit-linear-gradient(top,#149bdf,#0480be);background-image:-o-linear-gradient(top,#149bdf,#0480be);background-image:linear-gradient(to bottom,#149bdf,#0480be);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf',endColorstr='#ff0480be',GradientType=0);-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-moz-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-transition:width .6s ease;-moz-transition:width .6s ease;-o-transition:width .6s ease;transition:width .6s ease}.dndupload-hidden{display:none}#page-course-pending .singlebutton,#page-course-index .singlebutton,#page-course-index-category .singlebutton,#page-course-editsection
.singlebutton{text-align:center}#page-admin-course-manage #movecourses td
img{margin:0
.22em;vertical-align:text-bottom}#page-admin-course-manage #movecourses td
img.icon{padding:0}#coursesearch{margin-top:1em;text-align:center}#page-course-pending
.pendingcourserequests{margin-bottom:1em}#page-course-pending .pendingcourserequests
.singlebutton{display:inline}#page-course-pending .pendingcourserequests
.cell{padding:0
5px}#page-course-pending .pendingcourserequests
.cell.c6{white-space:nowrap}.coursebox{padding:5px;margin-bottom:15px;border:1px
dotted #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.coursebox>.info>.coursename
a{display:block;padding-left:21px;background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=i%2Fcourse);background-position:left .5em;background-repeat:no-repeat}.dir-rtl .coursebox>.info>.coursename
a{padding-right:21px;padding-left:0;background-position:right}.coursebox.remotehost>.info>.categoryname
a{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=i%2Fmnethost)}.coursebox .content .teachers,.coursebox .content .courseimage,.coursebox .content
.coursefile{float:left;width:40%;clear:left}.dir-rtl .coursebox>.info>.coursename,.dir-rtl .coursebox .teachers,.dir-rtl .coursebox .content .courseimage,.dir-rtl .coursebox .content
.coursefile{float:right;clear:right}.coursebox>.info>h3.coursename{margin:5px}.coursebox>.info>.coursename{padding:0;margin:5px}.coursebox .content .teachers
li{padding:0;margin:0;list-style-type:none}.coursebox
.enrolmenticons{float:right;padding:3px
0}.coursebox
.moreinfo{float:right;padding:3px
0}.coursebox .enrolmenticons img,.coursebox .moreinfo
img{margin:0
.2em}.coursebox
.content{clear:both}.coursebox .content .summary,.coursebox .content
.coursecat{float:right;width:55%}.coursebox .content
.coursecat{clear:right;text-align:right}.coursebox.remotecoursebox
.remotecourseinfo{float:left;width:40%}.coursebox .content .courseimage
img{max-width:100px;max-height:100px}.coursebox .content .coursecat,.coursebox .content .summary,.coursebox .content .courseimage,.coursebox .content .coursefile,.coursebox .content .teachers,.coursebox.remotecoursebox
.remotecourseinfo{padding:0;margin:3px
5px}.dir-rtl .coursebox>.info>.categoryname
a{padding-right:21px;padding-left:0;background-position:center right}.dir-rtl .coursebox>.info>.categoryname,.dir-rtl .coursebox .teachers,.dir-rtl .coursebox .content .courseimage,.dir-rtl .coursebox .content
.coursefile{float:right;clear:right}.dir-rtl .coursebox .enrolmenticons,.dir-rtl .coursebox
.moreinfo{float:left}.dir-rtl .coursebox .summary,.dir-rtl .coursebox
.coursecat{float:left}.dir-rtl .coursebox
.coursecat{clear:left;text-align:left}.coursebox.collapsed{margin-bottom:0}.coursebox.collapsed>.content{display:none}.courses
.coursebox.collapsed{padding:5px;border:1px
solid #ddd}.courses
.coursebox.even{background-color:#f9f9f9}.courses .coursebox:hover,.course_category_tree .courses>.paging.paging-morelink:hover{background-color:#f5f5f5}.course_category_tree .category
.numberofcourse{font-size:11.9px}.course_category_tree
.controls{visibility:hidden}.course_category_tree .controls
div{display:inline;cursor:pointer}.jsenabled .course_category_tree
.controls{visibility:visible}.course_category_tree
.controls{float:right;margin-bottom:5px;text-align:right}.course_category_tree .controls
div{padding-right:2em;font-size:75%}.course_category_tree .category>.info>.categoryname{padding:2px
18px;margin:3px;background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_empty);background-position:center left;background-repeat:no-repeat}.dir-rtl .course_category_tree .category>.info>.categoryname{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_empty_rtl);background-position:center right}.course_category_tree .category.with_children>.info>.categoryname{cursor:pointer;background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fexpanded)}.course_category_tree .category.with_children.collapsed>.info>.categoryname{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed)}.dir-rtl .course_category_tree .category.with_children.collapsed>.info>.categoryname{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_rtl)}.course_category_tree .category.collapsed>.content{display:none}.course_category_tree .category>.info{min-height:20px;min-height:0;padding:19px;padding:0;margin:3px
0;margin-bottom:20px;margin-bottom:3px;clear:both;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.course_category_tree .category>.info
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.course_category_tree.frontpage-category-names .category>.info{margin:0;background:0;border:0}.course_category_tree .category>.content{padding-left:16px}.dir-rtl .course_category_tree .category>.content{padding-right:16px;padding-left:0}.course_category_tree .subcategories>.paging,.courses>.paging{padding:5px;margin:0;text-align:center}.courses>.paging.paging-morelink,.course_category_tree .subcategories>.paging.paging-morelink{text-align:left}.course_category_tree .paging.paging-morelink
a{font-size:11.9px}.dir-rtl .courses>.paging.paging-morelink,.dir-rtl .course_category_tree .paging.paging-morelink{text-align:right}#page-course-index-category
.generalbox.info{padding:5px;margin-bottom:15px;border:1px
dotted #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}#page-course-index-category
.categorypicker{margin:10px
0 20px;text-align:center}.section .summary .iconsmall,.section .activity
.iconsmall{width:16px;height:16px}.section .editing_title
.iconsmall{width:12px;height:12px;padding:4px
8px 0 0;margin:8px
8px 0 0;vertical-align:text-bottom}.section .moodle-actionmenu
.iconsmall{width:16px;height:16px;max-width:none!important;padding:4px;vertical-align:text-bottom}.section .moodle-actionmenu[data-enhanced] .menu
img{width:12px;height:12px}.dir-rtl .section .editing_title
.iconsmall{padding:4px
0 0 8px;margin:8px
0 0 8px}#course-category-listings{margin-bottom:200px;background-color:transparent}#course-category-listings.columns-2>#course-listing>div{position:relative;left:-1px}#course-category-listings.columns-3>#course-listing>div{height:100%}#course-category-listings>div>div{min-height:300px}#course-category-listings>div>div>ul.ml>li:first-child>div{border-top:0}#course-category-listings
h3{padding:.4rem .6rem .3rem;margin:0}#course-category-listings
h4{padding:.6rem 1rem .5rem;margin:1rem 0 0}#course-category-listings .moodle-actionmenu{white-space:nowrap}#course-category-listings .moodle-actionmenu[data-enhance] .toggle-display
img{width:auto}#course-category-listings .moodle-actionmenu[data-enhance] .toggle-display.textmenu{padding-right:4px}#course-category-listings .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-top:12px}#course-category-listings .listing-actions{padding:.4rem .3rem .3rem;line-height:2.2em;text-align:center}#course-category-listings .listing-actions>.moodle-actionmenu{display:inline-block}#course-category-listings .listing-actions>.moodle-actionmenu .menu
a{padding-left:1rem}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) li{line-height:normal}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menubar
a{display:inline-block;color:inherit}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menubar a>img{display:none}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menubar a
.caret{display:none}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menu .menu-action-text{display:inline-block}#course-category-listings
ul.ml{margin:1rem 0;list-style:none}#course-category-listings ul.ml
ul.ml{margin:0}#course-category-listings
li{line-height:2.2em}#course-category-listings li>div:hover{background-color:#f5f5f5}#course-category-listings li .tree-icon{width:12px;margin:2px
6px 0 0;vertical-align:inherit}#course-category-listings li[data-selected='1']>div{background-color:#f9f9f9}#course-category-listings li[data-selected='1']>div:hover{background-color:#f5f5f5}#course-category-listings li .tree-icon{margin-left:0}#course-category-listings li li .tree-icon{margin-left:1em}#course-category-listings li li li .tree-icon{margin-left:2em}#course-category-listings li li li li .tree-icon{margin-left:3em}#course-category-listings li li li li li .tree-icon{margin-left:4em}#course-category-listings li li li li li li .tree-icon{margin-left:4.5em}#course-category-listings li li li li li li li .tree-icon{margin-left:5em}#course-category-listings li li li li li li li li .tree-icon{margin-left:5.5em}#course-category-listings .item-actions{display:inline-block;display:initial;margin-right:1em}#course-category-listings .item-actions
img{height:12px;padding:0;margin:0
4px;vertical-align:inherit}#course-category-listings .item-actions.show .menu
a{padding:4px
1em 4px 4px}#course-category-listings .item-actions.show .menu
img{width:12px;max-width:none}#course-category-listings .item-actions .menu-action-text{vertical-align:inherit}#course-category-listings .listitem>div>.float-left{float:left}#course-category-listings .listitem>div>.float-right{float:right;text-align:right}#course-category-listings .listitem>div .item-actions .action-show{display:none}#course-category-listings .listitem>div .item-actions .action-hide{display:inline}#course-category-listings .listitem>div .without-actions{color:#333}#course-category-listings .listitem>div
.idnumber{margin-right:2em;color:#a1a1a8}#course-category-listings .listitem[data-visible="0"]{color:#999}#course-category-listings .listitem[data-visible="0"]>div>a{color:#999}#course-category-listings .listitem[data-visible="0"]>div .item-actions .action-show{display:inline}#course-category-listings .listitem[data-visible="0"]>div .item-actions .action-hide{display:none}#course-category-listings
.listitem.highlight{background-color:transparent}#course-category-listings .listitem.highlight>div,#course-category-listings .listitem.highlight>div:hover,#course-category-listings .listitem.highlight[data-selected='1']>div{background-color:#f5f5f5}#course-category-listings #course-listing .listitem
.categoryname{display:inline-block;margin-left:1em;color:#a1a1a8}#course-category-listings #course-listing .listitem
.coursename{display:inline-block}#course-category-listings #course-listing .listitem>div{padding-left:1rem}#course-category-listings #course-listing>.firstpage .listitem:first-child>div .item-actions .action-moveup,#course-category-listings #course-listing>.lastpage .listitem:last-child>div .item-actions .action-movedown{display:none}#course-category-listings #course-listing .bulk-action-checkbox{margin:-2px 6px 0 0}#course-category-listings #category-listing .listitem.collapsed>ul.ml{display:none}#course-category-listings #category-listing .listitem>div>.ba-checkbox{width:2.2em;padding-top:2px;margin:-1px .5em 0 0;text-align:center}#course-category-listings #category-listing .listitem.highlight>div>.ba-checkbox{background-color:#f5f5f5}#course-category-listings #category-listing .listitem[data-selected='1']>div>.ba-checkbox{padding:0;margin:0
.5em 0 0;background-color:inherit}#course-category-listings #category-listing .listitem:first-child>div .item-actions .action-moveup,#course-category-listings #category-listing .listitem:last-child>div .item-actions .action-movedown{display:none}#course-category-listings #category-listing .course-count{display:inline-block;min-width:3.5em;margin-right:2rem;color:#a1a1a8}#course-category-listings #category-listing .course-count
.smallicon{width:12px;margin-left:4px;vertical-align:inherit}#course-category-listings #category-listing .bulk-action-checkbox{margin-right:-3px}#course-category-listings #category-listing .category-listing>ul>.listitem:first-child{position:relative}#course-category-listings #category-listing .category-bulk-actions{position:relative;margin:0
.5em .5em}#course-category-listings .detail-pair{margin:0
1rem;border-bottom:1px solid #ddd}#course-category-listings .detail-pair>*{display:inline-block;line-height:2.2rem}#course-category-listings .detail-pair .pair-key{font-weight:bold;vertical-align:top}#course-category-listings .detail-pair .pair-key
span{display:block;margin-right:1rem}#course-category-listings .detail-pair .pair-value
select{max-width:100%}#course-category-listings .bulk-actions .detail-pair>*{display:block;width:100%}#course-category-listings .listing-pagination{text-align:center}#course-category-listings .listing-pagination .yui3-button{margin:.4rem .2rem .45rem;font-size:10.4px;background-color:#fff;border:0}#course-category-listings .listing-pagination .yui3-button.active-page{background-color:#e6e6e6}#course-category-listings .listing-pagination-totals{text-align:center}#course-category-listings .listing-pagination-totals.dimmed{margin:.4rem 1rem .45rem;color:#999}#course-category-listings .select-a-category .notifymessage,#course-category-listings .select-a-category
.alert{margin:1em}#course-category-listings #course-listing .listitem .drag-handle{display:none}.jsenabled #course-category-listings #course-listing .listitem .drag-handle{display:inline-block;margin:0
6px 0 0;cursor:pointer}.dir-rtl #course-category-listings #category-listing,.dir-rtl #course-category-listings #course-listing{float:right;margin-left:0}.dir-rtl #course-category-listings .listitem>div>.float-left{float:right}.dir-rtl #course-category-listings .listitem>div>.float-right{float:left;text-align:left}.dir-rtl #course-category-listings li .tree-icon{margin:2px
0 0 6px}.dir-rtl #course-category-listings li .tree-icon{margin-right:0}.dir-rtl #course-category-listings li li .tree-icon{margin-right:1em}.dir-rtl #course-category-listings li li li .tree-icon{margin-right:2em}.dir-rtl #course-category-listings li li li li .tree-icon{margin-right:3em}.dir-rtl #course-category-listings li li li li li .tree-icon{margin-right:4em}.dir-rtl #course-category-listings li li li li li li .tree-icon{margin-right:4.5em}.dir-rtl #course-category-listings li li li li li li li .tree-icon{margin-right:5em}.dir-rtl #course-category-listings li li li li li li li li .tree-icon{margin-right:5.5em}.dir-rtl #course-category-listings #category-listing .listitem>div{margin-right:.5em;margin-left:0}.dir-rtl #course-category-listings #category-listing .listitem>div>.ba-checkbox{margin:-1px 0 0 .5em}.dir-rtl #course-category-listings #category-listing .listitem[data-selected='1']>div>.ba-checkbox{margin:0
0 0 .5em}.dir-rtl #course-category-listings #category-listing .course-count{margin-left:2rem}.dir-rtl #course-category-listings #category-listing .bulk-action-checkbox{margin-right:0;margin-left:-3px}.dir-rtl #course-category-listings #course-listing{padding-right:24px}.dir-rtl #course-category-listings #course-listing .listitem
.idnumber{padding-right:2em;color:#a1a1a8}.dir-rtl #course-category-listings #course-listing .listitem
.categoryname{display:inline-block;margin-right:1em;margin-left:0}.dir-rtl #course-category-listings #course-listing .listitem .drag-handle{margin:0
6px 0 6px}.dir-rtl #course-category-listings #course-listing .listitem>div{padding-left:1rem}.dir-rtl #course-category-listings #course-listing .bulk-action-checkbox{margin:-2px 0 0 6px;vertical-align:middle}.dir-rtl #course-category-listings .detail-pair>*{float:right;margin-right:0}.dir-rtl #course-category-listings .detail-pair .pair-key
span{margin-right:0;margin-left:0}.dir-rtl #course-category-listings .detail-pair .pair-value{margin-right:.5em}.coursecat-management-header{vertical-align:middle}.coursecat-management-header
h2{display:inline-block;text-align:left}.coursecat-management-header>div{display:inline-block;float:right;line-height:40px}.coursecat-management-header>div>div{display:inline-block;margin:10px
0;margin-left:1em}.coursecat-management-header
select{max-width:300px;padding:.4em .5em .45em 1em;white-space:nowrap;vertical-align:baseline;cursor:pointer}.coursecat-management-header .view-mode-selector .moodle-actionmenu{display:inline-block;white-space:nowrap}.coursecat-management-header .view-mode-selector .moodle-actionmenu[data-enhanced].show .menu
a{padding-left:1em}.dir-rtl .coursecat-management-header
h2{text-align:right}.dir-rtl .coursecat-management-header>div{float:left;margin-right:1em;margin-left:0}.course-being-dragged-proxy{padding:0
0 0 4em;color:#0070a8;vertical-align:middle;border:0}.course-being-dragged{opacity:.5;filter:alpha(opacity=50)}@media(min-width:1200px) and (max-width:1600px){#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-3 #course-listing{width:50%}#course-category-listings.columns-3 #category-listing>div,#course-category-listings.columns-3 #course-listing>div,#course-category-listings.columns-3 #course-detail>div{background-color:transparent}#course-category-listings.columns-3 #course-detail{width:100%;margin-top:1em}}@media(max-width:1199px){#course-category-listings.columns-2,#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-2 #category-listing,#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-2 #course-listing,#course-category-listings.columns-3 #course-listing,#course-category-listings.columns-2 #course-detail,#course-category-listings.columns-3 #course-detail{width:100%;margin:0
0 1em}#course-category-listings.columns-2 #category-listing>div,#course-category-listings.columns-3 #category-listing>div,#course-category-listings.columns-2 #course-listing>div,#course-category-listings.columns-3 #course-listing>div,#course-category-listings.columns-2 #course-detail>div,#course-category-listings.columns-3 #course-detail>div{background-color:transparent}}.filemanager,.filepicker,.file-picker{font-size:11px}.filemanager a,.file-picker a,.filemanager a:hover,.file-picker a:hover{color:#555;text-decoration:none}.filemanager input[type="text"],.file-picker input[type="text"]{width:265px}.filemanager .fp-license td,.file-picker .fp-setlicense
td{max-width:265px}.filemanager .fp-license select,.file-picker .fp-setlicense
select{max-width:100%}.fp-content-center{display:table-cell;width:100%;height:100%;vertical-align:middle}.fp-content-hidden{visibility:hidden}.yui3-panel-focused{outline:0}#filesskin .yui3-panel-content{display:inline-block;*display:inline;padding-bottom:20px;background:#f2f2f2;border:1px
solid #fff;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;*zoom:1;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}#filesskin .yui3-widget-hd{padding:5px;font-size:12px;letter-spacing:1px;color:#333;text-align:center;text-shadow:1px 1px 1px #fff;background-color:#ebebeb;background-image:-moz-linear-gradient(top,#fff,#ccc);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#ccc));background-image:-webkit-linear-gradient(top,#fff,#ccc);background-image:-o-linear-gradient(top,#fff,#ccc);background-image:linear-gradient(to bottom,#fff,#ccc);background-repeat:repeat-x;border-bottom:1px solid #bbb;-webkit-border-radius:10px 10px 0 0;-moz-border-radius:10px 10px 0 0;border-radius:10px 10px 0 0;filter:dropshadow(color=#ffffff,offx=1,offy=1);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffcccccc',GradientType=0)}.fp-panel-button{display:inline-block;*display:inline;padding:3px
20px 2px 20px;margin:10px;text-align:center;background:#fff;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;*zoom:1;-webkit-box-shadow:2px 2px 3px .1px #999;-moz-box-shadow:2px 2px 3px .1px #999;box-shadow:2px 2px 3px .1px #999}.moodle-dialogue-base .filepicker .moodle-dialogue-wrap .moodle-dialogue-bd{padding:0}#filesskin .file-picker.fp-generallayout{position:relative;width:859px;background:#fff;border:1px
solid #ccc;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px}.file-picker .fp-repo-area{display:inline-block;*display:inline;float:left;width:180px;height:525px;overflow:auto;border-right:1px solid #bbb;*zoom:1}.dir-rtl .file-picker .fp-repo-area{float:right;border-right:0;border-left:1px solid #bbb}.file-picker .fp-repo-items{float:none;width:auto;margin-left:181px}.moodle-dialogue-fullscreen .file-picker .fp-repo-items{float:left;margin-right:0;margin-left:0}.dir-rtl .file-picker .fp-repo-items{margin-right:181px;margin-left:0}.dir-rtl .moodle-dialogue-fullscreen .file-picker .fp-repo-items{float:right;margin-right:0;margin-left:0}.file-picker .fp-navbar{min-height:40px;overflow:hidden;background:#f2f2f2;border-bottom:1px solid #bbb}.file-picker .fp-navbar .fp-viewbar{margin:4px}.file-picker .fp-content{height:452px;overflow:auto;clear:none;background:#fff}.filepicker.moodle-dialogue-fullscreen .file-picker .fp-content{width:100%}.file-picker .fp-content-loading{display:table;width:100%;height:100%;text-align:center}.file-picker .fp-content .fp-object-container{width:98%;height:98%}.dir-rtl .file-picker .fp-list{text-align:right}.dir-rtl .file-picker .fp-toolbar{padding:4px}.dir-rtl .file-picker .fp-list{text-align:right}.dir-rtl .file-picker .fp-repo-name{display:inline}.dir-rtl .file-picker .fp-pathbar{display:block;text-align:right;border-top:0}.dir-rtl .file-picker
div.bd{text-align:right}.dir-rtl #filemenu
.yuimenuitemlabel{text-align:right}.dir-rtl .filepicker .yui-layout-unit-left{left:500px}.dir-rtl .filepicker .yui-layout-unit-center{left:0}.dir-rtl .filemanager-toolbar
a{padding:0}.file-picker .fp-list{float:left;width:100%;padding:0;margin:0;list-style-type:none}.dir-rtl .file-picker .fp-list{float:left;text-align:right}.file-picker .fp-list .fp-repo
a{display:block;padding:.5em .7em}.file-picker .fp-list .fp-repo.active{background:#f2f2f2}.file-picker .fp-list .fp-repo-icon{width:16px;height:16px;padding:0
7px 0 5px}.fp-toolbar{float:left}.dir-rtl .fp-toolbar{float:right}.fp-toolbar.empty{display:none}.dir-rtl .fp-toolbar div.disabled,.fp-toolbar
.disabled{display:none}.fp-toolbar
div{display:block;float:left;margin-right:4px}.dir-rtl .fp-toolbar
div{display:block;float:right;margin-right:0;margin-left:4px}.fp-toolbar
img{margin-right:5px;vertical-align:-15%}.fp-toolbar .fp-tb-search{width:235px;height:27px}.fp-toolbar .fp-tb-search
input{width:200px;height:27px;padding:2px
6px 1px 27px;background:#fff url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=a%2Fsearch') no-repeat 7px 7px;border:1px
solid #bbb}.fp-viewbar{float:right;height:30px;background:white;border:1px
solid #CCC;border-bottom:1px solid #b3b3b3;border-radius:4px}.fp-repo-items fp-viewbar{margin:4px}.dir-rtl .fp-toolbar
img{vertical-align:-35%}.dir-rtl .fp-viewbar{float:left}.fp-viewbar
a{display:block;float:left;width:30px;height:30px;border-right:1px solid #CCC}.fp-viewbar a.checked:hover,.fp-viewbar a:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center,#fff 60%,#dfdfdf 100%)}.fp-viewbar a.checked,.fp-viewbar a:active{background-color:#dfdfdf;background-image:radial-gradient(ellipse at center,#fff 40%,#dfdfdf 100%)}.fp-viewbar a.fp-vb-icons{border-radius:4px 0 0 4px}.fp-viewbar a.fp-vb-tree{border-right:0;border-radius:0 4px 4px 0}.fp-viewbar a
img{margin:7px}.fp-viewbar.disabled
a{cursor:default;background:0;opacity:.45}.file-picker .fp-clear-left{clear:left}.dir-rtl .filemanager-toolbar .fp-vb-icons a:hover{background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Fview_icon_selected')}.dir-rtl .filemanager-toolbar .fp-vb-icons.checked a:hover{background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Fview_icon_active') no-repeat 0 0}.dir-rtl .fp-vb-details a:hover{background:0;border:20px
solid black}.dir-rtl .fp-vb-details.checked a:hover{background:0;border:40px
solid black}.dir-rtl .fp-vb-tree a:hover{background:0;border:30px
solid black}.dir-rtl .fp-vb-tree.checked a:hover{background:0;border:50px
solid black}.file-picker .fp-pathbar{display:table-row}.fp-pathbar.empty{display:none}.fp-pathbar .fp-path-folder{width:27px;height:12px;margin-left:4px;background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Fpath_folder') no-repeat 0 0}.dir-rtl .fp-pathbar .fp-path-folder{width:auto;height:12px;margin-left:4px;background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Fpath_folder_rtl') no-repeat right top}.dir-rtl .fp-pathbar
span{display:inline-block;*display:inline;float:right;margin-left:32px;*zoom:1}.fp-pathbar .fp-path-folder-name{margin-left:32px;line-height:20px}.dir-rtl .fp-pathbar .fp-path-folder-name{margin-right:32px;line-height:20px}.fp-iconview .fp-file{position:relative;float:left;margin:10px
10px 35px;text-align:center}.fp-iconview .fp-thumbnail{display:block;min-width:110px;min-height:110px;line-height:110px;text-align:center;border:1px
solid #fff}.fp-iconview .fp-thumbnail
img{padding:3px;vertical-align:middle;border:1px
solid #ddd;-webkit-box-shadow:1px 1px 2px 0 #ccc;-moz-box-shadow:1px 1px 2px 0 #ccc;box-shadow:1px 1px 2px 0 #ccc}.fp-iconview .fp-thumbnail:hover{background:#fff;border:1px
solid #ddd;-webkit-box-shadow:inset 0 0 10px 0 #ccc;-moz-box-shadow:inset 0 0 10px 0 #ccc;box-shadow:inset 0 0 10px 0 #ccc}.fp-iconview .fp-filename-field{position:absolute;height:33px;overflow:hidden;word-wrap:break-word}.fp-iconview .fp-filename-field:hover{z-index:1000;overflow:visible}.fp-iconview .fp-filename-field .fp-filename{min-width:112px;padding-top:5px;padding-bottom:12px;background:#fff}.dir-rtl .fp-iconview .fp-file{float:right}.file-picker .yui3-datatable
table{width:100%;border:0
solid #bbb}#filesskin .file-picker .yui3-datatable-header{color:#555;background:#fff;border-bottom:1px solid #ccc;border-left:0 solid #fff}#filesskin .file-picker .yui3-datatable-odd .yui3-datatable-cell{background-color:#f6f6f6;border-left:0 solid #f6f6f6}#filesskin .file-picker .yui3-datatable-even .yui3-datatable-cell{background-color:#fff;border-left:0 solid #fff}.dir-rtl .file-picker .yui3-datatable-header{text-align:right}.file-picker .ygtvtn,.filemanager
.ygtvtn{width:17px;height:22px;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftn') 0 0 no-repeat}.dir-rtl .filemanager .ygtvtn,.dir-rtl .file-picker
.ygtvtn{width:17px;height:22px;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftn_rtl') 0 0 no-repeat}.file-picker .ygtvtm,.filemanager
.ygtvtm{width:13px;height:12px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftm') 0 10px no-repeat}.file-picker .ygtvtmh,.filemanager
.ygtvtmh{width:13px;height:12px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftm') 0 10px no-repeat}.file-picker .ygtvtp,.filemanager
.ygtvtp{width:13px;height:12px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftp') 0 10px no-repeat}.dir-rtl .file-picker .ygtvtp,.dir-rtl .filemanager
.ygtvtp{background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftp_rtl') 0 10px no-repeat}.file-picker .ygtvtph,.filemanager
.ygtvtph{width:13px;height:22px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftp') 0 10px no-repeat}.dir-rtl .file-picker .ygtvtph,.dir-rtl .filemanager
.ygtvtph{background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Ftp_rtl') 0 10px no-repeat}.file-picker .ygtvln,.filemanager
.ygtvln{width:17px;height:22px;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Fln') 0 0 no-repeat}.dir-rtl .file-picker .ygtvln,.dir-rtl .filemanager
.ygtvln{background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Fln_rtl') 0 0 no-repeat}.file-picker .ygtvlm,.filemanager
.ygtvlm{width:13px;height:12px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Flm') 0 10px no-repeat}.file-picker .ygtvlmh,.filemanager
.ygtvlmh{width:13px;height:12px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Flm') 0 10px no-repeat}.file-picker .ygtvlp,.filemanager
.ygtvlp{width:13px;height:12px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Flp') 0 10px no-repeat}.dir-rtl .file-picker .ygtvlp,.dir-rtl .filemanager
.ygtvlp{background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Flp_rtl') 0 10px no-repeat}.file-picker .ygtvlph,.filemanager
.ygtvlph{width:13px;height:12px;cursor:pointer;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Flp') 0 10px no-repeat}.dir-rtl .file-picker .ygtvlph,.dir-rtl .filemanager
.ygtvlph{background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Flp_rtl') 0 10px no-repeat}.file-picker .ygtvloading,.filemanager
.ygtvloading{width:16px;height:22px;background:transparent url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Floading') 0 0 no-repeat}.file-picker .ygtvdepthcell,.filemanager
.ygtvdepthcell{width:17px;height:32px;background:url('/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=y%2Fvline') 0 0 no-repeat}.file-picker .ygtvblankdepthcell,.filemanager
.ygtvblankdepthcell{width:17px;height:22px}a.ygtvspacer:hover{color:transparent;text-decoration:none}.ygtvlabel,.ygtvlabel:link,.ygtvlabel:visited,.ygtvlabel:hover{margin-left:2px;text-decoration:none;cursor:pointer;background-color:transparent}.file-picker .ygtvfocus,.filemanager
.ygtvfocus{background-color:#eee}.fp-filename-icon{position:relative;display:block;margin-top:10px}.fp-icon{float:left;width:24px;height:24px;margin-top:-7px;margin-right:10px;line-height:24px;text-align:center}.dir-rtl .fp-icon{float:right;margin-right:0;margin-left:10px}.fp-icon
img{max-width:24px;max-height:24px;vertical-align:middle}.fp-filename{padding-right:10px}.dir-rtl .fp-filename{padding-right:0;padding-left:10px}.file-picker .fp-login-form{display:table;width:100%;height:100%}.file-picker .fp-login-form
table{margin:0
auto}.file-picker .fp-login-form
p{margin-top:3em;text-align:center}.file-picker .fp-login-form .fp-login-input
label{display:block;text-align:right}.file-picker .fp-login-form .fp-login-input
.input{text-align:left}.file-picker .fp-login-form input[type="checkbox"]{width:15px;height:15px}.file-picker .fp-upload-form{display:table;width:100%;height:100%}.file-picker .fp-upload-form
table{margin:0
auto}.file-picker.fp-dlg{text-align:center}.file-picker.fp-dlg .fp-dlg-text{padding:30px
20px 10px;font-size:12px}.file-picker.fp-dlg .fp-dlg-buttons{margin:0
20px}.file-picker.fp-msg{text-align:center}.file-picker.fp-msg .fp-msg-text{max-width:500px;max-height:300px;min-width:200px;padding:40px
20px 10px 20px;overflow:auto;font-size:12px}.file-picker.fp-msg.fp-msg-error .fp-msg-text{padding:40px
20px 10px 20px;font-size:12px}.file-picker .fp-content-error{display:table;width:100%;height:100%;text-align:center}.file-picker .fp-content-error .fp-error{display:table-cell;width:100%;height:100%;padding:40px
20px 10px 20px;font-size:12px;vertical-align:middle}.file-picker .fp-nextpage{clear:both}.file-picker .fp-nextpage .fp-nextpage-loading{display:none}.file-picker .fp-nextpage.loading .fp-nextpage-link{display:none}.file-picker .fp-nextpage.loading .fp-nextpage-loading{display:block;height:100px;padding-top:50px;text-align:center}.fp-select
form{padding:20px
20px 0}.fp-select .fp-select-loading{margin-top:20px;text-align:center}.fp-select .fp-hr{width:auto;height:1px;margin:10px
0;clear:both;background-color:#fff;border-bottom:1px solid #bbb}.fp-select
table{padding:0
0 10px}.fp-select table .mdl-right{min-width:84px}.fp-select .fp-reflist .mdl-right{vertical-align:top}.fp-select .fp-select-buttons{float:right}.fp-select .fp-info{display:block;padding:1px
20px 0;clear:both}.fp-select .fp-thumbnail{float:left;min-width:110px;min-height:110px;margin:10px
20px 0 0;line-height:110px;text-align:center;background:#fff;border:1px
solid #ddd;-webkit-box-shadow:inset 0 0 10px 0 #ccc;-moz-box-shadow:inset 0 0 10px 0 #ccc;box-shadow:inset 0 0 10px 0 #ccc}.fp-select .fp-thumbnail
img{padding:3px;margin:10px;vertical-align:middle;border:1px
solid #ddd}.fp-select .fp-fileinfo{display:inline-block;*display:inline;margin-top:10px;*zoom:1}.file-picker.fp-select .fp-fileinfo{max-width:240px}.fp-select .fp-fileinfo
div{padding-bottom:5px}.file-picker.fp-select
.uneditable{display:none}.file-picker.fp-select .fp-select-loading{display:none}.file-picker.fp-select.loading .fp-select-loading{display:block}.file-picker.fp-select.loading
form{display:none}.fp-select .fp-dimensions.fp-unknown{display:none}.filemanager-loading{display:none}.jsenabled .filemanager-loading{display:block;margin-top:100px}.filemanager.fm-loading .filemanager-toolbar,.filemanager.fm-loading .fp-pathbar,.filemanager.fm-loading .filemanager-container,.filemanager.fm-loaded .filemanager-loading,.filemanager.fm-maxfiles .fp-btn-add,.filemanager.fm-maxfiles .dndupload-message,.filemanager.fm-noitems .fp-btn-download,.filemanager .fm-empty-container,.filemanager.fm-noitems .filemanager-container .fp-content{display:none}.filemanager .fp-img-downloading{display:none;padding-top:7px}.filemanager .filemanager-updating{display:none;text-align:center}.filemanager.fm-updating .filemanager-updating{display:block;margin-top:37px}.filemanager.fm-updating .fm-content-wrapper,.filemanager.fm-nomkdir .fp-btn-mkdir,.fitem.disabled .filemanager .filemanager-toolbar,.fitem.disabled .filemanager .fp-pathbar,.fitem.disabled .filemanager .fp-restrictions,.fitem.disabled .filemanager .fm-content-wrapper{display:none}.filemanager .fp-restrictions{text-align:right}.filemanager .fp-navbar{background:#f2f2f2;border:1px
solid #bbb;border-bottom:0}.filemanager-toolbar{padding:4px;overflow:hidden}.fp-pathbar{min-height:20px;padding:5px
8px 1px;border-top:1px solid #bbb}.file-picker .fp-toolbar{padding:4px}.fp-toolbar .fp-btn-add,.fp-toolbar .fp-btn-download,.fp-toolbar .fp-btn-mkdir,.fp-toolbar .fp-tb-help,.fp-toolbar .fp-tb-manage,.fp-toolbar .fp-tb-logout,.fp-toolbar .fp-tb-refresh{width:30px;height:30px;background:white;border:1px
solid #CCC;border-bottom:1px solid #b3b3b3;border-radius:4px}.fp-toolbar a:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center,#fff 60%,#dfdfdf 100%)}.fp-toolbar a:active{background-color:#dfdfdf;background-image:radial-gradient(ellipse at center,#fff 40%,#dfdfdf 100%)}.fp-btn-add a,.fp-btn-download a,.fp-btn-mkdir a,.fp-tb-help a,.fp-tb-manage a,.fp-tb-logout a,.fp-tb-refresh
a{display:block;width:30px;height:30px;border-radius:4px}.fp-btn-add img,.fp-btn-download img,.fp-btn-mkdir img,.fp-tb-help img,.fp-tb-manage img,.fp-tb-logout img,.fp-tb-refresh
img{margin:7px}.filemanager .fp-pathbar.empty{display:none}.filepicker-filelist,.filemanager-container{position:relative;min-height:140px;overflow:auto;clear:both;background:#fff;border:1px
solid #bbb}.filemanager .fp-content{max-height:472px;min-height:157px;overflow:auto}.filemanager-container,.filepicker-filelist{overflow:hidden}.fitem.disabled .filepicker-filelist,.fitem.disabled .filemanager-container{background-color:#ebebe4}.fitem.disabled .fp-btn-choose{color:#999}.fitem.disabled .filepicker-filelist .filepicker-filename{display:none}.fp-iconview .fp-reficons1{position:absolute;top:0;left:0;width:100%;height:100%}.fp-iconview .fp-reficons2{position:absolute;top:0;left:0;width:100%;height:100%}.fp-iconview .fp-file.fp-hasreferences .fp-reficons1{background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Flink') no-repeat;background-position:bottom right}.fp-iconview .fp-file.fp-isreference .fp-reficons2{background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Falias') no-repeat;background-position:bottom left}.filemanager .fp-iconview .fp-file.fp-originalmissing .fp-thumbnail
img{display:none}.filemanager .fp-iconview .fp-file.fp-originalmissing .fp-thumbnail{background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=s%2Fdead) no-repeat;background-position:center center}.filemanager .yui3-datatable
table{width:100%;border:0
solid #bbb}.filemanager .yui3-datatable-header{color:#555!important;background:#fff!important;border-bottom:1px solid #ccc!important;border-left:0 solid #fff!important}.filemanager .yui3-datatable-odd .yui3-datatable-cell{background-color:#f6f6f6!important;border-left:0 solid #f6f6f6}.filemanager .yui3-datatable-even .yui3-datatable-cell{background-color:#fff!important;border-left:0 solid #fff}.filemanager .fp-filename-icon.fp-hasreferences .fp-reficons1{position:absolute;top:8px;left:17px;z-index:1000;width:100%;height:100%;background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Flink_sm') no-repeat 0 0}.filemanager .fp-filename-icon.fp-isreference .fp-reficons2{position:absolute;top:9px;left:-6px;z-index:1001;width:100%;height:100%;background:url('/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Falias_sm') no-repeat 0 0}.filemanager .fp-contextmenu{display:none}.filemanager .fp-iconview .fp-folder.fp-hascontextmenu .fp-contextmenu{position:absolute;right:7px;bottom:5px;display:block}.filemanager .fp-treeview .fp-folder.fp-hascontextmenu .fp-contextmenu,.filemanager .fp-tableview .fp-folder.fp-hascontextmenu .fp-contextmenu{position:absolute;top:6px;left:14px;display:inline;margin-right:-20px}.dir-rtl .filemanager .fp-iconview .fp-folder.fp-hascontextmenu .fp-contextmenu{right:inherit;left:7px}.dir-rtl .filemanager .fp-treeview .fp-folder.fp-hascontextmenu .fp-contextmenu,.dir-rtl .filemanager .fp-tableview .fp-folder.fp-hascontextmenu .fp-contextmenu{right:16px;left:inherit;margin-right:0}.filepicker-filelist .filepicker-container,.filemanager.fm-noitems .fm-empty-container{position:absolute;top:10px;right:10px;bottom:10px;left:10px;display:block;padding-top:85px;text-align:center;border:2px
dashed #bbb}.filepicker-filelist .dndupload-target,.filemanager-container .dndupload-target{position:absolute;top:10px;right:10px;bottom:10px;left:10px;padding-top:85px;text-align:center;background:#fff;border:2px
dashed #fb7979;-webkit-box-shadow:0 0 0 10px #fff;-moz-box-shadow:0 0 0 10px #fff;box-shadow:0 0 0 10px #fff}.filepicker-filelist.dndupload-over .dndupload-target,.filemanager-container.dndupload-over .dndupload-target{position:absolute;top:10px;right:10px;bottom:10px;left:10px;padding-top:85px;text-align:center;background:#fff;border:2px
dashed #6c8cd3}.dndupload-message{display:none}.dndsupported .dndupload-message{display:inline}.dnduploadnotsupported-message{display:none}.dndnotsupported .dnduploadnotsupported-message{display:inline}.dndupload-target{display:none}.dndsupported .dndupload-ready .dndupload-target{display:block}.dndupload-uploadinprogress{display:none;text-align:center}.dndupload-uploading .dndupload-uploadinprogress{display:block}.dndupload-arrow{position:absolute;top:5px;width:100%;height:80px;background:url(/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=fp%2Fdnd_arrow) center no-repeat}.fitem.disabled .filepicker-container,.fitem.disabled .fm-empty-container{display:none}.dndupload-progressbars{display:none;padding:10px}.dndupload-inprogress .dndupload-progressbars{display:block}.dndupload-inprogress .fp-content{display:none}.filemanager.fm-noitems .dndupload-inprogress .fm-empty-container{display:none}.filepicker-filelist.dndupload-inprogress .filepicker-container{display:none}.filepicker-filelist.dndupload-inprogress
a{display:none}.filemanager.fp-select .fp-select-loading{display:none}.filemanager.fp-select.loading .fp-select-loading{display:block}.filemanager.fp-select.loading
form{display:none}.filemanager.fp-select.fp-folder .fp-license,.filemanager.fp-select.fp-folder .fp-author,.filemanager.fp-select.fp-file .fp-file-unzip,.filemanager.fp-select.fp-folder .fp-file-unzip,.filemanager.fp-select.fp-file .fp-file-zip,.filemanager.fp-select.fp-zip .fp-file-zip{display:none}.filemanager.fp-select .fp-file-setmain,.filemanager.fp-select .fp-file-setmain-help{display:none}.filemanager.fp-select.fp-cansetmain .fp-file-setmain,.filemanager.fp-select.fp-cansetmain .fp-file-setmain-help{display:inline-block;*display:inline;*zoom:1}.filemanager .fp-mainfile .fp-filename{font-weight:bold}.filemanager.fp-select.fp-folder .fp-file-download{display:none}.fm-operation{font-weight:bold}.filemanager.fp-select .fp-original.fp-unknown,.filemanager.fp-select .fp-original .fp-originloading{display:none}.filemanager.fp-select .fp-original.fp-loading .fp-originloading{display:inline}.filemanager.fp-select .fp-reflist.fp-unknown,.filemanager.fp-select .fp-reflist .fp-reflistloading{display:none}.filemanager.fp-select .fp-refcount{max-width:265px}.filemanager.fp-select .fp-reflist.fp-loading .fp-reflistloading{display:inline}.filemanager.fp-select .fp-reflist .fp-value{max-width:265px;max-height:75px;padding:8px
7px;margin:0;overflow:auto;background:#f9f9f9;border:1px
solid #bbb}.filemanager.fp-select .fp-reflist .fp-value
li{padding-bottom:7px}.filemanager.fp-mkdir-dlg{text-align:center}.filemanager.fp-mkdir-dlg .fp-mkdir-dlg-text{margin:20px;text-align:left}.dir-rtl .filemanager .fp-mkdir-dlg
p{text-align:right}.filemanager.fp-dlg{text-align:center}.filemanager.fp-dlg .fp-dlg-text{max-width:340px;max-height:300px;min-width:200px;padding:0
10px;margin:40px
20px 20px;overflow:auto;font-size:12px;line-height:22px}.file-picker
div.bd{text-align:left}.dir-rtl .filemanager .fp-restrictions{text-align:left}.dir-rtl .file-picker div.bd,.dir-rtl .file-picker .fp-pathbar,.dir-rtl .file-picker .fp-list,.dir-rtl #filemenu .yuimenuitemlabel,.dir-rtl .filemanager-container .yui3-skin-sam .yui3-datatable-header{text-align:right}.dir-rtl .filepicker .yui-layout-unit-left{left:500px}.dir-rtl .filepicker .yui-layout-unit-center{left:0}.dir-rtl .file-picker .fp-toolbar .fp-tb-search
input{padding:2px
30px 1px 3px;background-position:208px 7px}.dir-rtl .file-picker .fp-toolbar
div{float:right;margin-left:4px}.fp-formset{max-width:500px;padding:10px}.fp-formset input[type="file"]{line-height:inherit}.fp-forminset{max-width:400px;padding:0
10px}.fp-forminset .control-group.control-radio{margin-bottom:0}.fp-forminset .control-group label.control-label{width:105px}.fp-forminset .control-group label.control-radio{float:right;width:215px;text-align:left}.fp-forminset .control-group
.controls{margin-left:125px}.fp-forminset .control-group .controls.control-radio
input{margin-top:3px}.fp-forminset .fp-select-buttons{float:none}.fp-forminset input[type="text"]{width:228px}.fp-fileinfo .fp-value{display:inline-block;padding-left:5px}.dir-rtl .fp-forminset{max-width:400px}.dir-rtl .fp-forminset .control-group label.control-label{float:right;text-align:left}.dir-rtl .fp-forminset .control-group label.control-radio{float:left;width:215px;text-align:right}.dir-rtl .fp-forminset .control-group
.controls{margin-right:125px;margin-left:0}.dir-rtl .fp-forminset .fp-select-buttons{float:left}.dir-rtl .fp-forminset input[type="text"]{width:228px}.dir-rtl .fp-fileinfo .fp-value{display:inline-block;padding-right:5px}.dir-rtl .fp-select .fp-thumbnail{margin:10px
0 0 0}.dir-rtl .filepicker .fp-formset
label{float:right;text-align:left}.dir-rtl .filepicker .fp-formset
.controls{margin-left:0;text-align:right}.message-discussion-noframes
h1{font-size:1em}.message-discussion-noframes #userinfo .commands,.message .noframesjslink,.message
.link{font-size:11.9px}.message
.heading{font-size:1em;font-weight:bold}.message
.author{font-weight:bold}.message
.time{font-style:italic}#page-message-user .commands
span{font-size:.7em}#page-message-user
.name{font-size:1.1em;font-weight:bold}.message
.time{color:#999}#page-message-messages{padding:10px}#page-message-send
.notifysuccess{padding:1px}#page-message-send
td.fixeditor{text-align:center}.message
.note{padding:10px}table.message .searchresults
td{padding:5px}.message
.contactselector{float:left;width:24%}.message .contactselector
.contact{text-align:left}.message .contactselector
.messageselecteduser{font-weight:bold}.message .contactselector
.paging{position:relative;z-index:1}.message
.messagearea{float:right;width:74%;min-height:200px;padding-left:1%;border-left:1px solid #ddd}.message .messagearea
.messagehistorytype{padding-bottom:20px;clear:both}.message .messagearea .messagehistory
.message_user_pictures{margin-right:auto;margin-left:auto}.message .messagearea .messagehistory .message_user_pictures
#user1{width:200px;vertical-align:top}.message .messagearea .messagehistory .message_user_pictures
#user2{width:200px;vertical-align:top}.message .messagearea .messagehistory .message_user_pictures
.useractionlinks{font-size:.9em}.message .messagearea .messagehistory
.heading{width:100%;clear:both}.message .messagearea .messagehistory
.left{float:left;width:50%;padding-bottom:10px;clear:both}.dir-rtl .message .messagearea .messagehistory
.left{float:right}.message .messagearea .messagehistory
.right{float:right;width:50%;padding-bottom:10px;clear:both}.dir-rtl .message .messagearea .messagehistory
.right{float:left}.message .messagearea .messagehistory
.notification{min-height:20px;padding:19px;padding:9px;margin-top:5px;margin-bottom:20px;margin-bottom:0;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-webkit-border-radius:3px;-moz-border-radius:4px;-moz-border-radius:3px;border-radius:4px;border-radius:3px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.message .messagearea .messagehistory .notification
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.message .messagearea
.messagesend{padding-top:20px;clear:both}.message .messagearea .messagesend
.messagesendbox{width:100%}.message .messagearea .messagesend
fieldset{padding:0;margin:0}.message .messagearea
.messagerecent{width:100%;text-align:left}.message .messagearea .messagerecent
.singlemessage{padding:10px;border-bottom:1px solid #ddd}.message .messagearea .messagerecent .singlemessage .otheruser
span{padding:5px}.message .messagearea .messagerecent .singlemessage
.messagedate{float:right}.message
.hiddenelement{display:none}.message
.visible{display:inline}.message #usergroupselector.fieldset,.message
#viewing{width:100%}.messagesearchresults{margin-bottom:40px}.messagesearchresults
td{padding:0
10px 0 20px}.messagesearchresults td
span{white-space:nowrap}.messagesearchresults td
img.userpicture{padding-right:.45em;vertical-align:text-bottom}.dir-rtl .messagesearchresults td
img.userpicture{padding-right:0;padding-left:.45em}.messagesearchresults td span
img{padding:0
0 0 .45em;vertical-align:text-bottom}.dir-rtl .messagesearchresults td span
img{padding:0
.45em 0 0}#newmessageoverlay{position:fixed;right:0;bottom:0;min-height:20px;padding:19px;margin:0
1em;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}#newmessageoverlay
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}#newmessageoverlay
#usermessage{padding:10px}#page-user-action_redir #edit-messagebody{width:auto}.questionbank
h2{margin-top:0}.questioncategories
h3{margin-top:0}#chooseqtypebox{margin-top:1em}#chooseqtype
h3{margin:0
0 .3em}#chooseqtype
.instruction{display:none}#chooseqtype
.fakeqtypes{border-top:1px solid silver}#chooseqtype
.qtypeoption{margin-bottom:.5em}#chooseqtype
label{display:block}#chooseqtype .qtypename
img{padding:0
.3em}#chooseqtype
.qtypename{display:inline-table;width:16em}#chooseqtype
.qtypesummary{display:block;margin:0
2em}#chooseqtype
.submitbuttons{margin:.7em 0;text-align:center}#qtypechoicecontainer{display:none}#qtypechoicecontainer_c.yui-panel-container.shadow
.underlay{background:0}#qtypechoicecontainer.yui-panel
.hd{letter-spacing:1px;color:#333;text-shadow:1px 1px 1px #fff;background-color:#ebebeb;background-image:-moz-linear-gradient(top,#fff,#ccc);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#ccc));background-image:-webkit-linear-gradient(top,#fff,#ccc);background-image:-o-linear-gradient(top,#fff,#ccc);background-image:linear-gradient(to bottom,#fff,#ccc);background-repeat:repeat-x;border:1px
solid #ccc;border-bottom:1px solid #bbb;-webkit-border-top-right-radius:10px;border-top-right-radius:10px;-webkit-border-top-left-radius:10px;border-top-left-radius:10px;-moz-border-radius-topright:10px;-moz-border-radius-topleft:10px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffcccccc',GradientType=0)}#qtypechoicecontainer{font-size:12px;color:#333;background:#f2f2f2;border:1px
solid #ccc;border-top:0 none;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}#qtypechoicecontainer
#chooseqtype{width:40em}#chooseqtypehead
h3{margin:0;font-weight:normal}#chooseqtype
.qtypes{position:relative;padding:.24em 0;border-bottom:1px solid #bbb}#chooseqtype
.alloptions{width:60%;max-height:400px;max-height:calc(85vh);max-height:60vh;overflow-x:hidden;overflow-y:auto}#chooseqtype
.qtypeoption{padding:.3em .3em .3em 1.6em;margin-bottom:0}#chooseqtype .qtypeoption
img{padding-right:.5em;padding-left:1em;vertical-align:text-bottom}#chooseqtype
.selected{background-color:#fff;-webkit-box-shadow:0 0 10px 0 #ccc;-moz-box-shadow:0 0 10px 0 #ccc;box-shadow:0 0 10px 0 #ccc}#chooseqtype .instruction,#chooseqtype
.qtypesummary{position:absolute;top:0;right:0;bottom:0;left:60%;display:none;padding:1.5em 1.6em;margin:0;overflow-x:hidden;overflow-y:auto;background-color:#fff}#chooseqtype .instruction,#chooseqtype .selected
.qtypesummary{display:block}#categoryquestions{margin:0}#categoryquestions td,#categoryquestions
th{padding:0
.2em}#categoryquestions
th{font-weight:normal;text-align:left}#categoryquestions
.checkbox{padding-left:5px}#categoryquestions .checkbox input[type="checkbox"]{float:none;margin-left:0}#categoryquestions
img.iconsmall{padding:0}#categoryquestions
.iconcol{padding:3px}#categoryquestions
label{margin:0}#page-mod-quiz-edit div.questionbankwindow
div.header{margin:0}#page-mod-quiz-edit
div.questionbankwindow.block{padding:0}.dir-rtl #categoryquestions
th{text-align:right}.questionbank
.singleselect{margin:0}#combinedfeedbackhdr
div.fhtmleditor{padding:0}#combinedfeedbackhdr
div.fcheckbox{margin-bottom:1em}#multitriesheader
div.fitem_feditor{margin-top:1em}#multitriesheader
div.fitem_fgroup{margin-bottom:1em}#multitriesheader div.fitem_fgroup fieldset.felement
label{margin-right:.3em;margin-left:.3em}body.path-question-type .fitem_fgroup
.accesshide{position:static;left:0;padding-right:.3em;font:inherit}.que{margin:0
auto 1.8em auto;clear:left;text-align:left}.dir-rtl
.que{text-align:right}.que
.info{float:left;width:7em;padding:.5em;margin-bottom:1.8em;background-color:#eee;border:1px
solid #dcdcdc;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}.que
h3.no{margin:0;font-size:.8em;line-height:1}.que
span.qno{font-size:1.5em;font-weight:bold}.que .info>div{margin-top:.7em;font-size:.8em}.que .info
.questionflag.editable{cursor:pointer}.que .info .editquestion img,.que .info .questionflag img,.que .info .questionflag
input{vertical-align:bottom}.que
.content{margin:0
0 0 8.5em}.que .formulation,.que .outcome,.que
.comment{padding:8px
35px 8px 14px;margin-bottom:20px;color:#c09853;text-shadow:0 1px 0 rgba(255,255,255,0.5);background-color:#fcf8e3;border:1px
solid #fbeed5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.que
.formulation{color:#3a87ad;color:#333;background-color:#d9edf7;border-color:#bce8f1}.formulation input[type="text"],.formulation
select{width:auto}.path-mod-quiz input[size]{width:auto}.que
.comment{color:#468847;background-color:#dff0d8;border-color:#d6e9c6}.que
.history{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.que .history
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.que
.ablock{margin:.7em 0 .3em 0}.que .im-controls{margin-top:.5em;text-align:left}.dir-rtl .que .im-controls{text-align:right}.que .specificfeedback,.que .generalfeedback,.que .rightanswer,.que .im-feedback,.que .feedback,.que
p{margin:0
0 .5em}.que
.qtext{margin-bottom:1.5em}.que
.correctness{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);white-space:nowrap;vertical-align:baseline;background-color:#999;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.que .correctness:empty{display:none}.que .correctness-important{background-color:#b94a48}.que .correctness-important[href]{background-color:#953b39}.que .correctness-warning{background-color:#f89406}.que .correctness-warning[href]{background-color:#c67605}.que .correctness-success{background-color:#468847}.que .correctness-success[href]{background-color:#356635}.que .correctness-info{background-color:#3a87ad}.que .correctness-info[href]{background-color:#2d6987}.que .correctness-inverse{background-color:#333}.que .correctness-inverse[href]{background-color:#1a1a1a}.que
.correctness.correct{background-color:#468847}.que
.correctness.partiallycorrect{background-color:#f89406}.que .correctness.notanswered,.que
.correctness.incorrect{background-color:#b94a48}.que
.validationerror{color:#b94a48}.formulation
.correct{background-color:#dff0d8}.formulation
.partiallycorrect{background-color:#fcf8e3}.formulation
.incorrect{background-color:#f2dede}.formulation select.correct,.formulation
input.correct{color:#468847;background-color:#dff0d8;border-color:#468847;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.formulation select.correct:focus,.formulation input.correct:focus{border-color:#356635;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b}.formulation select.partiallycorrect,.formulation
input.partiallycorrect{color:#c09853;background-color:#fcf8e3;border-color:#c09853;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.formulation select.partiallycorrect:focus,.formulation input.partiallycorrect:focus{border-color:#a47e3c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #dbc59e;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #dbc59e;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #dbc59e}.formulation select.incorrect,.formulation
input.incorrect{color:#b94a48;background-color:#f2dede;border-color:#b94a48;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.formulation select.incorrect:focus,.formulation input.incorrect:focus{border-color:#953b39;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392}.que .grading,.que .comment,.que .commentlink,.que
.history{margin-top:.5em}.que .history
h3{margin:0
0 .2em;font-size:1em}.que .history
table{width:100%;margin:0}.que .history
.current{font-weight:bold}.que
.questioncorrectnessicon{vertical-align:text-bottom}.que
input.questionflagimage{padding-right:3px}.dir-rtl .que
input.questionflagimage{padding-right:0;padding-left:3px}.importerror{margin-top:10px;border-bottom:1px solid #555}.mform .que.comment
.fitemtitle{width:20%}#page-question-preview
#techinfo{margin:1em
0}.dir-rtl #chooseqtype .instruction,.dir-rtl #chooseqtype
.qtypesummary{right:60%;left:0;border-right:1px solid grey;border-left:0}#page-mod-quiz-edit
.box.generalbox.questionbank{padding:.5em}#page-mod-quiz-edit .questionbank .categorypagingbarcontainer,#page-mod-quiz-edit .questionbank .categoryquestionscontainer,#page-mod-quiz-edit .questionbank
.choosecategory{padding:0}#page-mod-quiz-edit .questionbank .choosecategory
select{width:100%}#page-mod-quiz-edit div.questionbank
.categoryquestionscontainer{background:transparent}#page-mod-quiz-edit #categoryquestions>thead{background:#FFF}#page-mod-quiz-edit #categoryquestions>tbody>tr:nth-of-type(even){background:#e4e4e4}#page-mod-quiz-edit .questionbankwindow
div.header{padding:3px;padding:2px
10px 2px 10px;margin:0
-10px 0 -10px;color:#444;text-shadow:none;background:transparent;-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topright:4px;-moz-border-radius-topleft:4px}#page-mod-quiz-edit .questionbankwindow div.header a:link,#page-mod-quiz-edit .questionbankwindow div.header a:visited{color:#0070a8}#page-mod-quiz-edit .questionbankwindow div.header a:hover{color:#003d5c}#page-mod-quiz-edit
.createnewquestion{padding:.3em 0}#page-mod-quiz-edit .createnewquestion div,#page-mod-quiz-edit .createnewquestion
input{margin:0}#page-mod-quiz-edit .questionbankwindow div.header
.title{color:#333}#page-mod-quiz-edit div.container
div.generalbox{padding:1.5em;background-color:transparent}#page-mod-quiz-edit
.categoryinfo{background-color:transparent;border-bottom:0}#page-mod-quiz-edit .createnewquestion .singlebutton
input{margin-bottom:0}#page-mod-quiz-edit div.questionbank .categorysortopotionscontainer,#page-mod-quiz-edit div.questionbank
.categoryselectallcontainer{padding:0
0 1.5em 0}#page-mod-quiz-edit div.questionbank
.categorypagingbarcontainer{margin:0;background-color:transparent;border-top:0;border-bottom:0}#page-mod-quiz-edit div.questionbank .categorypagingbarcontainer
.paging{padding:0
.3em}#page-mod-quiz-edit div.question div.content
div.questioncontrols{background-color:#fff}#page-mod-quiz-edit div.question div.content
div.points{padding-bottom:.5em;margin-top:-0.5em;background-color:#fff;border:0}#page-mod-quiz-edit div.question div.content div.points
label{display:inline-block}#page-mod-quiz-edit div.quizpage .pagecontent
.pagestatus{background-color:#fff}#page-mod-quiz-edit .quizpagedelete,#page-mod-quiz-edit .quizpagedelete
img{background-color:transparent}#page-mod-quiz-edit div.quizpage
.pagecontent{overflow:hidden;border:1px
solid #ddd;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}#page-mod-quiz-edit div.questionbank
.categoryinfo{padding:.3em 0}#page-mod-quiz-edit div.questionbank
.modulespecificbuttonscontainer{padding:0}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
strong{display:block}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer hr,#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
br{display:none}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
strong{margin-left:-0.3em}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer strong
label{margin-left:.3em}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
input{margin-left:0}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer input+input{margin-left:5px}.questionbankwindow
.module{width:auto}#page-mod-quiz-edit div.editq div.question
div.content{overflow:hidden;background-color:#fff;border:1px
solid #ddd;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}.path-mod-quiz
.statedetails{display:block;font-size:.9em}a#hidebankcmd{color:#0070a8}.que.shortanswer
.answer{padding:0}.que
label{display:inline}body.path-question-type .mform
fieldset.hidden{padding:0;margin:.7em 0 0}.userprofile
.fullprofilelink{margin:10px;text-align:center}.userprofile
.description{margin-bottom:20px}.userprofile
dl.list{*zoom:1}.userprofile dl.list:before,.userprofile dl.list:after{display:table;line-height:0;content:""}.userprofile dl.list:after{clear:both}.userprofile dl.list
dt{float:left;width:180px;overflow:hidden;clear:left;text-align:right;text-overflow:ellipsis;white-space:nowrap}.userprofile dl.list
dd{margin-left:200px}.user-box{float:left;width:115px;height:160px;margin:8px;clear:none;text-align:center}.dir-rtl .userprofile
.description{margin-right:0}.dir-rtl .user-box{float:right}.dir-rtl .userprofile dl.list
dt{float:right;padding-left:10px;text-align:left}.dir-rtl .userprofile dl.list
dd{margin-left:0}.userlist .action-icon
img{vertical-align:middle}.userlist
#showall{margin:10px
0}.userlist
.buttons{text-align:center}.userlist .buttons
label{padding:0
3px}.userlist
table#participants{text-align:center}.userlist table#participants td,.userlist table#participants
th{padding:4px;text-align:left;vertical-align:middle}.userlist
table.controls{width:100%}.userlist table.controls
tr{vertical-align:top}.userlist table.controls
.right{text-align:right}.userlist table.controls
.groupselector{margin-top:0;margin-bottom:0}.userlist table.controls .groupselector
label{display:block}.userinfobox{width:100%;padding:10px;border:1px
solid;border-collapse:separate}.userinfobox .left,.userinfobox
.side{width:100px;vertical-align:top}.userinfobox
.userpicture{width:100px;height:100px}.userinfobox
.content{vertical-align:top}.userinfobox
.links{width:100px;padding:5px;vertical-align:bottom}.userinfobox .links
a{display:block}.userinfobox .list
td{padding:3px}.userinfobox
.username{padding-bottom:20px;font-weight:bold}.userinfobox
td.label{font-weight:bold;text-align:right;white-space:nowrap;vertical-align:top}.groupinfobox{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.groupinfobox
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.groupinfobox
.left{width:100px;padding:10px;vertical-align:top}.course-participation
#showall{margin:10px
0;text-align:center}#user-policy
.noticebox{width:80%;height:250px;margin-right:auto;margin-bottom:10px;margin-left:auto;text-align:center}#user-policy
#policyframe{width:100%;height:100%}.iplookup
#map{margin:auto}.userselector
select{width:100%}.userselector
div{margin-top:.2em}.userselector div
label{margin-right:.3em}.userselector .userselector-infobelow{font-size:.8em}#userselector_options{padding:.3em 0}#userselector_options
.collapsibleregioncaption{font-weight:bold}#userselector_options
p{margin:.2em 0;text-align:left}.dir-rtl #userselector_options
p{text-align:right}#page-user-profile
.messagebox{margin-right:auto;margin-left:auto;text-align:center}#page-course-view-weeks
.messagebox{margin-right:auto;margin-left:auto;text-align:center}.dir-rtl .userprofilebox
.descriptionbox{margin:0}.dir-rtl .userlist table#participants td,.dir-rtl .userlist table#participants
th{text-align:right}.dir-rtl .userlist
table#participants{margin:0
auto}#page-my-index.dir-rtl .block
h3{text-align:right}.profileeditor>.singleselect{margin:0
.5em 0 0}.profileeditor>.singlebutton{display:inline-block;margin:0
0 0 .5em}.profileeditor>.singlebutton div,.profileeditor>.singlebutton
input{margin:0}.dir-rtl .profileeditor>.singleselect{margin:0
0 0 .5em}.dir-rtl .profileeditor>.singlebutton{margin:0
.5em 0 0}.clearfix{*zoom:1}.clearfix:before,.clearfix:after{display:table;line-height:0;content:""}.clearfix:after{clear:both}.hide-text{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.input-block-level{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}article,aside,details,figcaption,figure,footer,header,hgroup,nav,section{display:block}audio,canvas,video{display:inline-block;*display:inline;*zoom:1}audio:not([controls]){display:none}html{font-size:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}a:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}a:hover,a:active{outline:0}sub,sup{position:relative;font-size:75%;line-height:0;vertical-align:baseline}sup{top:-0.5em}sub{bottom:-0.25em}.img-responsive{width:auto\9;height:auto;max-width:100%;-ms-interpolation-mode:bicubic}img{vertical-align:middle;border:0}#map_canvas img,.google-maps
img{max-width:none}button,input,select,textarea{margin:0;font-size:100%;vertical-align:middle}button,input{*overflow:visible;line-height:normal}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}button,html input[type="button"],input[type="reset"],input[type="submit"]{cursor:pointer;-webkit-appearance:button}label,select,button,input[type="button"],input[type="reset"],input[type="submit"],input[type="radio"],input[type="checkbox"]{cursor:pointer}input[type="search"]{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;-webkit-appearance:textfield}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button{-webkit-appearance:none}textarea{overflow:auto;vertical-align:top}@media
print{*{color:#000!important;text-shadow:none!important;background:transparent!important;box-shadow:none!important}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}.ir a:after,a[href^="javascript:"]:after,a[href^="#"]:after{content:""}pre,blockquote{border:1px
solid #999;page-break-inside:avoid}thead{display:table-header-group}tr,img{page-break-inside:avoid}img{max-width:100%!important}@page{margin:.5cm}p,h2,h3{orphans:3;widows:3}h2,h3{page-break-after:avoid}}body{margin:0;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:14px;line-height:20px;color:#333;background-color:#fff}a{color:#0070a8;text-decoration:none}a:hover,a:focus{color:#003d5c;text-decoration:underline}.img-rounded{-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.img-polaroid{padding:4px;background-color:#fff;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.2);-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.1);-moz-box-shadow:0 1px 3px rgba(0,0,0,0.1);box-shadow:0 1px 3px rgba(0,0,0,0.1)}.img-circle{-webkit-border-radius:500px;-moz-border-radius:500px;border-radius:500px}.row{margin-left:-20px;*zoom:1}.row:before,.row:after{display:table;line-height:0;content:""}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:20px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:940px}.span12{width:940px}.span11{width:860px}.span10{width:780px}.span9{width:700px}.span8{width:620px}.span7{width:540px}.span6{width:460px}.span5{width:380px}.span4{width:300px}.span3{width:220px}.span2{width:140px}.span1{width:60px}.offset12{margin-left:980px}.offset11{margin-left:900px}.offset10{margin-left:820px}.offset9{margin-left:740px}.offset8{margin-left:660px}.offset7{margin-left:580px}.offset6{margin-left:500px}.offset5{margin-left:420px}.offset4{margin-left:340px}.offset3{margin-left:260px}.offset2{margin-left:180px}.offset1{margin-left:100px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;line-height:0;content:""}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;float:left;width:100%;min-height:30px;margin-left:2.127659574468085%;*margin-left:2.074468085106383%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.127659574468085%}.row-fluid
.span12{width:100%;*width:99.94680851063829%}.row-fluid
.span11{width:91.48936170212765%;*width:91.43617021276594%}.row-fluid
.span10{width:82.97872340425532%;*width:82.92553191489361%}.row-fluid
.span9{width:74.46808510638297%;*width:74.41489361702126%}.row-fluid
.span8{width:65.95744680851064%;*width:65.90425531914893%}.row-fluid
.span7{width:57.44680851063829%;*width:57.39361702127659%}.row-fluid
.span6{width:48.93617021276595%;*width:48.88297872340425%}.row-fluid
.span5{width:40.42553191489362%;*width:40.37234042553192%}.row-fluid
.span4{width:31.914893617021278%;*width:31.861702127659576%}.row-fluid
.span3{width:23.404255319148934%;*width:23.351063829787233%}.row-fluid
.span2{width:14.893617021276595%;*width:14.840425531914894%}.row-fluid
.span1{width:6.382978723404255%;*width:6.329787234042553%}.row-fluid
.offset12{margin-left:104.25531914893617%;*margin-left:104.14893617021275%}.row-fluid .offset12:first-child{margin-left:102.12765957446808%;*margin-left:102.02127659574467%}.row-fluid
.offset11{margin-left:95.74468085106382%;*margin-left:95.6382978723404%}.row-fluid .offset11:first-child{margin-left:93.61702127659574%;*margin-left:93.51063829787232%}.row-fluid
.offset10{margin-left:87.23404255319149%;*margin-left:87.12765957446807%}.row-fluid .offset10:first-child{margin-left:85.1063829787234%;*margin-left:84.99999999999999%}.row-fluid
.offset9{margin-left:78.72340425531914%;*margin-left:78.61702127659572%}.row-fluid .offset9:first-child{margin-left:76.59574468085106%;*margin-left:76.48936170212764%}.row-fluid
.offset8{margin-left:70.2127659574468%;*margin-left:70.10638297872339%}.row-fluid .offset8:first-child{margin-left:68.08510638297872%;*margin-left:67.9787234042553%}.row-fluid
.offset7{margin-left:61.70212765957446%;*margin-left:61.59574468085106%}.row-fluid .offset7:first-child{margin-left:59.574468085106375%;*margin-left:59.46808510638297%}.row-fluid
.offset6{margin-left:53.191489361702125%;*margin-left:53.085106382978715%}.row-fluid .offset6:first-child{margin-left:51.063829787234035%;*margin-left:50.95744680851063%}.row-fluid
.offset5{margin-left:44.68085106382979%;*margin-left:44.57446808510638%}.row-fluid .offset5:first-child{margin-left:42.5531914893617%;*margin-left:42.4468085106383%}.row-fluid
.offset4{margin-left:36.170212765957444%;*margin-left:36.06382978723405%}.row-fluid .offset4:first-child{margin-left:34.04255319148936%;*margin-left:33.93617021276596%}.row-fluid
.offset3{margin-left:27.659574468085104%;*margin-left:27.5531914893617%}.row-fluid .offset3:first-child{margin-left:25.53191489361702%;*margin-left:25.425531914893618%}.row-fluid
.offset2{margin-left:19.148936170212764%;*margin-left:19.04255319148936%}.row-fluid .offset2:first-child{margin-left:17.02127659574468%;*margin-left:16.914893617021278%}.row-fluid
.offset1{margin-left:10.638297872340425%;*margin-left:10.53191489361702%}.row-fluid .offset1:first-child{margin-left:8.51063829787234%;*margin-left:8.404255319148938%}[class*="span"].hide,.row-fluid [class*="span"].hide{display:none}[class*="span"].pull-right,.row-fluid [class*="span"].pull-right{float:right}.container{margin-right:auto;margin-left:auto;*zoom:1}.container:before,.container:after{display:table;line-height:0;content:""}.container:after{clear:both}.container-fluid{padding-right:20px;padding-left:20px;*zoom:1}.container-fluid:before,.container-fluid:after{display:table;line-height:0;content:""}.container-fluid:after{clear:both}p{margin:0
0 10px}.lead{margin-bottom:20px;font-size:21px;font-weight:200;line-height:30px}small{font-size:85%}strong{font-weight:bold}em{font-style:italic}cite{font-style:normal}.muted{color:#999}a.muted:hover,a.muted:focus{color:#808080}.text-warning{color:#c09853}a.text-warning:hover,a.text-warning:focus{color:#a47e3c}.text-error{color:#b94a48}a.text-error:hover,a.text-error:focus{color:#953b39}.text-info{color:#3a87ad}a.text-info:hover,a.text-info:focus{color:#2d6987}.text-success{color:#468847}a.text-success:hover,a.text-success:focus{color:#356635}.text-left{text-align:left}.text-right{text-align:right}.text-center{text-align:center}h1,h2,h3,h4,h5,h6{margin:10px
0;font-family:inherit;font-weight:bold;line-height:20px;color:inherit;text-rendering:optimizelegibility}h1 small,h2 small,h3 small,h4 small,h5 small,h6
small{font-weight:normal;line-height:1;color:#999}h1,h2,h3{line-height:40px}h1{font-size:38.5px}h2{font-size:31.5px}h3{font-size:24.5px}h4{font-size:17.5px}h5{font-size:14px}h6{font-size:11.9px}h1
small{font-size:24.5px}h2
small{font-size:17.5px}h3
small{font-size:14px}h4
small{font-size:14px}.page-header{padding-bottom:9px;margin:20px
0 30px;border-bottom:1px solid #eee}ul,ol{padding:0;margin:0
0 10px 25px}ul ul,ul ol,ol ol,ol
ul{margin-bottom:0}li{line-height:20px}ul.unstyled,ol.unstyled{margin-left:0;list-style:none}ul.inline,ol.inline{margin-left:0;list-style:none}ul.inline>li,ol.inline>li{display:inline-block;*display:inline;padding-right:5px;padding-left:5px;*zoom:1}dl{margin-bottom:20px}dt,dd{line-height:20px}dt{font-weight:bold}dd{margin-left:10px}.dl-horizontal{*zoom:1}.dl-horizontal:before,.dl-horizontal:after{display:table;line-height:0;content:""}.dl-horizontal:after{clear:both}.dl-horizontal
dt{float:left;width:180px;overflow:hidden;clear:left;text-align:right;text-overflow:ellipsis;white-space:nowrap}.dl-horizontal
dd{margin-left:200px}hr{margin:20px
0;border:0;border-top:1px solid #eee;border-bottom:1px solid #fff}abbr[title],abbr[data-original-title]{cursor:help;border-bottom:1px dotted #999}abbr.initialism{font-size:90%;text-transform:uppercase}blockquote{padding:0
0 0 15px;margin:0
0 20px;border-left:5px solid #eee}blockquote
p{margin-bottom:0;font-size:17.5px;font-weight:300;line-height:1.25}blockquote
small{display:block;line-height:20px;color:#999}blockquote small:before{content:'\2014 \00A0'}blockquote.pull-right{float:right;padding-right:15px;padding-left:0;border-right:5px solid #eee;border-left:0}blockquote.pull-right p,blockquote.pull-right
small{text-align:right}blockquote.pull-right small:before{content:''}blockquote.pull-right small:after{content:'\00A0 \2014'}q:before,q:after,blockquote:before,blockquote:after{content:""}address{display:block;margin-bottom:20px;font-style:normal;line-height:20px}code,pre{padding:0
3px 2px;font-family:Monaco,Menlo,Consolas,"Courier New",monospace;font-size:12px;color:#333;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}code{padding:2px
4px;color:#d14;white-space:nowrap;background-color:#f7f7f9;border:1px
solid #e1e1e8}pre{display:block;padding:9.5px;margin:0
0 10px;font-size:13px;line-height:20px;word-break:break-all;word-wrap:break-word;white-space:pre;white-space:pre-wrap;background-color:#f5f5f5;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.15);-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}pre.prettyprint{margin-bottom:20px}pre
code{padding:0;color:inherit;white-space:pre;white-space:pre-wrap;background-color:transparent;border:0}.pre-scrollable{max-height:340px;overflow-y:scroll}form{margin:0
0 20px}fieldset{padding:0;margin:0;border:0}legend{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:40px;color:#333;border:0;border-bottom:1px solid #e5e5e5}legend
small{font-size:15px;color:#999}label,input,button,select,textarea{font-size:14px;font-weight:normal;line-height:20px}input,button,select,textarea{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif}label{display:block;margin-bottom:5px}select,textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"],.uneditable-input{display:inline-block;height:20px;padding:4px
6px;margin-bottom:10px;font-size:14px;line-height:20px;color:#555;vertical-align:middle;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}input,textarea,.uneditable-input{width:206px}textarea{height:auto}textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"],.uneditable-input{background-color:#fff;border:1px
solid #ccc;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-webkit-transition:border linear .2s,box-shadow linear .2s;-moz-transition:border linear .2s,box-shadow linear .2s;-o-transition:border linear .2s,box-shadow linear .2s;transition:border linear .2s,box-shadow linear .2s}textarea:focus,input[type="text"]:focus,input[type="password"]:focus,input[type="datetime"]:focus,input[type="datetime-local"]:focus,input[type="date"]:focus,input[type="month"]:focus,input[type="time"]:focus,input[type="week"]:focus,input[type="number"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="search"]:focus,input[type="tel"]:focus,input[type="color"]:focus,.uneditable-input:focus{border-color:rgba(82,168,236,0.8);outline:0;outline:thin dotted \9;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6)}input[type="radio"],input[type="checkbox"]{margin:4px
0 0;margin-top:1px \9;*margin-top:0;line-height:normal}input[type="file"],input[type="image"],input[type="submit"],input[type="reset"],input[type="button"],input[type="radio"],input[type="checkbox"]{width:auto}select,input[type="file"]{height:30px;*margin-top:4px;line-height:30px}select{width:220px;background-color:#fff;border:1px
solid #ccc}select[multiple],select[size]{height:auto}select:focus,input[type="file"]:focus,input[type="radio"]:focus,input[type="checkbox"]:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}.uneditable-input,.uneditable-textarea{color:#999;cursor:not-allowed;background-color:#fcfcfc;border-color:#ccc;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.025);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.025);box-shadow:inset 0 1px 2px rgba(0,0,0,0.025)}.uneditable-input{overflow:hidden;white-space:nowrap}.uneditable-textarea{width:auto;height:auto}input:-moz-placeholder,textarea:-moz-placeholder{color:#999}input:-ms-input-placeholder,textarea:-ms-input-placeholder{color:#999}input::-webkit-input-placeholder,textarea::-webkit-input-placeholder{color:#999}.radio,.checkbox{min-height:20px;padding-left:20px}.radio input[type="radio"],.checkbox input[type="checkbox"]{float:left;margin-left:-20px}.controls>.radio:first-child,.controls>.checkbox:first-child{padding-top:5px}.radio.inline,.checkbox.inline{display:inline-block;padding-top:5px;margin-bottom:0;vertical-align:middle}.radio.inline+.radio.inline,.checkbox.inline+.checkbox.inline{margin-left:10px}.input-mini{width:60px}.input-small{width:90px}.input-medium{width:150px}.input-large{width:210px}.input-xlarge{width:270px}.input-xxlarge{width:530px}input[class*="span"],select[class*="span"],textarea[class*="span"],.uneditable-input[class*="span"],.row-fluid input[class*="span"],.row-fluid select[class*="span"],.row-fluid textarea[class*="span"],.row-fluid .uneditable-input[class*="span"]{float:none;margin-left:0}.input-append input[class*="span"],.input-append .uneditable-input[class*="span"],.input-prepend input[class*="span"],.input-prepend .uneditable-input[class*="span"],.row-fluid input[class*="span"],.row-fluid select[class*="span"],.row-fluid textarea[class*="span"],.row-fluid .uneditable-input[class*="span"],.row-fluid .input-prepend [class*="span"],.row-fluid .input-append [class*="span"]{display:inline-block}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:20px}input.span12,textarea.span12,.uneditable-input.span12{width:926px}input.span11,textarea.span11,.uneditable-input.span11{width:846px}input.span10,textarea.span10,.uneditable-input.span10{width:766px}input.span9,textarea.span9,.uneditable-input.span9{width:686px}input.span8,textarea.span8,.uneditable-input.span8{width:606px}input.span7,textarea.span7,.uneditable-input.span7{width:526px}input.span6,textarea.span6,.uneditable-input.span6{width:446px}input.span5,textarea.span5,.uneditable-input.span5{width:366px}input.span4,textarea.span4,.uneditable-input.span4{width:286px}input.span3,textarea.span3,.uneditable-input.span3{width:206px}input.span2,textarea.span2,.uneditable-input.span2{width:126px}input.span1,textarea.span1,.uneditable-input.span1{width:46px}.controls-row{*zoom:1}.controls-row:before,.controls-row:after{display:table;line-height:0;content:""}.controls-row:after{clear:both}.controls-row [class*="span"],.row-fluid .controls-row [class*="span"]{float:left}.controls-row .checkbox[class*="span"],.controls-row .radio[class*="span"]{padding-top:5px}input[disabled],select[disabled],textarea[disabled],input[readonly],select[readonly],textarea[readonly]{cursor:not-allowed;background-color:#eee}input[type="radio"][disabled],input[type="checkbox"][disabled],input[type="radio"][readonly],input[type="checkbox"][readonly]{background-color:transparent}.control-group.warning .control-label,.control-group.warning .help-block,.control-group.warning .help-inline{color:#c09853}.control-group.warning .checkbox,.control-group.warning .radio,.control-group.warning input,.control-group.warning select,.control-group.warning
textarea{color:#c09853}.control-group.warning input,.control-group.warning select,.control-group.warning
textarea{border-color:#c09853;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.warning input:focus,.control-group.warning select:focus,.control-group.warning textarea:focus{border-color:#a47e3c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #dbc59e;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #dbc59e;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #dbc59e}.control-group.warning .input-prepend .add-on,.control-group.warning .input-append .add-on{color:#c09853;background-color:#fcf8e3;border-color:#c09853}.control-group.error .control-label,.control-group.error .help-block,.control-group.error .help-inline{color:#b94a48}.control-group.error .checkbox,.control-group.error .radio,.control-group.error input,.control-group.error select,.control-group.error
textarea{color:#b94a48}.control-group.error input,.control-group.error select,.control-group.error
textarea{border-color:#b94a48;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.error input:focus,.control-group.error select:focus,.control-group.error textarea:focus{border-color:#953b39;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392}.control-group.error .input-prepend .add-on,.control-group.error .input-append .add-on{color:#b94a48;background-color:#f2dede;border-color:#b94a48}.control-group.success .control-label,.control-group.success .help-block,.control-group.success .help-inline{color:#468847}.control-group.success .checkbox,.control-group.success .radio,.control-group.success input,.control-group.success select,.control-group.success
textarea{color:#468847}.control-group.success input,.control-group.success select,.control-group.success
textarea{border-color:#468847;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.success input:focus,.control-group.success select:focus,.control-group.success textarea:focus{border-color:#356635;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b}.control-group.success .input-prepend .add-on,.control-group.success .input-append .add-on{color:#468847;background-color:#dff0d8;border-color:#468847}.control-group.info .control-label,.control-group.info .help-block,.control-group.info .help-inline{color:#3a87ad}.control-group.info .checkbox,.control-group.info .radio,.control-group.info input,.control-group.info select,.control-group.info
textarea{color:#3a87ad}.control-group.info input,.control-group.info select,.control-group.info
textarea{border-color:#3a87ad;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.info input:focus,.control-group.info select:focus,.control-group.info textarea:focus{border-color:#2d6987;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7ab5d3;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7ab5d3;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7ab5d3}.control-group.info .input-prepend .add-on,.control-group.info .input-append .add-on{color:#3a87ad;background-color:#d9edf7;border-color:#3a87ad}input:focus:invalid,textarea:focus:invalid,select:focus:invalid{color:#b94a48;border-color:#ee5f5b}input:focus:invalid:focus,textarea:focus:invalid:focus,select:focus:invalid:focus{border-color:#e9322d;-webkit-box-shadow:0 0 6px #f8b9b7;-moz-box-shadow:0 0 6px #f8b9b7;box-shadow:0 0 6px #f8b9b7}.form-actions{padding:19px
20px 20px;margin-top:20px;margin-bottom:20px;background-color:#f5f5f5;border-top:1px solid #e5e5e5;*zoom:1}.form-actions:before,.form-actions:after{display:table;line-height:0;content:""}.form-actions:after{clear:both}.help-block,.help-inline{color:#595959}.help-block{display:block;margin-bottom:10px}.help-inline{display:inline-block;*display:inline;padding-left:5px;vertical-align:middle;*zoom:1}.input-append,.input-prepend{display:inline-block;margin-bottom:10px;font-size:0;white-space:nowrap;vertical-align:middle}.input-append input,.input-prepend input,.input-append select,.input-prepend select,.input-append .uneditable-input,.input-prepend .uneditable-input,.input-append .dropdown-menu,.input-prepend .dropdown-menu,.input-append .popover,.input-prepend
.popover{font-size:14px}.input-append input,.input-prepend input,.input-append select,.input-prepend select,.input-append .uneditable-input,.input-prepend .uneditable-input{position:relative;margin-bottom:0;*margin-left:0;vertical-align:top;-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-append input:focus,.input-prepend input:focus,.input-append select:focus,.input-prepend select:focus,.input-append .uneditable-input:focus,.input-prepend .uneditable-input:focus{z-index:2}.input-append .add-on,.input-prepend .add-on{display:inline-block;width:auto;height:20px;min-width:16px;padding:4px
5px;font-size:14px;font-weight:normal;line-height:20px;text-align:center;text-shadow:0 1px 0 #fff;background-color:#eee;border:1px
solid #ccc}.input-append .add-on,.input-prepend .add-on,.input-append .btn,.input-prepend .btn,.input-append .btn-group>.dropdown-toggle,.input-prepend .btn-group>.dropdown-toggle{vertical-align:top;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.input-append .active,.input-prepend
.active{background-color:#a9dba9;border-color:#46a546}.input-prepend .add-on,.input-prepend
.btn{margin-right:-1px}.input-prepend .add-on:first-child,.input-prepend .btn:first-child{-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.input-append input,.input-append select,.input-append .uneditable-input{-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.input-append input+.btn-group .btn:last-child,.input-append select+.btn-group .btn:last-child,.input-append .uneditable-input+.btn-group .btn:last-child{-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-append .add-on,.input-append .btn,.input-append .btn-group{margin-left:-1px}.input-append .add-on:last-child,.input-append .btn:last-child,.input-append .btn-group:last-child>.dropdown-toggle{-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-prepend.input-append input,.input-prepend.input-append select,.input-prepend.input-append .uneditable-input{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.input-prepend.input-append input+.btn-group .btn,.input-prepend.input-append select+.btn-group .btn,.input-prepend.input-append .uneditable-input+.btn-group
.btn{-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-prepend.input-append .add-on:first-child,.input-prepend.input-append .btn:first-child{margin-right:-1px;-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.input-prepend.input-append .add-on:last-child,.input-prepend.input-append .btn:last-child{margin-left:-1px;-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-prepend.input-append .btn-group:first-child{margin-left:0}input.search-query{padding-right:14px;padding-right:4px \9;padding-left:14px;padding-left:4px \9;margin-bottom:0;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.form-search .input-append .search-query,.form-search .input-prepend .search-query{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.form-search .input-append .search-query{-webkit-border-radius:14px 0 0 14px;-moz-border-radius:14px 0 0 14px;border-radius:14px 0 0 14px}.form-search .input-append
.btn{-webkit-border-radius:0 14px 14px 0;-moz-border-radius:0 14px 14px 0;border-radius:0 14px 14px 0}.form-search .input-prepend .search-query{-webkit-border-radius:0 14px 14px 0;-moz-border-radius:0 14px 14px 0;border-radius:0 14px 14px 0}.form-search .input-prepend
.btn{-webkit-border-radius:14px 0 0 14px;-moz-border-radius:14px 0 0 14px;border-radius:14px 0 0 14px}.form-search input,.form-inline input,.form-horizontal input,.form-search textarea,.form-inline textarea,.form-horizontal textarea,.form-search select,.form-inline select,.form-horizontal select,.form-search .help-inline,.form-inline .help-inline,.form-horizontal .help-inline,.form-search .uneditable-input,.form-inline .uneditable-input,.form-horizontal .uneditable-input,.form-search .input-prepend,.form-inline .input-prepend,.form-horizontal .input-prepend,.form-search .input-append,.form-inline .input-append,.form-horizontal .input-append{display:inline-block;*display:inline;margin-bottom:0;vertical-align:middle;*zoom:1}.form-search .hide,.form-inline .hide,.form-horizontal
.hide{display:none}.form-search label,.form-inline label,.form-search .btn-group,.form-inline .btn-group{display:inline-block}.form-search .input-append,.form-inline .input-append,.form-search .input-prepend,.form-inline .input-prepend{margin-bottom:0}.form-search .radio,.form-search .checkbox,.form-inline .radio,.form-inline
.checkbox{padding-left:0;margin-bottom:0;vertical-align:middle}.form-search .radio input[type="radio"],.form-search .checkbox input[type="checkbox"],.form-inline .radio input[type="radio"],.form-inline .checkbox input[type="checkbox"]{float:left;margin-right:3px;margin-left:0}.control-group{margin-bottom:10px}legend+.control-group{margin-top:20px;-webkit-margin-top-collapse:separate}.form-horizontal .control-group{margin-bottom:20px;*zoom:1}.form-horizontal .control-group:before,.form-horizontal .control-group:after{display:table;line-height:0;content:""}.form-horizontal .control-group:after{clear:both}.form-horizontal .control-label{float:left;width:180px;padding-top:5px;text-align:right}.form-horizontal
.controls{*display:inline-block;*padding-left:20px;margin-left:200px;*margin-left:0}.form-horizontal .controls:first-child{*padding-left:200px}.form-horizontal .help-block{margin-bottom:0}.form-horizontal input+.help-block,.form-horizontal select+.help-block,.form-horizontal textarea+.help-block,.form-horizontal .uneditable-input+.help-block,.form-horizontal .input-prepend+.help-block,.form-horizontal .input-append+.help-block{margin-top:10px}.form-horizontal .form-actions{padding-left:200px}table{max-width:100%;background-color:transparent;border-collapse:collapse;border-spacing:0}.table{width:100%;margin-bottom:20px}.table th,.table
td{padding:8px;line-height:20px;text-align:left;vertical-align:top;border-top:1px solid #ddd}.table
th{font-weight:bold}.table thead
th{vertical-align:bottom}.table caption+thead tr:first-child th,.table caption+thead tr:first-child td,.table colgroup+thead tr:first-child th,.table colgroup+thead tr:first-child td,.table thead:first-child tr:first-child th,.table thead:first-child tr:first-child
td{border-top:0}.table tbody+tbody{border-top:2px solid #ddd}.table
.table{background-color:#fff}.table-condensed th,.table-condensed
td{padding:4px
5px}.table-bordered{border:1px
solid #ddd;border-collapse:separate;*border-collapse:collapse;border-left:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.table-bordered th,.table-bordered
td{border-left:1px solid #ddd}.table-bordered caption+thead tr:first-child th,.table-bordered caption+tbody tr:first-child th,.table-bordered caption+tbody tr:first-child td,.table-bordered colgroup+thead tr:first-child th,.table-bordered colgroup+tbody tr:first-child th,.table-bordered colgroup+tbody tr:first-child td,.table-bordered thead:first-child tr:first-child th,.table-bordered tbody:first-child tr:first-child th,.table-bordered tbody:first-child tr:first-child
td{border-top:0}.table-bordered thead:first-child tr:first-child>th:first-child,.table-bordered tbody:first-child tr:first-child>td:first-child,.table-bordered tbody:first-child tr:first-child>th:first-child{-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topleft:4px}.table-bordered thead:first-child tr:first-child>th:last-child,.table-bordered tbody:first-child tr:first-child>td:last-child,.table-bordered tbody:first-child tr:first-child>th:last-child{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-moz-border-radius-topright:4px}.table-bordered thead:last-child tr:last-child>th:first-child,.table-bordered tbody:last-child tr:last-child>td:first-child,.table-bordered tbody:last-child tr:last-child>th:first-child,.table-bordered tfoot:last-child tr:last-child>td:first-child,.table-bordered tfoot:last-child tr:last-child>th:first-child{-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px}.table-bordered thead:last-child tr:last-child>th:last-child,.table-bordered tbody:last-child tr:last-child>td:last-child,.table-bordered tbody:last-child tr:last-child>th:last-child,.table-bordered tfoot:last-child tr:last-child>td:last-child,.table-bordered tfoot:last-child tr:last-child>th:last-child{-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px}.table-bordered tfoot+tbody:last-child tr:last-child td:first-child{-webkit-border-bottom-left-radius:0;border-bottom-left-radius:0;-moz-border-radius-bottomleft:0}.table-bordered tfoot+tbody:last-child tr:last-child td:last-child{-webkit-border-bottom-right-radius:0;border-bottom-right-radius:0;-moz-border-radius-bottomright:0}.table-bordered caption+thead tr:first-child th:first-child,.table-bordered caption+tbody tr:first-child td:first-child,.table-bordered colgroup+thead tr:first-child th:first-child,.table-bordered colgroup+tbody tr:first-child td:first-child{-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topleft:4px}.table-bordered caption+thead tr:first-child th:last-child,.table-bordered caption+tbody tr:first-child td:last-child,.table-bordered colgroup+thead tr:first-child th:last-child,.table-bordered colgroup+tbody tr:first-child td:last-child{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-moz-border-radius-topright:4px}.table-striped tbody>tr:nth-child(odd)>td,.table-striped tbody>tr:nth-child(odd)>th{background-color:#f9f9f9}.table-hover tbody tr:hover>td,.table-hover tbody tr:hover>th{background-color:#f5f5f5}table td[class*="span"],table th[class*="span"],.row-fluid table td[class*="span"],.row-fluid table th[class*="span"]{display:table-cell;float:none;margin-left:0}.table td.span1,.table
th.span1{float:none;width:44px;margin-left:0}.table td.span2,.table
th.span2{float:none;width:124px;margin-left:0}.table td.span3,.table
th.span3{float:none;width:204px;margin-left:0}.table td.span4,.table
th.span4{float:none;width:284px;margin-left:0}.table td.span5,.table
th.span5{float:none;width:364px;margin-left:0}.table td.span6,.table
th.span6{float:none;width:444px;margin-left:0}.table td.span7,.table
th.span7{float:none;width:524px;margin-left:0}.table td.span8,.table
th.span8{float:none;width:604px;margin-left:0}.table td.span9,.table
th.span9{float:none;width:684px;margin-left:0}.table td.span10,.table
th.span10{float:none;width:764px;margin-left:0}.table td.span11,.table
th.span11{float:none;width:844px;margin-left:0}.table td.span12,.table
th.span12{float:none;width:924px;margin-left:0}.table tbody tr.success>td{background-color:#dff0d8}.table tbody tr.error>td{background-color:#f2dede}.table tbody tr.warning>td{background-color:#fcf8e3}.table tbody tr.info>td{background-color:#d9edf7}.table-hover tbody tr.success:hover>td{background-color:#d0e9c6}.table-hover tbody tr.error:hover>td{background-color:#ebcccc}.table-hover tbody tr.warning:hover>td{background-color:#faf2cc}.table-hover tbody tr.info:hover>td{background-color:#c4e3f3}[class^="icon-"],[class*=" icon-"]{display:inline-block;width:14px;height:14px;margin-top:1px;*margin-right:.3em;line-height:14px;vertical-align:text-top;background-image:url("/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=glyphicons-halflings");background-position:14px 14px;background-repeat:no-repeat}.icon-white,.nav-pills>.active>a>[class^="icon-"],.nav-pills>.active>a>[class*=" icon-"],.nav-list>.active>a>[class^="icon-"],.nav-list>.active>a>[class*=" icon-"],.navbar-inverse .nav>.active>a>[class^="icon-"],.navbar-inverse .nav>.active>a>[class*=" icon-"],.dropdown-menu>li>a:hover>[class^="icon-"],.dropdown-menu>li>a:focus>[class^="icon-"],.dropdown-menu>li>a:hover>[class*=" icon-"],.dropdown-menu>li>a:focus>[class*=" icon-"],.dropdown-menu>.active>a>[class^="icon-"],.dropdown-menu>.active>a>[class*=" icon-"],.dropdown-submenu:hover>a>[class^="icon-"],.dropdown-submenu:focus>a>[class^="icon-"],.dropdown-submenu:hover>a>[class*=" icon-"],.dropdown-submenu:focus>a>[class*=" icon-"]{background-image:url("/moodle/theme/image.php?theme=clean&component=theme&rev=1488795260&image=glyphicons-halflings-white")}.icon-glass{background-position:0 0}.icon-music{background-position:-24px 0}.icon-search{background-position:-48px 0}.icon-envelope{background-position:-72px 0}.icon-heart{background-position:-96px 0}.icon-star{background-position:-120px 0}.icon-star-empty{background-position:-144px 0}.icon-user{background-position:-168px 0}.icon-film{background-position:-192px 0}.icon-th-large{background-position:-216px 0}.icon-th{background-position:-240px 0}.icon-th-list{background-position:-264px 0}.icon-ok{background-position:-288px 0}.icon-remove{background-position:-312px 0}.icon-zoom-in{background-position:-336px 0}.icon-zoom-out{background-position:-360px 0}.icon-off{background-position:-384px 0}.icon-signal{background-position:-408px 0}.icon-cog{background-position:-432px 0}.icon-trash{background-position:-456px 0}.icon-home{background-position:0 -24px}.icon-file{background-position:-24px -24px}.icon-time{background-position:-48px -24px}.icon-road{background-position:-72px -24px}.icon-download-alt{background-position:-96px -24px}.icon-download{background-position:-120px -24px}.icon-upload{background-position:-144px -24px}.icon-inbox{background-position:-168px -24px}.icon-play-circle{background-position:-192px -24px}.icon-repeat{background-position:-216px -24px}.icon-refresh{background-position:-240px -24px}.icon-list-alt{background-position:-264px -24px}.icon-lock{background-position:-287px -24px}.icon-flag{background-position:-312px -24px}.icon-headphones{background-position:-336px -24px}.icon-volume-off{background-position:-360px -24px}.icon-volume-down{background-position:-384px -24px}.icon-volume-up{background-position:-408px -24px}.icon-qrcode{background-position:-432px -24px}.icon-barcode{background-position:-456px -24px}.icon-tag{background-position:0 -48px}.icon-tags{background-position:-25px -48px}.icon-book{background-position:-48px -48px}.icon-bookmark{background-position:-72px -48px}.icon-print{background-position:-96px -48px}.icon-camera{background-position:-120px -48px}.icon-font{background-position:-144px -48px}.icon-bold{background-position:-167px -48px}.icon-italic{background-position:-192px -48px}.icon-text-height{background-position:-216px -48px}.icon-text-width{background-position:-240px -48px}.icon-align-left{background-position:-264px -48px}.icon-align-center{background-position:-288px -48px}.icon-align-right{background-position:-312px -48px}.icon-align-justify{background-position:-336px -48px}.icon-list{background-position:-360px -48px}.icon-indent-left{background-position:-384px -48px}.icon-indent-right{background-position:-408px -48px}.icon-facetime-video{background-position:-432px -48px}.icon-picture{background-position:-456px -48px}.icon-pencil{background-position:0 -72px}.icon-map-marker{background-position:-24px -72px}.icon-adjust{background-position:-48px -72px}.icon-tint{background-position:-72px -72px}.icon-edit{background-position:-96px -72px}.icon-share{background-position:-120px -72px}.icon-check{background-position:-144px -72px}.icon-move{background-position:-168px -72px}.icon-step-backward{background-position:-192px -72px}.icon-fast-backward{background-position:-216px -72px}.icon-backward{background-position:-240px -72px}.icon-play{background-position:-264px -72px}.icon-pause{background-position:-288px -72px}.icon-stop{background-position:-312px -72px}.icon-forward{background-position:-336px -72px}.icon-fast-forward{background-position:-360px -72px}.icon-step-forward{background-position:-384px -72px}.icon-eject{background-position:-408px -72px}.icon-chevron-left{background-position:-432px -72px}.icon-chevron-right{background-position:-456px -72px}.icon-plus-sign{background-position:0 -96px}.icon-minus-sign{background-position:-24px -96px}.icon-remove-sign{background-position:-48px -96px}.icon-ok-sign{background-position:-72px -96px}.icon-question-sign{background-position:-96px -96px}.icon-info-sign{background-position:-120px -96px}.icon-screenshot{background-position:-144px -96px}.icon-remove-circle{background-position:-168px -96px}.icon-ok-circle{background-position:-192px -96px}.icon-ban-circle{background-position:-216px -96px}.icon-arrow-left{background-position:-240px -96px}.icon-arrow-right{background-position:-264px -96px}.icon-arrow-up{background-position:-289px -96px}.icon-arrow-down{background-position:-312px -96px}.icon-share-alt{background-position:-336px -96px}.icon-resize-full{background-position:-360px -96px}.icon-resize-small{background-position:-384px -96px}.icon-plus{background-position:-408px -96px}.icon-minus{background-position:-433px -96px}.icon-asterisk{background-position:-456px -96px}.icon-exclamation-sign{background-position:0 -120px}.icon-gift{background-position:-24px -120px}.icon-leaf{background-position:-48px -120px}.icon-fire{background-position:-72px -120px}.icon-eye-open{background-position:-96px -120px}.icon-eye-close{background-position:-120px -120px}.icon-warning-sign{background-position:-144px -120px}.icon-plane{background-position:-168px -120px}.icon-calendar{background-position:-192px -120px}.icon-random{width:16px;background-position:-216px -120px}.icon-comment{background-position:-240px -120px}.icon-magnet{background-position:-264px -120px}.icon-chevron-up{background-position:-288px -120px}.icon-chevron-down{background-position:-313px -119px}.icon-retweet{background-position:-336px -120px}.icon-shopping-cart{background-position:-360px -120px}.icon-folder-close{width:16px;background-position:-384px -120px}.icon-folder-open{width:16px;background-position:-408px -120px}.icon-resize-vertical{background-position:-432px -119px}.icon-resize-horizontal{background-position:-456px -118px}.icon-hdd{background-position:0 -144px}.icon-bullhorn{background-position:-24px -144px}.icon-bell{background-position:-48px -144px}.icon-certificate{background-position:-72px -144px}.icon-thumbs-up{background-position:-96px -144px}.icon-thumbs-down{background-position:-120px -144px}.icon-hand-right{background-position:-144px -144px}.icon-hand-left{background-position:-168px -144px}.icon-hand-up{background-position:-192px -144px}.icon-hand-down{background-position:-216px -144px}.icon-circle-arrow-right{background-position:-240px -144px}.icon-circle-arrow-left{background-position:-264px -144px}.icon-circle-arrow-up{background-position:-288px -144px}.icon-circle-arrow-down{background-position:-312px -144px}.icon-globe{background-position:-336px -144px}.icon-wrench{background-position:-360px -144px}.icon-tasks{background-position:-384px -144px}.icon-filter{background-position:-408px -144px}.icon-briefcase{background-position:-432px -144px}.icon-fullscreen{background-position:-456px -144px}.dropup,.dropdown{position:relative}.dropdown-toggle{*margin-bottom:-3px}.dropdown-toggle:active,.open .dropdown-toggle{outline:0}.caret{display:inline-block;width:0;height:0;vertical-align:top;border-top:4px solid #000;border-right:4px solid transparent;border-left:4px solid transparent;content:""}.dropdown
.caret{margin-top:8px;margin-left:2px}.dropdown-menu{position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px
0;margin:2px
0 0;list-style:none;background-color:#fff;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.2);*border-right-width:2px;*border-bottom-width:2px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2);-moz-box-shadow:0 5px 10px rgba(0,0,0,0.2);box-shadow:0 5px 10px rgba(0,0,0,0.2);-webkit-background-clip:padding-box;-moz-background-clip:padding;background-clip:padding-box}.dropdown-menu.pull-right{right:0;left:auto}.dropdown-menu
.divider{*width:100%;height:1px;margin:9px
1px;*margin:-5px 0 5px;overflow:hidden;background-color:#e5e5e5;border-bottom:1px solid #fff}.dropdown-menu>li>a{display:block;padding:3px
20px;clear:both;font-weight:normal;line-height:20px;color:#333;white-space:nowrap}.dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus,.dropdown-submenu:hover>a,.dropdown-submenu:focus>a{color:#fff;text-decoration:none;background-color:#00699e;background-image:-moz-linear-gradient(top,#0070a8,#005f8f);background-image:-webkit-gradient(linear,0 0,0 100%,from(#0070a8),to(#005f8f));background-image:-webkit-linear-gradient(top,#0070a8,#005f8f);background-image:-o-linear-gradient(top,#0070a8,#005f8f);background-image:linear-gradient(to bottom,#0070a8,#005f8f);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8',endColorstr='#ff005f8f',GradientType=0)}.dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus{color:#fff;text-decoration:none;background-color:#00699e;background-image:-moz-linear-gradient(top,#0070a8,#005f8f);background-image:-webkit-gradient(linear,0 0,0 100%,from(#0070a8),to(#005f8f));background-image:-webkit-linear-gradient(top,#0070a8,#005f8f);background-image:-o-linear-gradient(top,#0070a8,#005f8f);background-image:linear-gradient(to bottom,#0070a8,#005f8f);background-repeat:repeat-x;outline:0;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8',endColorstr='#ff005f8f',GradientType=0)}.dropdown-menu>.disabled>a,.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{color:#999}.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{text-decoration:none;cursor:default;background-color:transparent;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.open{*z-index:1000}.open>.dropdown-menu{display:block}.pull-right>.dropdown-menu{right:0;left:auto}.dropup .caret,.navbar-fixed-bottom .dropdown
.caret{border-top:0;border-bottom:4px solid #000;content:""}.dropup .dropdown-menu,.navbar-fixed-bottom .dropdown .dropdown-menu{top:auto;bottom:100%;margin-bottom:1px}.dropdown-submenu{position:relative}.dropdown-submenu>.dropdown-menu{top:0;left:100%;margin-top:-6px;margin-left:-1px;-webkit-border-radius:0 6px 6px 6px;-moz-border-radius:0 6px 6px 6px;border-radius:0 6px 6px 6px}.dropdown-submenu:hover>.dropdown-menu{display:block}.dropup .dropdown-submenu>.dropdown-menu{top:auto;bottom:0;margin-top:0;margin-bottom:-2px;-webkit-border-radius:5px 5px 5px 0;-moz-border-radius:5px 5px 5px 0;border-radius:5px 5px 5px 0}.dropdown-submenu>a:after{display:block;float:right;width:0;height:0;margin-top:5px;margin-right:-10px;border-color:transparent;border-left-color:#ccc;border-style:solid;border-width:5px 0 5px 5px;content:" "}.dropdown-submenu:hover>a:after{border-left-color:#fff}.dropdown-submenu.pull-left{float:none}.dropdown-submenu.pull-left>.dropdown-menu{left:-100%;margin-left:10px;-webkit-border-radius:6px 0 6px 6px;-moz-border-radius:6px 0 6px 6px;border-radius:6px 0 6px 6px}.dropdown .dropdown-menu .nav-header{padding-right:20px;padding-left:20px}.typeahead{z-index:1051;margin-top:2px;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.well{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.well
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.well-large{padding:24px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.well-small{padding:9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.fade{opacity:0;-webkit-transition:opacity .15s linear;-moz-transition:opacity .15s linear;-o-transition:opacity .15s linear;transition:opacity .15s linear}.fade.in{opacity:1}.collapse{position:relative;height:0;overflow:hidden;-webkit-transition:height .35s ease;-moz-transition:height .35s ease;-o-transition:height .35s ease;transition:height .35s ease}.collapse.in{height:auto}.close{float:right;font-size:20px;font-weight:bold;line-height:20px;color:#000;text-shadow:0 1px 0 #fff;opacity:.2;filter:alpha(opacity=20)}.close:hover,.close:focus{color:#000;text-decoration:none;cursor:pointer;opacity:.4;filter:alpha(opacity=40)}button.close{padding:0;cursor:pointer;background:transparent;border:0;-webkit-appearance:none}.btn{display:inline-block;*display:inline;padding:4px
12px;margin-bottom:0;*margin-left:.3em;font-size:14px;line-height:20px;color:#333;text-align:center;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;cursor:pointer;background-color:#f5f5f5;*background-color:#e6e6e6;background-image:-moz-linear-gradient(top,#fff,#e6e6e6);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#e6e6e6));background-image:-webkit-linear-gradient(top,#fff,#e6e6e6);background-image:-o-linear-gradient(top,#fff,#e6e6e6);background-image:linear-gradient(to bottom,#fff,#e6e6e6);background-repeat:repeat-x;border:1px
solid #ccc;*border:0;border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe6e6e6',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);*zoom:1;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}.btn:hover,.btn:focus,.btn:active,.btn.active,.btn.disabled,.btn[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}.btn:active,.btn.active{background-color:#ccc \9}.btn:first-child{*margin-left:0}.btn:hover,.btn:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}.btn:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}.btn.active,.btn:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}.btn.disabled,.btn[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.btn-large{padding:11px
19px;font-size:17.5px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.btn-large [class^="icon-"],.btn-large [class*=" icon-"]{margin-top:4px}.btn-small{padding:2px
10px;font-size:11.9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.btn-small [class^="icon-"],.btn-small [class*=" icon-"]{margin-top:0}.btn-mini [class^="icon-"],.btn-mini [class*=" icon-"]{margin-top:-1px}.btn-mini{padding:0
6px;font-size:10.5px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.btn-block{display:block;width:100%;padding-right:0;padding-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.btn-block+.btn-block{margin-top:5px}input[type="submit"].btn-block,input[type="reset"].btn-block,input[type="button"].btn-block{width:100%}.btn-primary.active,.btn-warning.active,.btn-danger.active,.btn-success.active,.btn-info.active,.btn-inverse.active{color:rgba(255,255,255,0.75)}.btn-primary{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#005aa8;*background-color:#0038a8;background-image:-moz-linear-gradient(top,#0070a8,#0038a8);background-image:-webkit-gradient(linear,0 0,0 100%,from(#0070a8),to(#0038a8));background-image:-webkit-linear-gradient(top,#0070a8,#0038a8);background-image:-o-linear-gradient(top,#0070a8,#0038a8);background-image:linear-gradient(to bottom,#0070a8,#0038a8);background-repeat:repeat-x;border-color:#0038a8 #0038a8 #001e5c;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8',endColorstr='#ff0038a8',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.btn-primary:hover,.btn-primary:focus,.btn-primary:active,.btn-primary.active,.btn-primary.disabled,.btn-primary[disabled]{color:#fff;background-color:#0038a8;*background-color:#002f8f}.btn-primary:active,.btn-primary.active{background-color:#002775 \9}.btn-warning{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#faa732;*background-color:#f89406;background-image:-moz-linear-gradient(top,#fbb450,#f89406);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fbb450),to(#f89406));background-image:-webkit-linear-gradient(top,#fbb450,#f89406);background-image:-o-linear-gradient(top,#fbb450,#f89406);background-image:linear-gradient(to bottom,#fbb450,#f89406);background-repeat:repeat-x;border-color:#f89406 #f89406 #ad6704;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450',endColorstr='#fff89406',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.btn-warning:hover,.btn-warning:focus,.btn-warning:active,.btn-warning.active,.btn-warning.disabled,.btn-warning[disabled]{color:#fff;background-color:#f89406;*background-color:#df8505}.btn-warning:active,.btn-warning.active{background-color:#c67605 \9}.btn-danger{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#da4f49;*background-color:#bd362f;background-image:-moz-linear-gradient(top,#ee5f5b,#bd362f);background-image:-webkit-gradient(linear,0 0,0 100%,from(#ee5f5b),to(#bd362f));background-image:-webkit-linear-gradient(top,#ee5f5b,#bd362f);background-image:-o-linear-gradient(top,#ee5f5b,#bd362f);background-image:linear-gradient(to bottom,#ee5f5b,#bd362f);background-repeat:repeat-x;border-color:#bd362f #bd362f #802420;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffee5f5b',endColorstr='#ffbd362f',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.btn-danger:hover,.btn-danger:focus,.btn-danger:active,.btn-danger.active,.btn-danger.disabled,.btn-danger[disabled]{color:#fff;background-color:#bd362f;*background-color:#a9302a}.btn-danger:active,.btn-danger.active{background-color:#942a25 \9}.btn-success{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#5bb75b;*background-color:#51a351;background-image:-moz-linear-gradient(top,#62c462,#51a351);background-image:-webkit-gradient(linear,0 0,0 100%,from(#62c462),to(#51a351));background-image:-webkit-linear-gradient(top,#62c462,#51a351);background-image:-o-linear-gradient(top,#62c462,#51a351);background-image:linear-gradient(to bottom,#62c462,#51a351);background-repeat:repeat-x;border-color:#51a351 #51a351 #387038;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff62c462',endColorstr='#ff51a351',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.btn-success:hover,.btn-success:focus,.btn-success:active,.btn-success.active,.btn-success.disabled,.btn-success[disabled]{color:#fff;background-color:#51a351;*background-color:#499249}.btn-success:active,.btn-success.active{background-color:#408140 \9}.btn-info{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#49afcd;*background-color:#2f96b4;background-image:-moz-linear-gradient(top,#5bc0de,#2f96b4);background-image:-webkit-gradient(linear,0 0,0 100%,from(#5bc0de),to(#2f96b4));background-image:-webkit-linear-gradient(top,#5bc0de,#2f96b4);background-image:-o-linear-gradient(top,#5bc0de,#2f96b4);background-image:linear-gradient(to bottom,#5bc0de,#2f96b4);background-repeat:repeat-x;border-color:#2f96b4 #2f96b4 #1f6377;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de',endColorstr='#ff2f96b4',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.btn-info:hover,.btn-info:focus,.btn-info:active,.btn-info.active,.btn-info.disabled,.btn-info[disabled]{color:#fff;background-color:#2f96b4;*background-color:#2a85a0}.btn-info:active,.btn-info.active{background-color:#24748c \9}.btn-inverse{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#363636;*background-color:#222;background-image:-moz-linear-gradient(top,#444,#222);background-image:-webkit-gradient(linear,0 0,0 100%,from(#444),to(#222));background-image:-webkit-linear-gradient(top,#444,#222);background-image:-o-linear-gradient(top,#444,#222);background-image:linear-gradient(to bottom,#444,#222);background-repeat:repeat-x;border-color:#222 #222 #000;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff444444',endColorstr='#ff222222',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.btn-inverse:hover,.btn-inverse:focus,.btn-inverse:active,.btn-inverse.active,.btn-inverse.disabled,.btn-inverse[disabled]{color:#fff;background-color:#222;*background-color:#151515}.btn-inverse:active,.btn-inverse.active{background-color:#080808 \9}button.btn,input[type="submit"].btn{*padding-top:3px;*padding-bottom:3px}button.btn::-moz-focus-inner,input[type="submit"].btn::-moz-focus-inner{padding:0;border:0}button.btn.btn-large,input[type="submit"].btn.btn-large{*padding-top:7px;*padding-bottom:7px}button.btn.btn-small,input[type="submit"].btn.btn-small{*padding-top:3px;*padding-bottom:3px}button.btn.btn-mini,input[type="submit"].btn.btn-mini{*padding-top:1px;*padding-bottom:1px}.btn-link,.btn-link:active,.btn-link[disabled]{background-color:transparent;background-image:none;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.btn-link{color:#0070a8;cursor:pointer;border-color:transparent;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.btn-link:hover,.btn-link:focus{color:#003d5c;text-decoration:underline;background-color:transparent}.btn-link[disabled]:hover,.btn-link[disabled]:focus{color:#333;text-decoration:none}.btn-group{position:relative;display:inline-block;*display:inline;*margin-left:.3em;font-size:0;white-space:nowrap;vertical-align:middle;*zoom:1}.btn-group:first-child{*margin-left:0}.btn-group+.btn-group{margin-left:5px}.btn-toolbar{margin-top:10px;margin-bottom:10px;font-size:0}.btn-toolbar>.btn+.btn,.btn-toolbar>.btn-group+.btn,.btn-toolbar>.btn+.btn-group{margin-left:5px}.btn-group>.btn{position:relative;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.btn-group>.btn+.btn{margin-left:-1px}.btn-group>.btn,.btn-group>.dropdown-menu,.btn-group>.popover{font-size:14px}.btn-group>.btn-mini{font-size:10.5px}.btn-group>.btn-small{font-size:11.9px}.btn-group>.btn-large{font-size:17.5px}.btn-group>.btn:first-child{margin-left:0;-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-bottomleft:4px;-moz-border-radius-topleft:4px}.btn-group>.btn:last-child,.btn-group>.dropdown-toggle{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-moz-border-radius-topright:4px;-moz-border-radius-bottomright:4px}.btn-group>.btn.large:first-child{margin-left:0;-webkit-border-bottom-left-radius:6px;border-bottom-left-radius:6px;-webkit-border-top-left-radius:6px;border-top-left-radius:6px;-moz-border-radius-bottomleft:6px;-moz-border-radius-topleft:6px}.btn-group>.btn.large:last-child,.btn-group>.large.dropdown-toggle{-webkit-border-top-right-radius:6px;border-top-right-radius:6px;-webkit-border-bottom-right-radius:6px;border-bottom-right-radius:6px;-moz-border-radius-topright:6px;-moz-border-radius-bottomright:6px}.btn-group>.btn:hover,.btn-group>.btn:focus,.btn-group>.btn:active,.btn-group>.btn.active{z-index:2}.btn-group .dropdown-toggle:active,.btn-group.open .dropdown-toggle{outline:0}.btn-group>.btn+.dropdown-toggle{*padding-top:5px;padding-right:8px;*padding-bottom:5px;padding-left:8px;-webkit-box-shadow:inset 1px 0 0 rgba(255,255,255,0.125),inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 1px 0 0 rgba(255,255,255,0.125),inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 1px 0 0 rgba(255,255,255,0.125),inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}.btn-group>.btn-mini+.dropdown-toggle{*padding-top:2px;padding-right:5px;*padding-bottom:2px;padding-left:5px}.btn-group>.btn-small+.dropdown-toggle{*padding-top:5px;*padding-bottom:4px}.btn-group>.btn-large+.dropdown-toggle{*padding-top:7px;padding-right:12px;*padding-bottom:7px;padding-left:12px}.btn-group.open .dropdown-toggle{background-image:none;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}.btn-group.open .btn.dropdown-toggle{background-color:#e6e6e6}.btn-group.open .btn-primary.dropdown-toggle{background-color:#0038a8}.btn-group.open .btn-warning.dropdown-toggle{background-color:#f89406}.btn-group.open .btn-danger.dropdown-toggle{background-color:#bd362f}.btn-group.open .btn-success.dropdown-toggle{background-color:#51a351}.btn-group.open .btn-info.dropdown-toggle{background-color:#2f96b4}.btn-group.open .btn-inverse.dropdown-toggle{background-color:#222}.btn
.caret{margin-top:8px;margin-left:0}.btn-large
.caret{margin-top:6px}.btn-large
.caret{border-top-width:5px;border-right-width:5px;border-left-width:5px}.btn-mini .caret,.btn-small
.caret{margin-top:8px}.dropup .btn-large
.caret{border-bottom-width:5px}.btn-primary .caret,.btn-warning .caret,.btn-danger .caret,.btn-info .caret,.btn-success .caret,.btn-inverse
.caret{border-top-color:#fff;border-bottom-color:#fff}.btn-group-vertical{display:inline-block;*display:inline;*zoom:1}.btn-group-vertical>.btn{display:block;float:none;max-width:100%;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.btn-group-vertical>.btn+.btn{margin-top:-1px;margin-left:0}.btn-group-vertical>.btn:first-child{-webkit-border-radius:4px 4px 0 0;-moz-border-radius:4px 4px 0 0;border-radius:4px 4px 0 0}.btn-group-vertical>.btn:last-child{-webkit-border-radius:0 0 4px 4px;-moz-border-radius:0 0 4px 4px;border-radius:0 0 4px 4px}.btn-group-vertical>.btn-large:first-child{-webkit-border-radius:6px 6px 0 0;-moz-border-radius:6px 6px 0 0;border-radius:6px 6px 0 0}.btn-group-vertical>.btn-large:last-child{-webkit-border-radius:0 0 6px 6px;-moz-border-radius:0 0 6px 6px;border-radius:0 0 6px 6px}.alert{padding:8px
35px 8px 14px;margin-bottom:20px;text-shadow:0 1px 0 rgba(255,255,255,0.5);background-color:#fcf8e3;border:1px
solid #fbeed5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.alert,.alert
h4{color:#c09853}.alert
h4{margin:0}.alert
.close{position:relative;top:-2px;right:-21px;line-height:20px}.alert-success{color:#468847;background-color:#dff0d8;border-color:#d6e9c6}.alert-success
h4{color:#468847}.alert-danger,.alert-error{color:#b94a48;background-color:#f2dede;border-color:#eed3d7}.alert-danger h4,.alert-error
h4{color:#b94a48}.alert-info{color:#3a87ad;background-color:#d9edf7;border-color:#bce8f1}.alert-info
h4{color:#3a87ad}.alert-block{padding-top:14px;padding-bottom:14px}.alert-block>p,.alert-block>ul{margin-bottom:0}.alert-block p+p{margin-top:5px}.nav{margin-bottom:20px;margin-left:0;list-style:none}.nav>li>a{display:block}.nav>li>a:hover,.nav>li>a:focus{text-decoration:none;background-color:#eee}.nav>li>a>img{max-width:none}.nav>.pull-right{float:right}.nav-header{display:block;padding:3px
15px;font-size:11px;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase}.nav li+.nav-header{margin-top:9px}.nav-list{padding-right:15px;padding-left:15px;margin-bottom:0}.nav-list>li>a,.nav-list .nav-header{margin-right:-15px;margin-left:-15px;text-shadow:0 1px 0 rgba(255,255,255,0.5)}.nav-list>li>a{padding:3px
15px}.nav-list>.active>a,.nav-list>.active>a:hover,.nav-list>.active>a:focus{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.2);background-color:#0070a8}.nav-list [class^="icon-"],.nav-list [class*=" icon-"]{margin-right:2px}.nav-list
.divider{*width:100%;height:1px;margin:9px
1px;*margin:-5px 0 5px;overflow:hidden;background-color:#e5e5e5;border-bottom:1px solid #fff}.nav-tabs,.nav-pills{*zoom:1}.nav-tabs:before,.nav-pills:before,.nav-tabs:after,.nav-pills:after{display:table;line-height:0;content:""}.nav-tabs:after,.nav-pills:after{clear:both}.nav-tabs>li,.nav-pills>li{float:left}.nav-tabs>li>a,.nav-pills>li>a{padding-right:12px;padding-left:12px;margin-right:2px;line-height:14px}.nav-tabs{border-bottom:1px solid #ddd}.nav-tabs>li{margin-bottom:-1px}.nav-tabs>li>a{padding-top:8px;padding-bottom:8px;line-height:20px;border:1px
solid transparent;-webkit-border-radius:4px 4px 0 0;-moz-border-radius:4px 4px 0 0;border-radius:4px 4px 0 0}.nav-tabs>li>a:hover,.nav-tabs>li>a:focus{border-color:#eee #eee #ddd}.nav-tabs>.active>a,.nav-tabs>.active>a:hover,.nav-tabs>.active>a:focus{color:#555;cursor:default;background-color:#fff;border:1px
solid #ddd;border-bottom-color:transparent}.nav-pills>li>a{padding-top:8px;padding-bottom:8px;margin-top:2px;margin-bottom:2px;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px}.nav-pills>.active>a,.nav-pills>.active>a:hover,.nav-pills>.active>a:focus{color:#fff;background-color:#0070a8}.nav-stacked>li{float:none}.nav-stacked>li>a{margin-right:0}.nav-tabs.nav-stacked{border-bottom:0}.nav-tabs.nav-stacked>li>a{border:1px
solid #ddd;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.nav-tabs.nav-stacked>li:first-child>a{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topright:4px;-moz-border-radius-topleft:4px}.nav-tabs.nav-stacked>li:last-child>a{-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-moz-border-radius-bottomright:4px;-moz-border-radius-bottomleft:4px}.nav-tabs.nav-stacked>li>a:hover,.nav-tabs.nav-stacked>li>a:focus{z-index:2;border-color:#ddd}.nav-pills.nav-stacked>li>a{margin-bottom:3px}.nav-pills.nav-stacked>li:last-child>a{margin-bottom:1px}.nav-tabs .dropdown-menu{-webkit-border-radius:0 0 6px 6px;-moz-border-radius:0 0 6px 6px;border-radius:0 0 6px 6px}.nav-pills .dropdown-menu{-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.nav .dropdown-toggle
.caret{margin-top:6px;border-top-color:#0070a8;border-bottom-color:#0070a8}.nav .dropdown-toggle:hover .caret,.nav .dropdown-toggle:focus
.caret{border-top-color:#003d5c;border-bottom-color:#003d5c}.nav-tabs .dropdown-toggle
.caret{margin-top:8px}.nav .active .dropdown-toggle
.caret{border-top-color:#fff;border-bottom-color:#fff}.nav-tabs .active .dropdown-toggle
.caret{border-top-color:#555;border-bottom-color:#555}.nav>.dropdown.active>a:hover,.nav>.dropdown.active>a:focus{cursor:pointer}.nav-tabs .open .dropdown-toggle,.nav-pills .open .dropdown-toggle,.nav>li.dropdown.open.active>a:hover,.nav>li.dropdown.open.active>a:focus{color:#fff;background-color:#999;border-color:#999}.nav li.dropdown.open .caret,.nav li.dropdown.open.active .caret,.nav li.dropdown.open a:hover .caret,.nav li.dropdown.open a:focus
.caret{border-top-color:#fff;border-bottom-color:#fff;opacity:1;filter:alpha(opacity=100)}.tabs-stacked .open>a:hover,.tabs-stacked .open>a:focus{border-color:#999}.tabbable{*zoom:1}.tabbable:before,.tabbable:after{display:table;line-height:0;content:""}.tabbable:after{clear:both}.tab-content{overflow:auto}.tabs-below>.nav-tabs,.tabs-right>.nav-tabs,.tabs-left>.nav-tabs{border-bottom:0}.tab-content>.tab-pane,.pill-content>.pill-pane{display:none}.tab-content>.active,.pill-content>.active{display:block}.tabs-below>.nav-tabs{border-top:1px solid #ddd}.tabs-below>.nav-tabs>li{margin-top:-1px;margin-bottom:0}.tabs-below>.nav-tabs>li>a{-webkit-border-radius:0 0 4px 4px;-moz-border-radius:0 0 4px 4px;border-radius:0 0 4px 4px}.tabs-below>.nav-tabs>li>a:hover,.tabs-below>.nav-tabs>li>a:focus{border-top-color:#ddd;border-bottom-color:transparent}.tabs-below>.nav-tabs>.active>a,.tabs-below>.nav-tabs>.active>a:hover,.tabs-below>.nav-tabs>.active>a:focus{border-color:transparent #ddd #ddd #ddd}.tabs-left>.nav-tabs>li,.tabs-right>.nav-tabs>li{float:none}.tabs-left>.nav-tabs>li>a,.tabs-right>.nav-tabs>li>a{min-width:74px;margin-right:0;margin-bottom:3px}.tabs-left>.nav-tabs{float:left;margin-right:19px;border-right:1px solid #ddd}.tabs-left>.nav-tabs>li>a{margin-right:-1px;-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.tabs-left>.nav-tabs>li>a:hover,.tabs-left>.nav-tabs>li>a:focus{border-color:#eee #ddd #eee #eee}.tabs-left>.nav-tabs .active>a,.tabs-left>.nav-tabs .active>a:hover,.tabs-left>.nav-tabs .active>a:focus{border-color:#ddd transparent #ddd #ddd;*border-right-color:#fff}.tabs-right>.nav-tabs{float:right;margin-left:19px;border-left:1px solid #ddd}.tabs-right>.nav-tabs>li>a{margin-left:-1px;-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.tabs-right>.nav-tabs>li>a:hover,.tabs-right>.nav-tabs>li>a:focus{border-color:#eee #eee #eee #ddd}.tabs-right>.nav-tabs .active>a,.tabs-right>.nav-tabs .active>a:hover,.tabs-right>.nav-tabs .active>a:focus{border-color:#ddd #ddd #ddd transparent;*border-left-color:#fff}.nav>.disabled>a{color:#999}.nav>.disabled>a:hover,.nav>.disabled>a:focus{text-decoration:none;cursor:default;background-color:transparent}.navbar{*position:relative;*z-index:2;margin-bottom:20px;overflow:visible}.navbar-inner{min-height:40px;padding-right:20px;padding-left:20px;background-color:#fafafa;background-image:-moz-linear-gradient(top,#fff,#f2f2f2);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#f2f2f2));background-image:-webkit-linear-gradient(top,#fff,#f2f2f2);background-image:-o-linear-gradient(top,#fff,#f2f2f2);background-image:linear-gradient(to bottom,#fff,#f2f2f2);background-repeat:repeat-x;border:1px
solid #d4d4d4;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#fff2f2f2',GradientType=0);*zoom:1;-webkit-box-shadow:0 1px 4px rgba(0,0,0,0.065);-moz-box-shadow:0 1px 4px rgba(0,0,0,0.065);box-shadow:0 1px 4px rgba(0,0,0,0.065)}.navbar-inner:before,.navbar-inner:after{display:table;line-height:0;content:""}.navbar-inner:after{clear:both}.navbar
.container{width:auto}.nav-collapse.collapse{height:auto;overflow:visible}.navbar
.brand{display:block;float:left;padding:10px
20px 10px;margin-left:-20px;font-size:20px;font-weight:200;color:#777;text-shadow:0 1px 0 #fff}.navbar .brand:hover,.navbar .brand:focus{text-decoration:none}.navbar-text{margin-bottom:0;line-height:40px;color:#777}.navbar-link{color:#777}.navbar-link:hover,.navbar-link:focus{color:#333}.navbar .divider-vertical{height:40px;margin:0
9px;border-right:1px solid #fff;border-left:1px solid #f2f2f2}.navbar .btn,.navbar .btn-group{margin-top:5px}.navbar .btn-group .btn,.navbar .input-prepend .btn,.navbar .input-append .btn,.navbar .input-prepend .btn-group,.navbar .input-append .btn-group{margin-top:0}.navbar-form{margin-bottom:0;*zoom:1}.navbar-form:before,.navbar-form:after{display:table;line-height:0;content:""}.navbar-form:after{clear:both}.navbar-form input,.navbar-form select,.navbar-form .radio,.navbar-form
.checkbox{margin-top:5px}.navbar-form input,.navbar-form select,.navbar-form
.btn{display:inline-block;margin-bottom:0}.navbar-form input[type="image"],.navbar-form input[type="checkbox"],.navbar-form input[type="radio"]{margin-top:3px}.navbar-form .input-append,.navbar-form .input-prepend{margin-top:5px;white-space:nowrap}.navbar-form .input-append input,.navbar-form .input-prepend
input{margin-top:0}.navbar-search{position:relative;float:left;margin-top:5px;margin-bottom:0}.navbar-search .search-query{padding:4px
14px;margin-bottom:0;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:13px;font-weight:normal;line-height:1;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.navbar-static-top{position:static;margin-bottom:0}.navbar-static-top .navbar-inner{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.navbar-fixed-top,.navbar-fixed-bottom{position:fixed;right:0;left:0;z-index:1030;margin-bottom:0}.navbar-fixed-top .navbar-inner,.navbar-static-top .navbar-inner{border-width:0 0 1px}.navbar-fixed-bottom .navbar-inner{border-width:1px 0 0}.navbar-fixed-top .navbar-inner,.navbar-fixed-bottom .navbar-inner{padding-right:0;padding-left:0;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:940px}.navbar-fixed-top{top:0}.navbar-fixed-top .navbar-inner,.navbar-static-top .navbar-inner{-webkit-box-shadow:0 1px 10px rgba(0,0,0,0.1);-moz-box-shadow:0 1px 10px rgba(0,0,0,0.1);box-shadow:0 1px 10px rgba(0,0,0,0.1)}.navbar-fixed-bottom{bottom:0}.navbar-fixed-bottom .navbar-inner{-webkit-box-shadow:0 -1px 10px rgba(0,0,0,0.1);-moz-box-shadow:0 -1px 10px rgba(0,0,0,0.1);box-shadow:0 -1px 10px rgba(0,0,0,0.1)}.navbar
.nav{position:relative;left:0;display:block;float:left;margin:0
10px 0 0}.navbar .nav.pull-right{float:right;margin-right:0}.navbar .nav>li{float:left}.navbar .nav>li>a{float:none;padding:10px
15px 10px;color:#777;text-decoration:none;text-shadow:0 1px 0 #fff}.navbar .nav .dropdown-toggle
.caret{margin-top:8px}.navbar .nav>li>a:focus,.navbar .nav>li>a:hover{color:#333;text-decoration:none;background-color:transparent}.navbar .nav>.active>a,.navbar .nav>.active>a:hover,.navbar .nav>.active>a:focus{color:#555;text-decoration:none;background-color:#e5e5e5;-webkit-box-shadow:inset 0 3px 8px rgba(0,0,0,0.125);-moz-box-shadow:inset 0 3px 8px rgba(0,0,0,0.125);box-shadow:inset 0 3px 8px rgba(0,0,0,0.125)}.navbar .btn-navbar{display:none;float:right;padding:7px
10px;margin-right:5px;margin-left:5px;color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#ededed;*background-color:#e5e5e5;background-image:-moz-linear-gradient(top,#f2f2f2,#e5e5e5);background-image:-webkit-gradient(linear,0 0,0 100%,from(#f2f2f2),to(#e5e5e5));background-image:-webkit-linear-gradient(top,#f2f2f2,#e5e5e5);background-image:-o-linear-gradient(top,#f2f2f2,#e5e5e5);background-image:linear-gradient(to bottom,#f2f2f2,#e5e5e5);background-repeat:repeat-x;border-color:#e5e5e5 #e5e5e5 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff2f2f2',endColorstr='#ffe5e5e5',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.075);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.075);box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.075)}.navbar .btn-navbar:hover,.navbar .btn-navbar:focus,.navbar .btn-navbar:active,.navbar .btn-navbar.active,.navbar .btn-navbar.disabled,.navbar .btn-navbar[disabled]{color:#fff;background-color:#e5e5e5;*background-color:#d9d9d9}.navbar .btn-navbar:active,.navbar .btn-navbar.active{background-color:#ccc \9}.navbar .btn-navbar .icon-bar{display:block;width:18px;height:2px;background-color:#f5f5f5;-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px;-webkit-box-shadow:0 1px 0 rgba(0,0,0,0.25);-moz-box-shadow:0 1px 0 rgba(0,0,0,0.25);box-shadow:0 1px 0 rgba(0,0,0,0.25)}.btn-navbar .icon-bar+.icon-bar{margin-top:3px}.navbar .nav>li>.dropdown-menu:before{position:absolute;top:-7px;left:9px;display:inline-block;border-right:7px solid transparent;border-bottom:7px solid #ccc;border-left:7px solid transparent;border-bottom-color:rgba(0,0,0,0.2);content:''}.navbar .nav>li>.dropdown-menu:after{position:absolute;top:-6px;left:10px;display:inline-block;border-right:6px solid transparent;border-bottom:6px solid #fff;border-left:6px solid transparent;content:''}.navbar-fixed-bottom .nav>li>.dropdown-menu:before{top:auto;bottom:-7px;border-top:7px solid #ccc;border-bottom:0;border-top-color:rgba(0,0,0,0.2)}.navbar-fixed-bottom .nav>li>.dropdown-menu:after{top:auto;bottom:-6px;border-top:6px solid #fff;border-bottom:0}.navbar .nav li.dropdown>a:hover .caret,.navbar .nav li.dropdown>a:focus
.caret{border-top-color:#333;border-bottom-color:#333}.navbar .nav li.dropdown.open>.dropdown-toggle,.navbar .nav li.dropdown.active>.dropdown-toggle,.navbar .nav li.dropdown.open.active>.dropdown-toggle{color:#555;background-color:#e5e5e5}.navbar .nav li.dropdown>.dropdown-toggle
.caret{border-top-color:#777;border-bottom-color:#777}.navbar .nav li.dropdown.open>.dropdown-toggle .caret,.navbar .nav li.dropdown.active>.dropdown-toggle .caret,.navbar .nav li.dropdown.open.active>.dropdown-toggle
.caret{border-top-color:#555;border-bottom-color:#555}.navbar .pull-right>li>.dropdown-menu,.navbar .nav>li>.dropdown-menu.pull-right{right:0;left:auto}.navbar .pull-right>li>.dropdown-menu:before,.navbar .nav>li>.dropdown-menu.pull-right:before{right:12px;left:auto}.navbar .pull-right>li>.dropdown-menu:after,.navbar .nav>li>.dropdown-menu.pull-right:after{right:13px;left:auto}.navbar .pull-right>li>.dropdown-menu .dropdown-menu,.navbar .nav>li>.dropdown-menu.pull-right .dropdown-menu{right:100%;left:auto;margin-right:-1px;margin-left:0;-webkit-border-radius:6px 0 6px 6px;-moz-border-radius:6px 0 6px 6px;border-radius:6px 0 6px 6px}.navbar-inverse .navbar-inner{background-color:#1b1b1b;background-image:-moz-linear-gradient(top,#222,#111);background-image:-webkit-gradient(linear,0 0,0 100%,from(#222),to(#111));background-image:-webkit-linear-gradient(top,#222,#111);background-image:-o-linear-gradient(top,#222,#111);background-image:linear-gradient(to bottom,#222,#111);background-repeat:repeat-x;border-color:#252525;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff222222',endColorstr='#ff111111',GradientType=0)}.navbar-inverse .brand,.navbar-inverse .nav>li>a{color:#999;text-shadow:0 -1px 0 rgba(0,0,0,0.25)}.navbar-inverse .brand:hover,.navbar-inverse .nav>li>a:hover,.navbar-inverse .brand:focus,.navbar-inverse .nav>li>a:focus{color:#fff}.navbar-inverse
.brand{color:#999}.navbar-inverse .navbar-text{color:#999}.navbar-inverse .nav>li>a:focus,.navbar-inverse .nav>li>a:hover{color:#fff;background-color:transparent}.navbar-inverse .nav .active>a,.navbar-inverse .nav .active>a:hover,.navbar-inverse .nav .active>a:focus{color:#fff;background-color:#111}.navbar-inverse .navbar-link{color:#999}.navbar-inverse .navbar-link:hover,.navbar-inverse .navbar-link:focus{color:#fff}.navbar-inverse .divider-vertical{border-right-color:#222;border-left-color:#111}.navbar-inverse .nav li.dropdown.open>.dropdown-toggle,.navbar-inverse .nav li.dropdown.active>.dropdown-toggle,.navbar-inverse .nav li.dropdown.open.active>.dropdown-toggle{color:#fff;background-color:#111}.navbar-inverse .nav li.dropdown>a:hover .caret,.navbar-inverse .nav li.dropdown>a:focus
.caret{border-top-color:#fff;border-bottom-color:#fff}.navbar-inverse .nav li.dropdown>.dropdown-toggle
.caret{border-top-color:#999;border-bottom-color:#999}.navbar-inverse .nav li.dropdown.open>.dropdown-toggle .caret,.navbar-inverse .nav li.dropdown.active>.dropdown-toggle .caret,.navbar-inverse .nav li.dropdown.open.active>.dropdown-toggle
.caret{border-top-color:#fff;border-bottom-color:#fff}.navbar-inverse .navbar-search .search-query{color:#fff;background-color:#515151;border-color:#111;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1),0 1px 0 rgba(255,255,255,0.15);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1),0 1px 0 rgba(255,255,255,0.15);box-shadow:inset 0 1px 2px rgba(0,0,0,0.1),0 1px 0 rgba(255,255,255,0.15);-webkit-transition:none;-moz-transition:none;-o-transition:none;transition:none}.navbar-inverse .navbar-search .search-query:-moz-placeholder{color:#ccc}.navbar-inverse .navbar-search .search-query:-ms-input-placeholder{color:#ccc}.navbar-inverse .navbar-search .search-query::-webkit-input-placeholder{color:#ccc}.navbar-inverse .navbar-search .search-query:focus,.navbar-inverse .navbar-search .search-query.focused{padding:5px
15px;color:#333;text-shadow:0 1px 0 #fff;background-color:#fff;border:0;outline:0;-webkit-box-shadow:0 0 3px rgba(0,0,0,0.15);-moz-box-shadow:0 0 3px rgba(0,0,0,0.15);box-shadow:0 0 3px rgba(0,0,0,0.15)}.navbar-inverse .btn-navbar{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#0e0e0e;*background-color:#040404;background-image:-moz-linear-gradient(top,#151515,#040404);background-image:-webkit-gradient(linear,0 0,0 100%,from(#151515),to(#040404));background-image:-webkit-linear-gradient(top,#151515,#040404);background-image:-o-linear-gradient(top,#151515,#040404);background-image:linear-gradient(to bottom,#151515,#040404);background-repeat:repeat-x;border-color:#040404 #040404 #000;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff151515',endColorstr='#ff040404',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.navbar-inverse .btn-navbar:hover,.navbar-inverse .btn-navbar:focus,.navbar-inverse .btn-navbar:active,.navbar-inverse .btn-navbar.active,.navbar-inverse .btn-navbar.disabled,.navbar-inverse .btn-navbar[disabled]{color:#fff;background-color:#040404;*background-color:#000}.navbar-inverse .btn-navbar:active,.navbar-inverse .btn-navbar.active{background-color:#000 \9}.breadcrumb{padding:8px
15px;margin:0
0 20px;list-style:none;background-color:#f5f5f5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.breadcrumb>li{display:inline-block;*display:inline;text-shadow:0 1px 0 #fff;*zoom:1}.breadcrumb>li>.divider{padding:0
5px;color:#ccc}.breadcrumb>.active{color:#999}.pagination{margin:20px
0}.pagination
ul{display:inline-block;*display:inline;margin-bottom:0;margin-left:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*zoom:1;-webkit-box-shadow:0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:0 1px 2px rgba(0,0,0,0.05);box-shadow:0 1px 2px rgba(0,0,0,0.05)}.pagination ul>li{display:inline}.pagination ul>li>a,.pagination ul>li>span{float:left;padding:4px
12px;line-height:20px;text-decoration:none;background-color:#fff;border:1px
solid #ddd;border-left-width:0}.pagination ul>li>a:hover,.pagination ul>li>a:focus,.pagination ul>.active>a,.pagination ul>.active>span{background-color:#f5f5f5}.pagination ul>.active>a,.pagination ul>.active>span{color:#999;cursor:default}.pagination ul>.disabled>span,.pagination ul>.disabled>a,.pagination ul>.disabled>a:hover,.pagination ul>.disabled>a:focus{color:#999;cursor:default;background-color:transparent}.pagination ul>li:first-child>a,.pagination ul>li:first-child>span{border-left-width:1px;-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-bottomleft:4px;-moz-border-radius-topleft:4px}.pagination ul>li:last-child>a,.pagination ul>li:last-child>span{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-moz-border-radius-topright:4px;-moz-border-radius-bottomright:4px}.pagination-centered{text-align:center}.pagination-right{text-align:right}.pagination-large ul>li>a,.pagination-large ul>li>span{padding:11px
19px;font-size:17.5px}.pagination-large ul>li:first-child>a,.pagination-large ul>li:first-child>span{-webkit-border-bottom-left-radius:6px;border-bottom-left-radius:6px;-webkit-border-top-left-radius:6px;border-top-left-radius:6px;-moz-border-radius-bottomleft:6px;-moz-border-radius-topleft:6px}.pagination-large ul>li:last-child>a,.pagination-large ul>li:last-child>span{-webkit-border-top-right-radius:6px;border-top-right-radius:6px;-webkit-border-bottom-right-radius:6px;border-bottom-right-radius:6px;-moz-border-radius-topright:6px;-moz-border-radius-bottomright:6px}.pagination-mini ul>li:first-child>a,.pagination-small ul>li:first-child>a,.pagination-mini ul>li:first-child>span,.pagination-small ul>li:first-child>span{-webkit-border-bottom-left-radius:3px;border-bottom-left-radius:3px;-webkit-border-top-left-radius:3px;border-top-left-radius:3px;-moz-border-radius-bottomleft:3px;-moz-border-radius-topleft:3px}.pagination-mini ul>li:last-child>a,.pagination-small ul>li:last-child>a,.pagination-mini ul>li:last-child>span,.pagination-small ul>li:last-child>span{-webkit-border-top-right-radius:3px;border-top-right-radius:3px;-webkit-border-bottom-right-radius:3px;border-bottom-right-radius:3px;-moz-border-radius-topright:3px;-moz-border-radius-bottomright:3px}.pagination-small ul>li>a,.pagination-small ul>li>span{padding:2px
10px;font-size:11.9px}.pagination-mini ul>li>a,.pagination-mini ul>li>span{padding:0
6px;font-size:10.5px}.pager{margin:20px
0;text-align:center;list-style:none;*zoom:1}.pager:before,.pager:after{display:table;line-height:0;content:""}.pager:after{clear:both}.pager
li{display:inline}.pager li>a,.pager li>span{display:inline-block;padding:5px
14px;background-color:#fff;border:1px
solid #ddd;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.pager li>a:hover,.pager li>a:focus{text-decoration:none;background-color:#f5f5f5}.pager .next>a,.pager .next>span{float:right}.pager .previous>a,.pager .previous>span{float:left}.pager .disabled>a,.pager .disabled>a:hover,.pager .disabled>a:focus,.pager .disabled>span{color:#999;cursor:default;background-color:#fff}.modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;background-color:#000}.modal-backdrop.fade{opacity:0}.modal-backdrop,.modal-backdrop.fade.in{opacity:.8;filter:alpha(opacity=80)}.modal{position:fixed;top:10%;left:50%;z-index:1050;width:560px;margin-left:-280px;background-color:#fff;border:1px
solid #999;border:1px
solid rgba(0,0,0,0.3);*border:1px
solid #999;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;outline:0;-webkit-box-shadow:0 3px 7px rgba(0,0,0,0.3);-moz-box-shadow:0 3px 7px rgba(0,0,0,0.3);box-shadow:0 3px 7px rgba(0,0,0,0.3);-webkit-background-clip:padding-box;-moz-background-clip:padding-box;background-clip:padding-box}.modal.fade{top:-25%;-webkit-transition:opacity .3s linear,top .3s ease-out;-moz-transition:opacity .3s linear,top .3s ease-out;-o-transition:opacity .3s linear,top .3s ease-out;transition:opacity .3s linear,top .3s ease-out}.modal.fade.in{top:10%}.modal-header{padding:9px
15px;border-bottom:1px solid #eee}.modal-header
.close{margin-top:2px}.modal-header
h3{margin:0;line-height:30px}.modal-body{position:relative;max-height:400px;padding:15px;overflow-y:auto}.modal-form{margin-bottom:0}.modal-footer{padding:14px
15px 15px;margin-bottom:0;text-align:right;background-color:#f5f5f5;border-top:1px solid #ddd;-webkit-border-radius:0 0 6px 6px;-moz-border-radius:0 0 6px 6px;border-radius:0 0 6px 6px;*zoom:1;-webkit-box-shadow:inset 0 1px 0 #fff;-moz-box-shadow:inset 0 1px 0 #fff;box-shadow:inset 0 1px 0 #fff}.modal-footer:before,.modal-footer:after{display:table;line-height:0;content:""}.modal-footer:after{clear:both}.modal-footer .btn+.btn{margin-bottom:0;margin-left:5px}.modal-footer .btn-group .btn+.btn{margin-left:-1px}.modal-footer .btn-block+.btn-block{margin-left:0}.tooltip{position:absolute;z-index:1030;display:block;font-size:11px;line-height:1.4;opacity:0;filter:alpha(opacity=0);visibility:visible}.tooltip.in{opacity:.8;filter:alpha(opacity=80)}.tooltip.top{padding:5px
0;margin-top:-3px}.tooltip.right{padding:0
5px;margin-left:3px}.tooltip.bottom{padding:5px
0;margin-top:3px}.tooltip.left{padding:0
5px;margin-left:-3px}.tooltip-inner{max-width:200px;padding:8px;color:#fff;text-align:center;text-decoration:none;background-color:#000;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.tooltip-arrow{position:absolute;width:0;height:0;border-color:transparent;border-style:solid}.tooltip.top .tooltip-arrow{bottom:0;left:50%;margin-left:-5px;border-top-color:#000;border-width:5px 5px 0}.tooltip.right .tooltip-arrow{top:50%;left:0;margin-top:-5px;border-right-color:#000;border-width:5px 5px 5px 0}.tooltip.left .tooltip-arrow{top:50%;right:0;margin-top:-5px;border-left-color:#000;border-width:5px 0 5px 5px}.tooltip.bottom .tooltip-arrow{top:0;left:50%;margin-left:-5px;border-bottom-color:#000;border-width:0 5px 5px}.popover{position:absolute;top:0;left:0;z-index:1010;display:none;max-width:276px;padding:1px;text-align:left;white-space:normal;background-color:#fff;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.2);-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2);-moz-box-shadow:0 5px 10px rgba(0,0,0,0.2);box-shadow:0 5px 10px rgba(0,0,0,0.2);-webkit-background-clip:padding-box;-moz-background-clip:padding;background-clip:padding-box}.popover.top{margin-top:-10px}.popover.right{margin-left:10px}.popover.bottom{margin-top:10px}.popover.left{margin-left:-10px}.popover-title{padding:8px
14px;margin:0;font-size:14px;font-weight:normal;line-height:18px;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;-webkit-border-radius:5px 5px 0 0;-moz-border-radius:5px 5px 0 0;border-radius:5px 5px 0 0}.popover-title:empty{display:none}.popover-content{padding:9px
14px}.popover .arrow,.popover .arrow:after{position:absolute;display:block;width:0;height:0;border-color:transparent;border-style:solid}.popover
.arrow{border-width:11px}.popover .arrow:after{border-width:10px;content:""}.popover.top
.arrow{bottom:-11px;left:50%;margin-left:-11px;border-top-color:#999;border-top-color:rgba(0,0,0,0.25);border-bottom-width:0}.popover.top .arrow:after{bottom:1px;margin-left:-10px;border-top-color:#fff;border-bottom-width:0}.popover.right
.arrow{top:50%;left:-11px;margin-top:-11px;border-right-color:#999;border-right-color:rgba(0,0,0,0.25);border-left-width:0}.popover.right .arrow:after{bottom:-10px;left:1px;border-right-color:#fff;border-left-width:0}.popover.bottom
.arrow{top:-11px;left:50%;margin-left:-11px;border-bottom-color:#999;border-bottom-color:rgba(0,0,0,0.25);border-top-width:0}.popover.bottom .arrow:after{top:1px;margin-left:-10px;border-bottom-color:#fff;border-top-width:0}.popover.left
.arrow{top:50%;right:-11px;margin-top:-11px;border-left-color:#999;border-left-color:rgba(0,0,0,0.25);border-right-width:0}.popover.left .arrow:after{right:1px;bottom:-10px;border-left-color:#fff;border-right-width:0}.thumbnails{margin-left:-20px;list-style:none;*zoom:1}.thumbnails:before,.thumbnails:after{display:table;line-height:0;content:""}.thumbnails:after{clear:both}.row-fluid
.thumbnails{margin-left:0}.thumbnails>li{float:left;margin-bottom:20px;margin-left:20px}.thumbnail{display:block;padding:4px;line-height:20px;border:1px
solid #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.055);-moz-box-shadow:0 1px 3px rgba(0,0,0,0.055);box-shadow:0 1px 3px rgba(0,0,0,0.055);-webkit-transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;transition:all .2s ease-in-out}a.thumbnail:hover,a.thumbnail:focus{border-color:#0070a8;-webkit-box-shadow:0 1px 4px rgba(0,105,214,0.25);-moz-box-shadow:0 1px 4px rgba(0,105,214,0.25);box-shadow:0 1px 4px rgba(0,105,214,0.25)}.thumbnail>img{display:block;max-width:100%;margin-right:auto;margin-left:auto}.thumbnail
.caption{padding:9px;color:#555}.media,.media-body{overflow:hidden;*overflow:visible;zoom:1}.media,.media
.media{margin-top:15px}.media:first-child{margin-top:0}.media-object{display:block}.media-heading{margin:0
0 5px}.media>.pull-left{margin-right:10px}.media>.pull-right{margin-left:10px}.media-list{margin-left:0;list-style:none}.label,.badge{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);white-space:nowrap;vertical-align:baseline;background-color:#999}.label{-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.badge{padding-right:9px;padding-left:9px;-webkit-border-radius:9px;-moz-border-radius:9px;border-radius:9px}.label:empty,.badge:empty{display:none}a.label:hover,a.label:focus,a.badge:hover,a.badge:focus{color:#fff;text-decoration:none;cursor:pointer}.label-important,.badge-important{background-color:#b94a48}.label-important[href],.badge-important[href]{background-color:#953b39}.label-warning,.badge-warning{background-color:#f89406}.label-warning[href],.badge-warning[href]{background-color:#c67605}.label-success,.badge-success{background-color:#468847}.label-success[href],.badge-success[href]{background-color:#356635}.label-info,.badge-info{background-color:#3a87ad}.label-info[href],.badge-info[href]{background-color:#2d6987}.label-inverse,.badge-inverse{background-color:#333}.label-inverse[href],.badge-inverse[href]{background-color:#1a1a1a}.btn .label,.btn
.badge{position:relative;top:-1px}.btn-mini .label,.btn-mini
.badge{top:0}@-webkit-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-moz-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-ms-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-o-keyframes progress-bar-stripes{from{background-position:0 0}to{background-position:40px 0}}@keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}.progress{height:20px;margin-bottom:20px;overflow:hidden;background-color:#f7f7f7;background-image:-moz-linear-gradient(top,#f5f5f5,#f9f9f9);background-image:-webkit-gradient(linear,0 0,0 100%,from(#f5f5f5),to(#f9f9f9));background-image:-webkit-linear-gradient(top,#f5f5f5,#f9f9f9);background-image:-o-linear-gradient(top,#f5f5f5,#f9f9f9);background-image:linear-gradient(to bottom,#f5f5f5,#f9f9f9);background-repeat:repeat-x;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5',endColorstr='#fff9f9f9',GradientType=0);-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);box-shadow:inset 0 1px 2px rgba(0,0,0,0.1)}.progress
.bar{float:left;width:0;height:100%;font-size:12px;color:#fff;text-align:center;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#0e90d2;background-image:-moz-linear-gradient(top,#149bdf,#0480be);background-image:-webkit-gradient(linear,0 0,0 100%,from(#149bdf),to(#0480be));background-image:-webkit-linear-gradient(top,#149bdf,#0480be);background-image:-o-linear-gradient(top,#149bdf,#0480be);background-image:linear-gradient(to bottom,#149bdf,#0480be);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf',endColorstr='#ff0480be',GradientType=0);-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-moz-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-transition:width .6s ease;-moz-transition:width .6s ease;-o-transition:width .6s ease;transition:width .6s ease}.progress .bar+.bar{-webkit-box-shadow:inset 1px 0 0 rgba(0,0,0,0.15),inset 0 -1px 0 rgba(0,0,0,0.15);-moz-box-shadow:inset 1px 0 0 rgba(0,0,0,0.15),inset 0 -1px 0 rgba(0,0,0,0.15);box-shadow:inset 1px 0 0 rgba(0,0,0,0.15),inset 0 -1px 0 rgba(0,0,0,0.15)}.progress-striped
.bar{background-color:#149bdf;background-image:-webkit-gradient(linear,0 100%,100% 0,color-stop(0.25,rgba(255,255,255,0.15)),color-stop(0.25,transparent),color-stop(0.5,transparent),color-stop(0.5,rgba(255,255,255,0.15)),color-stop(0.75,rgba(255,255,255,0.15)),color-stop(0.75,transparent),to(transparent));background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-moz-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);-webkit-background-size:40px 40px;-moz-background-size:40px 40px;-o-background-size:40px 40px;background-size:40px 40px}.progress.active
.bar{-webkit-animation:progress-bar-stripes 2s linear infinite;-moz-animation:progress-bar-stripes 2s linear infinite;-ms-animation:progress-bar-stripes 2s linear infinite;-o-animation:progress-bar-stripes 2s linear infinite;animation:progress-bar-stripes 2s linear infinite}.progress-danger .bar,.progress .bar-danger{background-color:#dd514c;background-image:-moz-linear-gradient(top,#ee5f5b,#c43c35);background-image:-webkit-gradient(linear,0 0,0 100%,from(#ee5f5b),to(#c43c35));background-image:-webkit-linear-gradient(top,#ee5f5b,#c43c35);background-image:-o-linear-gradient(top,#ee5f5b,#c43c35);background-image:linear-gradient(to bottom,#ee5f5b,#c43c35);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffee5f5b',endColorstr='#ffc43c35',GradientType=0)}.progress-danger.progress-striped .bar,.progress-striped .bar-danger{background-color:#ee5f5b;background-image:-webkit-gradient(linear,0 100%,100% 0,color-stop(0.25,rgba(255,255,255,0.15)),color-stop(0.25,transparent),color-stop(0.5,transparent),color-stop(0.5,rgba(255,255,255,0.15)),color-stop(0.75,rgba(255,255,255,0.15)),color-stop(0.75,transparent),to(transparent));background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-moz-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent)}.progress-success .bar,.progress .bar-success{background-color:#5eb95e;background-image:-moz-linear-gradient(top,#62c462,#57a957);background-image:-webkit-gradient(linear,0 0,0 100%,from(#62c462),to(#57a957));background-image:-webkit-linear-gradient(top,#62c462,#57a957);background-image:-o-linear-gradient(top,#62c462,#57a957);background-image:linear-gradient(to bottom,#62c462,#57a957);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff62c462',endColorstr='#ff57a957',GradientType=0)}.progress-success.progress-striped .bar,.progress-striped .bar-success{background-color:#62c462;background-image:-webkit-gradient(linear,0 100%,100% 0,color-stop(0.25,rgba(255,255,255,0.15)),color-stop(0.25,transparent),color-stop(0.5,transparent),color-stop(0.5,rgba(255,255,255,0.15)),color-stop(0.75,rgba(255,255,255,0.15)),color-stop(0.75,transparent),to(transparent));background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-moz-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent)}.progress-info .bar,.progress .bar-info{background-color:#4bb1cf;background-image:-moz-linear-gradient(top,#5bc0de,#339bb9);background-image:-webkit-gradient(linear,0 0,0 100%,from(#5bc0de),to(#339bb9));background-image:-webkit-linear-gradient(top,#5bc0de,#339bb9);background-image:-o-linear-gradient(top,#5bc0de,#339bb9);background-image:linear-gradient(to bottom,#5bc0de,#339bb9);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de',endColorstr='#ff339bb9',GradientType=0)}.progress-info.progress-striped .bar,.progress-striped .bar-info{background-color:#5bc0de;background-image:-webkit-gradient(linear,0 100%,100% 0,color-stop(0.25,rgba(255,255,255,0.15)),color-stop(0.25,transparent),color-stop(0.5,transparent),color-stop(0.5,rgba(255,255,255,0.15)),color-stop(0.75,rgba(255,255,255,0.15)),color-stop(0.75,transparent),to(transparent));background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-moz-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent)}.progress-warning .bar,.progress .bar-warning{background-color:#faa732;background-image:-moz-linear-gradient(top,#fbb450,#f89406);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fbb450),to(#f89406));background-image:-webkit-linear-gradient(top,#fbb450,#f89406);background-image:-o-linear-gradient(top,#fbb450,#f89406);background-image:linear-gradient(to bottom,#fbb450,#f89406);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450',endColorstr='#fff89406',GradientType=0)}.progress-warning.progress-striped .bar,.progress-striped .bar-warning{background-color:#fbb450;background-image:-webkit-gradient(linear,0 100%,100% 0,color-stop(0.25,rgba(255,255,255,0.15)),color-stop(0.25,transparent),color-stop(0.5,transparent),color-stop(0.5,rgba(255,255,255,0.15)),color-stop(0.75,rgba(255,255,255,0.15)),color-stop(0.75,transparent),to(transparent));background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-moz-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,0.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,0.15) 50%,rgba(255,255,255,0.15) 75%,transparent 75%,transparent)}.accordion{margin-bottom:20px}.accordion-group{margin-bottom:2px;border:1px
solid #e5e5e5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.accordion-heading{border-bottom:0}.accordion-heading .accordion-toggle{display:block;padding:8px
15px}.accordion-toggle{cursor:pointer}.accordion-inner{padding:9px
15px;border-top:1px solid #e5e5e5}.carousel{position:relative;margin-bottom:20px;line-height:1}.carousel-inner{position:relative;width:100%;overflow:hidden}.carousel-inner>.item{position:relative;display:none;-webkit-transition:.6s ease-in-out left;-moz-transition:.6s ease-in-out left;-o-transition:.6s ease-in-out left;transition:.6s ease-in-out left}.carousel-inner>.item>img,.carousel-inner>.item>a>img{display:block;line-height:1}.carousel-inner>.active,.carousel-inner>.next,.carousel-inner>.prev{display:block}.carousel-inner>.active{left:0}.carousel-inner>.next,.carousel-inner>.prev{position:absolute;top:0;width:100%}.carousel-inner>.next{left:100%}.carousel-inner>.prev{left:-100%}.carousel-inner>.next.left,.carousel-inner>.prev.right{left:0}.carousel-inner>.active.left{left:-100%}.carousel-inner>.active.right{left:100%}.carousel-control{position:absolute;top:40%;left:15px;width:40px;height:40px;margin-top:-20px;font-size:60px;font-weight:100;line-height:30px;color:#fff;text-align:center;background:#222;border:3px
solid #fff;-webkit-border-radius:23px;-moz-border-radius:23px;border-radius:23px;opacity:.5;filter:alpha(opacity=50)}.carousel-control.right{right:15px;left:auto}.carousel-control:hover,.carousel-control:focus{color:#fff;text-decoration:none;opacity:.9;filter:alpha(opacity=90)}.carousel-indicators{position:absolute;top:15px;right:15px;z-index:5;margin:0;list-style:none}.carousel-indicators
li{display:block;float:left;width:10px;height:10px;margin-left:5px;text-indent:-999px;background-color:#ccc;background-color:rgba(255,255,255,0.25);border-radius:5px}.carousel-indicators
.active{background-color:#fff}.carousel-caption{position:absolute;right:0;bottom:0;left:0;padding:15px;background:#333;background:rgba(0,0,0,0.75)}.carousel-caption h4,.carousel-caption
p{line-height:20px;color:#fff}.carousel-caption
h4{margin:0
0 5px}.carousel-caption
p{margin-bottom:0}.hero-unit{padding:60px;margin-bottom:30px;font-size:18px;font-weight:200;line-height:30px;color:inherit;background-color:#eee;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.hero-unit
h1{margin-bottom:0;font-size:60px;line-height:1;letter-spacing:-1px;color:inherit}.hero-unit
li{line-height:30px}.pull-right{float:right}.pull-left{float:left}.hide{display:none}.show{display:block}.invisible{visibility:hidden}.affix{position:fixed}h1{font-size:32px}h2{font-size:28px}h3{font-size:24px}h4{font-size:20px}h5{font-size:16px}h6{font-size:12px}h1
small{font-size:24px}h2
small{font-size:20px}h3
small{font-size:16px}h4
small{font-size:12px}@media
print{a[href]:after{content:""}}legend{color:#333;border-bottom-color:#ddd}.breadcrumb{background-color:#f5f5f5}.well{border-color:#e3e3e3}sup{vertical-align:super}sub{vertical-align:sub}li.activity.label,.file-picker
td.label{display:block;padding:8px;font-size:inherit;line-height:inherit;color:inherit;text-shadow:none;white-space:normal;background:inherit;border:inherit}.file-picker
td.label{display:table-cell;text-align:right}.choosercontainer #chooseform .option
label{font-size:12px}li.section.hidden,.block.hidden,.block.invisible{display:block;visibility:visible}#turnitintool_style .row,.forumpost
.row{margin-left:0!important}#turnitintool_style .row:before,#turnitintool_style .row:after,.forumpost .row:before,.forumpost .row:after{content:none}fieldset.hidden{display:inherit;visibility:inherit}div.c1.btn{display:block;padding:0;margin-bottom:0;font-size:inherit;line-height:inherit;color:inherit;text-align:inherit;text-shadow:inherit;vertical-align:inherit;cursor:default;background-color:inherit;background-image:none;background-repeat:none;border:0;border-radius:none;box-shadow:none}#questionbank+.container{width:auto}img.hide{display:inherit}.icon-bar,img.icon-post,img.icon-info,img.icon-warn,img.icon-pre{background-image:none}.loginbox.twocolumns .signuppanel,.loginbox.twocolumns .signuppanel,.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.loginpanel{padding:0;margin:0}.tooltip{display:inline;opacity:1;filter:alpha(opacity=100)}body:not(.jsenabled) .dropdown:hover>.dropdown-menu{display:block;margin-top:-6px}body:not(.jsenabled) .langmenu:hover>.dropdown-menu,.langmenu.open>.dropdown-menu{display:block;max-height:150px;overflow-y:auto}body{padding-top:60px}.block{min-height:20px;padding:19px;padding:8px
0;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.block
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.block .header
h2{display:block;padding:3px
15px;margin:0;font-size:11px;font-size:1.1em;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase;word-wrap:break-word}.block .header
.block_action{float:right;padding:3px
15px}.block .header .block_action>*{margin-left:3px}.block .header .block_action .block-hider-show,.block .header .block_action .block-hider-hide{cursor:pointer}.block .header .block_action .block-hider-show{display:none}.block .header
.commands{display:block;padding:3px
15px;clear:both;text-align:right}.block .header .commands>a{margin:0
3px}.block .header .commands .icon
img{width:12px;height:12px}.block .header .commands
img.actionmenu{width:auto}.block
.content{padding:4px
14px;word-wrap:break-word}.block .content
h3{display:block;padding:3px
15px;font-size:11px;font-size:1.1em;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase}.block .content
hr{margin:5px
0}.block .content
.userpicture{width:16px;height:16px;margin-right:6px}.block .content .list
li.listentry{clear:both}.block .content .list
.c0{display:inline}.block .content .list
.c1{display:inline;margin-left:5px}.block
.footer{display:block;padding:3px
5px;margin-bottom:4px}.block.beingmoved{border-style:dashed;border-width:2px}.block.invisible{opacity:.5;filter:alpha(opacity=50)}.block.hidden .header .block_action .block-hider-hide{display:none}.block.hidden .header .block_action .block-hider-show{display:inline}.block.list_block .unlist>li>.column{display:inline-block;*display:inline;*zoom:1}.jsenabled .block.hidden
.content{display:none}.blockmovetarget{display:block;height:1em;margin-bottom:20px;border-style:dashed;border-width:2px}.blockannotation{position:relative;top:-10px;margin-bottom:10px}.block_blog_menu
#blogsearchquery{max-width:92%}.block_settings
#adminsearchquery{max-width:92%}.block_search_forums
#searchform_search{width:auto;max-width:92%}.block_calendar_upcoming .content
.date{padding-left:22px}.block_calendar_upcoming .content
.footer{padding-top:10px;padding-left:0;margin-top:.5em}.block_rss_client .content
li{padding:5px;margin-bottom:10px;border:1px
solid #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.block_rss_client .content li
.link{font-weight:inherit}.block_rss_client .list li:first-child{border-top-width:1px}.block_news_items .content
.newlink{padding-bottom:10px}.block_news_items .content ul
li{display:table;width:100%;padding:2px;border-top:1px rgba(0,0,0,0.05) solid}.block_news_items .content ul li
.info{display:table-header-group}.block_news_items .content ul li
.date{display:inline;font-size:11.9px}.block_news_items .content ul li
.name{display:inline;padding-left:1ex;font-size:11.9px}.block_news_items .content
.footer{padding-top:10px;padding-left:0}.block_login input#login_username,.block_login
input#login_password{width:95%}.block_login
.content{max-width:280px;margin-right:auto;margin-left:auto}.block_login input[type="submit"]{margin:10px
0}.block_adminblock
.content{display:block;padding:3px
5px}.block_adminblock
select{max-width:92%}.dir-rtl .block
.header{text-align:right}.dir-rtl .block .header
h2{text-align:right}.dir-rtl .block .header
.commands{text-align:left}.dir-rtl .block .header .commands>*{margin-right:3px;margin-left:0}.dir-rtl .block .header
.block_action{float:left}.dir-rtl .block_calendar_upcoming .content
.date{padding-right:22px}.dir-rtl .block_calendar_upcoming .content
.footer{padding-right:0}.dir-rtl .block_news_items .content ul li
.name{padding-right:1ex}.dir-rtl .block_news_items .content
.footer{padding-left:0}form{margin:0}.mform fieldset
.advancedbutton{text-align:right}.jsenabled .mform .containsadvancedelements
.advanced{display:none}.mform .containsadvancedelements
.advanced.show{display:block}.mform
fieldset.group{margin-bottom:0}.mform
fieldset.error{border:1px
solid #b94a48}.mform
span.error{display:inline-block;padding:4px;margin-bottom:4px;background-color:#f2dede;border:1px
solid #eed3d7;border-radius:4px}.mform fieldset.collapsible legend
a.fheader{padding:0
5px 0 20px;margin-left:-20px;background:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fexpanded) 2px center no-repeat}.dir-rtl .mform fieldset.collapsible legend
a.fheader{padding:0
20px 0 5px;margin-right:-20px;margin-left:0;background-position:right center}.mform fieldset.collapsed legend
a.fheader{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed)}.dir-rtl .mform fieldset.collapsed legend
a.fheader{background-image:url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fcollapsed_rtl)}.jsenabled .mform .collapsed
.fcontainer{display:none}.mform .fitem .fitemtitle
div{display:inline}.loginpanel .error,.mform
.error{color:#b94a48}.mform
.fdescription.required{margin-left:200px}.mform .fpassword
.unmask{display:inline-block;margin-left:.5em}.mform .fpassword .unmask>input{margin:0}.mform .fpassword .unmask>label{display:inline-block}.mform
label{display:inline-block}.mform
.iconhelp{margin-left:4px}.dir-rtl .mform
.iconhelp{margin-right:4px}.mform .ftextarea
#id_alltext{width:100%}.mform ul.file-list{padding:0;margin:0;list-style:none}.mform label .req,.mform label
.adv{cursor:help}.mform .fcheckbox
input{margin-top:5px;margin-left:0}.mform .fitem fieldset.fgroup label,.mform fieldset.fdate_selector
label{display:inline;float:none;width:auto}.mform .ftags
label.accesshide{position:static;display:block}.mform .ftags
select{min-width:22em;margin-bottom:.7em}.mform .helplink
img{padding:0;margin:0
.45em}.mform legend .helplink
img{margin:0
.2em}.singleselect
label{margin-right:.3em}.dir-rtl .singleselect
label{margin-right:0;margin-left:.3em}input#id_externalurl{direction:ltr}#portfolio-add-button{display:inline}.form-item,.mform
.fitem{margin-bottom:20px;margin-bottom:10px;*zoom:1}.form-item:before,.mform .fitem:before,.form-item:after,.mform .fitem:after{display:table;line-height:0;content:""}.form-item:after,.mform .fitem:after{clear:both}.form-item .form-label,.mform .fitem
div.fitemtitle{float:left;width:180px;padding-top:5px;text-align:right}.dir-rtl .form-item .form-label,.dir-rtl .mform .fitem
div.fitemtitle{float:right;text-align:left}.form-defaultinfo,.form-label .form-shortname{color:#999}.form-label .form-shortname{display:block;font-size:10.5px}.dir-rtl .form-label .form-shortname{text-align:left}.form-item .form-setting,.form-item .form-description,.mform .fitem .felement,#page-mod-forum-search
.c1{*display:inline-block;*padding-left:20px;margin-left:200px;*margin-left:0}.form-item .form-setting:first-child,.form-item .form-description:first-child,.mform .fitem .felement:first-child,#page-mod-forum-search .c1:first-child{*padding-left:200px}.formsettingheading{margin-bottom:0}.form-item .form-description,.felement.fstatic{display:block;padding-top:5px;margin-bottom:10px;color:#595959}.form-item .form-description{padding-top:0}table#form td.submit,.form-buttons,.path-admin .buttons,#fitem_id_submitbutton,.fp-content-center form+div,div.backup-section+form,#fgroup_id_buttonar{padding:19px
20px 20px;padding-left:0;margin-top:20px;margin-bottom:20px;background-color:#f5f5f5;border-top:1px solid #e5e5e5;*zoom:1}table#form td.submit:before,.form-buttons:before,.path-admin .buttons:before,#fitem_id_submitbutton:before,.fp-content-center form+div:before,div.backup-section+form:before,#fgroup_id_buttonar:before,table#form td.submit:after,.form-buttons:after,.path-admin .buttons:after,#fitem_id_submitbutton:after,.fp-content-center form+div:after,div.backup-section+form:after,#fgroup_id_buttonar:after{display:table;line-height:0;content:""}table#form td.submit:after,.form-buttons:after,.path-admin .buttons:after,#fitem_id_submitbutton:after,.fp-content-center form+div:after,div.backup-section+form:after,#fgroup_id_buttonar:after{clear:both}.path-admin .buttons,.form-buttons{padding-left:200px}.dir-rtl table#form td.submit,.dir-rtl .form-buttons,.dir-rtl .path-admin .buttons,.dir-rtl #fitem_id_submitbutton,.dir-rtl .fp-content-center form+div,.dir-rtl div.backup-section+form,.dir-rtl
#fgroup_id_buttonar{padding:19px
20px 20px;padding-right:0;margin-top:20px;margin-bottom:20px;background-color:#f5f5f5;border-top:1px solid #e5e5e5;*zoom:1}.dir-rtl table#form td.submit:before,.dir-rtl .form-buttons:before,.dir-rtl .path-admin .buttons:before,.dir-rtl #fitem_id_submitbutton:before,.dir-rtl .fp-content-center form+div:before,.dir-rtl div.backup-section+form:before,.dir-rtl #fgroup_id_buttonar:before,.dir-rtl table#form td.submit:after,.dir-rtl .form-buttons:after,.dir-rtl .path-admin .buttons:after,.dir-rtl #fitem_id_submitbutton:after,.dir-rtl .fp-content-center form+div:after,.dir-rtl div.backup-section+form:after,.dir-rtl #fgroup_id_buttonar:after{display:table;line-height:0;content:""}.dir-rtl table#form td.submit:after,.dir-rtl .form-buttons:after,.dir-rtl .path-admin .buttons:after,.dir-rtl #fitem_id_submitbutton:after,.dir-rtl .fp-content-center form+div:after,.dir-rtl div.backup-section+form:after,.dir-rtl #fgroup_id_buttonar:after{clear:both}.dir-rtl .path-admin .buttons,.dir-rtl .form-buttons{padding-right:200px}.form-item .form-setting .form-checkbox.defaultsnext{display:inline-block;margin-top:5px}#adminsettings
h3{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:40px;color:#333;border:0;border-bottom:1px solid #e5e5e5}.mform legend a,.mform legend a:hover{color:#333;text-decoration:none}.dir-rtl .mform .fitem
.felement{margin-right:30%;margin-left:auto;text-align:right}.dir-rtl .mform .fitem .felement input[name=email],.dir-rtl .mform .fitem .felement input[name=email2],.dir-rtl .mform .fitem .felement input[name=url],.dir-rtl .mform .fitem .felement input[name=idnumber],.dir-rtl .mform .fitem .felement input[name=phone1],.dir-rtl .mform .fitem .felement input[name=phone2]{text-align:left;direction:ltr}.dir-rtl #id_s__pathtodu,.dir-rtl #id_s__aspellpath,.dir-rtl #id_s__pathtodot,.dir-rtl #id_s__supportemail,.dir-rtl #id_s__supportpage,.dir-rtl #id_s__sessioncookie,.dir-rtl #id_s__sessioncookiepath,.dir-rtl #id_s__sessioncookiedomain,.dir-rtl #id_s__proxyhost,.dir-rtl #id_s__proxyuser,.dir-rtl #id_s__proxypassword,.dir-rtl #id_s__proxybypass,.dir-rtl #id_s__jabberhost,.dir-rtl #id_s__jabberserver,.dir-rtl #id_s__jabberusername,.dir-rtl #id_s__jabberpassword,.dir-rtl #id_s__additionalhtmlhead,.dir-rtl #id_s__additionalhtmltopofbody,.dir-rtl #id_s__additionalhtmlfooter,.dir-rtl #id_s__docroot,.dir-rtl #id_s__filter_tex_latexpreamble,.dir-rtl #id_s__filter_tex_latexbackground,.dir-rtl #id_s__filter_tex_pathlatex,.dir-rtl #id_s__filter_tex_pathdvips,.dir-rtl #id_s__filter_tex_pathconvert,.dir-rtl #id_s__blockedip,.dir-rtl #id_s__pathtoclam,.dir-rtl #id_s__quarantinedir,.dir-rtl #id_s__sitepolicy,.dir-rtl #id_s__sitepolicyguest,.dir-rtl #id_s__cronremotepassword,.dir-rtl #id_s__allowedip,.dir-rtl #id_s__blockedip,.dir-rtl #id_s_enrol_meta_nosyncroleids,.dir-rtl #id_s_enrol_ldap_host_url,.dir-rtl #id_s_enrol_ldap_ldapencoding,.dir-rtl #id_s_enrol_ldap_bind_dn,.dir-rtl #id_s_enrol_ldap_bind_pw,.dir-rtl #admin-emoticons .form-text,.dir-rtl #admin-role_mapping input[type=text],.dir-rtl #id_s_enrol_paypal_paypalbusiness,.dir-rtl #id_s_enrol_flatfile_location,#page-admin-setting-enrolsettingsflatfile.dir-rtl input[type=text],#page-admin-setting-enrolsettingsdatabase.dir-rtl input[type=text],#page-admin-auth-db.dir-rtl input[type=text]{direction:ltr}#page-admin-setting-enrolsettingsflatfile.dir-rtl
.informationbox{text-align:left;direction:ltr}#page-admin-grade-edit-scale-edit.dir-rtl .error
input#id_name{margin-right:170px}#page-grade-edit-outcome-course
.courseoutcomes{width:100%;margin-right:auto;margin-left:auto}#page-grade-edit-outcome-course .courseoutcomes
td{text-align:center}#installform #id_wwwroot,#installform #id_dirroot,#installform #id_dataroot,#installform #id_dbhost,#installform #id_dbname,#installform #id_dbuser,#installform #id_dbpass,#installform
#id_prefix{direction:ltr}.mdl-right>label{display:inline-block}input[type="radio"]+label,input[type="checkbox"]+label{display:inline;padding-left:.2em}input[type="radio"],input[type="checkbox"]{margin-top:-4px;margin-right:7px}.dir-rtl input[type="radio"],.dir-rtl input[type="checkbox"]{margin-right:auto;margin-left:7px}.singleselect{display:inline-block}.singleselect form,.singleselect
select{margin:0}.form-item .form-label
label{margin-bottom:0}.dir-rtl .form-item .form-label
label{text-align:left}.felement.ffilepicker{margin-top:5px}div#dateselector-calendar-panel{z-index:3100}fieldset.coursesearchbox
label{display:inline}#region-main .mform:not(.unresponsive) .fitem .fitemtitle
label{font-weight:bold}@media(max-width:1199px){body #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{display:block;width:100%;margin-top:4px;margin-bottom:4px;text-align:left}body #region-main .mform:not(.unresponsive) .fitem
.felement{float:left;width:100%;padding-right:0;padding-left:0;margin-left:0}body #region-main .mform:not(.unresponsive) .fitem .fstatic:empty{display:none}body #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:8px}body #region-main .mform:not(.unresponsive) .femptylabel
.felement{display:inline-block;width:auto;padding-top:5px;margin-top:4px}body #region-main .mform:not(.unresponsive) .fitem_fcheckbox .fitemtitle,body #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{display:inline-block;width:auto}body #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{padding:6px}body.dir-rtl #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{margin-right:0;margin-left:8px}body.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{text-align:right}body.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.felement{float:right;padding-right:0;padding-left:0;margin-right:0}body.dir-rtl #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{float:right}}@media(max-width:1474px){.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{display:block;width:100%;margin-top:4px;margin-bottom:4px;text-align:left}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem
.felement{float:left;width:100%;padding-right:0;padding-left:0;margin-left:0}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem .fstatic:empty{display:none}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:8px}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .femptylabel
.felement{display:inline-block;width:auto;padding-top:5px;margin-top:4px}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem_fcheckbox .fitemtitle,.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{display:inline-block;width:auto}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{padding:6px}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{margin-right:0;margin-left:8px}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{text-align:right}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.felement{float:right;padding-right:0;padding-left:0;margin-right:0}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{float:right}}#fitem_id_availabilityconditionsjson *[aria-hidden=true]{display:none}#fitem_id_availabilityconditionsjson select,#fitem_id_availabilityconditionsjson input[type=text]{position:relative;top:4px}#fitem_id_availabilityconditionsjson
label{display:inline}#fitem_id_availabilityconditionsjson .availability-group{margin-right:8px}#fitem_id_availabilityconditionsjson .availability-item{margin-bottom:6px}#fitem_id_availabilityconditionsjson .availability-none{margin-bottom:4px;margin-left:20px}#fitem_id_availabilityconditionsjson .availability-plugincontrols{display:inline-block;padding:2px
0 0 4px;margin-right:8px;background:none repeat scroll 0 0 #f5f5f5;border:1px
solid #eee;border-radius:4px}#fitem_id_availabilityconditionsjson .availability-eye,#fitem_id_availabilityconditionsjson .availability-delete{margin-right:8px}#fitem_id_availabilityconditionsjson .availability-eye[aria-hidden=true]{display:inline;visibility:hidden}#fitem_id_availabilityconditionsjson .availability-list>.availability-eye
img{margin-top:12px;vertical-align:top}#fitem_id_availabilityconditionsjson .availability-button{margin-left:15px}#fitem_id_availabilityconditionsjson .availability-childlist>.availability-inner{display:inline-block;padding:6px;margin-bottom:6px;background:#f5f5f5;border:1px
solid #eee;border-radius:4px}#fitem_id_availabilityconditionsjson .availability-childlist .availability-childlist>.availability-inner{background:white}#fitem_id_availabilityconditionsjson .availability-connector{margin-bottom:6px;margin-left:20px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-group{margin-right:0;margin-left:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-none{margin-right:20px;margin-left:0}.dir-rtl #fitem_id_availabilityconditionsjson .availability-plugincontrols{padding-right:4px;padding-left:0;margin-right:0;margin-left:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-eye,.dir-rtl #fitem_id_availabilityconditionsjson .availability-delete{margin-right:0;margin-left:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-button{margin-right:15px;margin-left:0}.dir-rtl #fitem_id_availabilityconditionsjson .availability-connector{margin-right:20px;margin-left:0}.mform .error .availability-field{color:#333}.availability-dialogue .moodle-dialogue .moodle-dialogue-bd{padding-right:0;padding-bottom:2px;padding-left:0}.availability-dialogue
ul{display:block;margin:0}.availability-dialogue
li{display:block;padding:0
0 4px;margin-bottom:4px;clear:both;list-style-type:none;border-bottom:1px solid #eee}.availability-dialogue ul
button{float:left;min-width:140px;margin-top:4px;margin-left:1em}.availability-dialogue
label{margin-right:1em;margin-bottom:0;margin-left:170px}.availability-dialogue .availability-buttons
button{margin-top:4px;margin-right:1em;margin-left:1em}.dir-rtl .availability-dialogue ul
button{float:right;margin-right:1em;margin-left:0}.dir-rtl .availability-dialogue
label{margin-right:170px;margin-left:1em}textarea[cols],input[size]{width:auto}select{width:auto}.path-mod-forum .forumsearch input,.path-mod-forum .forumsearch
.helptooltip{margin:0
3px}.path-mod-forum .forumheaderlist,.path-mod-forum .forumheaderlist
td{border:0}.path-mod-forum .forumheaderlist thead
.header{white-space:normal;vertical-align:top}.path-mod-forum .forumheaderlist thead
.header.replies{text-align:center}.path-mod-forum .forumheaderlist thead
.header.lastpost{text-align:right}.path-mod-forum .forumheaderlist .discussion .author,.path-mod-forum .forumheaderlist .discussion .replies,.path-mod-forum .forumheaderlist .discussion
.lastpost{white-space:normal}.path-mod-forum .forumheaderlist .discussion
.replies{text-align:center}.path-mod-forum .forumheaderlist .discussion .topic,.path-mod-forum .forumheaderlist .discussion .topic.starter,.path-mod-forum .forumheaderlist .discussion .picture,.path-mod-forum .forumheaderlist .discussion .author,.path-mod-forum .forumheaderlist .discussion .replies,.path-mod-forum .forumheaderlist .discussion
.lastpost{vertical-align:top}.path-mod-feedback .generalbox div table tbody
img{height:5px}.forumpost{min-height:20px;padding:19px;padding:6px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.forumpost
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.forumpost
.header{margin-bottom:3px}.forumpost .picture
img{margin:3px}.forumpost .picture
img.userpicture{margin-right:10px;margin-left:3px}.forumpost .content
.posting.fullpost{margin-top:8px}.forumpost .row .topic,.forumpost .row .content-mask,.forumpost .row
.options{margin-left:48px}.forumpost
.row.side{clear:both}.dir-rtl .forumpost .picture
img.userpicture{margin-right:3px;margin-left:10px}.dir-rtl .forumpost .row .topic,.dir-rtl .forumpost .row .content-mask,.dir-rtl .forumpost .row
.options{margin-right:48px;margin-left:0}.forumpost .row
.left{width:48px}.forumpost .options
.commands{margin-left:0}.forumpost
.subject{font-weight:bold}.forumsearch input[type=text]{margin-bottom:0!important}#page-mod-forum-discuss
.discussioncontrols{width:auto;margin:0}#page-footer{padding:1em
0;margin-top:1em;border-top:2px solid #ddd}.maincalendar .calendarmonth td,.maincalendar .calendarmonth
th{border:1px
dotted #ddd}.path-grade-report-grader
h1{text-align:inherit}#page-mod-chat-gui_basic
input#message{max-width:100%}#page-mod-data-view
#singleimage{width:auto}.path-mod-data
form{margin-top:10px}.template_heading{margin-top:10px}.breadcrumb-button{float:right;margin-top:4px}.breadcrumb-button
.singlebutton{float:left;margin-left:4px}.dir-rtl .nav-tabs>li,.dir-rtl .nav-pills>li{float:right}.dir-rtl .navbar
.brand{float:right}.navbar-inverse .logininfo
a{color:#999}.navbar-inverse .logininfo a:hover{color:#fff;background-color:transparent}.navbar-fixed-top,.navbar-fixed-bottom{z-index:4030}.dir-rtl .breadcrumb-button,.dir-rtl .navbar .btn-navbar{float:left}.dir-rtl .breadcrumb-button
.singlebutton{float:right;margin-right:4px}.ie .row-fluid .desktop-first-column{margin-left:0}.langmenu
form{margin:0}.container-fluid{max-width:1680px;margin:0
auto}canvas{-ms-touch-action:auto}div#dock{display:none}.path-mod-choice .horizontal
.choices{margin:0}.path-mod-choice .horizontal .choices
.option{display:inline-block;padding:10px}.path-mod-choice .results
.data{white-space:normal}.path-mod-lesson
.firstpageoptions{width:60%;min-width:280px;margin:auto}.path-mod-lesson
.centerpadded{padding:5px;text-align:center}.path-mod-wiki .wiki_headingtitle,.path-mod-wiki .midpad,.path-mod-wiki
.wiki_headingtime{text-align:inherit}.path-mod-wiki
.wiki_contentbox{width:100%}.path-mod-survey .surveytable>tbody>tr:nth-of-type(odd){background-color:transparent}.path-mod-survey .surveytable>tbody>tr:nth-of-type(even){background-color:#f9f9f9}.path-mod-survey .surveytable .rblock
label{text-align:center}.path-mod-survey .resultgraph,.path-mod-survey .reportsummary,.path-mod-survey .studentreport,.path-mod-survey .reportbuttons,.path-mod-survey
.centerpara{text-align:center}.dir-rtl.path-mod-forum .forumheaderlist thead
.header.lastpost{text-align:left}.dir-rtl.path-mod-forum .forumheaderlist .discussion
.lastpost{text-align:left}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax{background-color:#fff}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd-nohd,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd-noft,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-right,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-bottom{border:0}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-right,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-bottom{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;border-radius:0;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-right blockquote,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-bottom
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd{background-color:transparent}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable
td.cell{padding:3px
15px;white-space:nowrap;border:0}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable input,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable td.cell
input{margin:0
10px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable input#input-message,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable td.cell input#input-message{width:45%;margin:auto}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable a,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable td.cell
a{margin:0
5px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist{padding:10px
5px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist #users-list{border-top:1px solid #ddd;border-bottom:1px solid #fff}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist #users-list
li{padding:5px
10px;border-top:1px solid #fff;border-bottom:1px solid #ddd}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist #users-list
img{max-width:none;margin-right:8px;border:1px
solid #ccc;border-radius:4px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages{margin:20px
25px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .chat-event.course-theme{margin:10px
0;font-size:11.9px;color:#777;text-align:center}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .chat-message.course-theme{padding:4px
10px;margin:10px
0;background-color:#fff;border:1px
dotted #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .chat-message.course-theme
.time{float:right;font-size:11px;color:#777}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .mdl-chat-my-entry .chat-message.course-theme{background-color:#f6f6f6}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .mdl-chat-my-entry .chat-message.course-theme
.user{font-weight:bold}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl .yui-layout-unit-right{padding:0}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl .yui-layout-unit div.yui-layout-bd{text-align:right}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-userlist #users-list
img{margin-left:8px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme
.time{float:left}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme
.user{float:right}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme .chat-message-meta{height:20px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme
.text{text-align:right}#page-report-participation-index .participationselectform div
label{display:inline;margin:0
5px}#page-report-participation-index.dir-ltr .participationselectform div label[for=menuinstanceid]{margin-left:0}#page-report-participation-index.dir-rtl .participationselectform div label[for=menuinstanceid]{margin-right:0}.path-backup .mform
.grouped_settings.section_level{min-height:20px;padding:19px;padding:10px
0 0 0;margin-bottom:20px;clear:both;background-color:#f5f5f5;border:1px
solid #e3e3e3;border-color:#e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.path-backup .mform .grouped_settings.section_level
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.path-backup .mform
.grouped_settings{overflow:hidden;clear:both}.path-backup .include_setting,.path-backup .grouped_settings
.normal_setting{display:inline-block}.path-backup .include_setting.section_level
label{font-weight:bold}.path-backup .mform .fitem
.fitemtitle{width:260px}.path-backup .mform .fitem
.felement{margin-left:280px}.path-backup
.notification.dependencies_enforced{font-weight:bold;color:#b94a48;text-align:center}.path-backup
.backup_progress{text-align:center}.path-backup .backup_progress
.backup_stage{color:#999}.path-backup .backup_progress
.backup_stage.backup_stage_current{font-weight:bold;color:inherit}.path-backup .backup_progress
span.backup_stage.backup_stage_complete{color:inherit}#page-backup-restore
.filealiasesfailures{background-color:#f2dede}#page-backup-restore .filealiasesfailures
.aliaseslist{width:90%;margin:.8em auto;background-color:#fff;border:1px
dotted #666}.path-backup .fitem
.smallicon{vertical-align:text-bottom}.backup-restore .backup-section>h2.header,.backup-restore .backup-section .backup-sub-section
h3{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:40px;color:#333;border:0;border-bottom:1px solid #e5e5e5}.backup-restore .backup-section
.noticebox{width:60%;margin:1em
auto;text-align:center}.backup-restore .backup-section.settings-section .detail-pair{display:inline-block;*display:inline;width:50%;*zoom:1}.backup-restore .backup-section.settings-section .detail-pair-label{width:65%}.backup-restore .backup-section.settings-section .detail-pair-value{width:25%}.backup-restore
.activitytable{min-width:500px}.backup-restore .activitytable
.modulename{width:100px}.backup-restore .activitytable
.moduleincluded{width:50px}.backup-restore .activitytable
.userinfoincluded{width:50px}.backup-restore .detail-pair-label{display:inline-block;*display:inline;width:25%;padding:8px;margin:0;font-weight:bold;text-align:right;vertical-align:top;*zoom:1}.backup-restore .detail-pair-value{display:inline-block;*display:inline;width:65%;padding:8px;margin:0;*zoom:1}.backup-restore .detail-pair-value>.sub-detail{display:block;font-size:11.9px;color:#999}.backup-restore>.singlebutton{text-align:right}.path-backup .mform .fgroup
.proceedbutton{float:right;margin-right:5%}.restore-course-search .rcs-results{width:70%;min-width:400px}.restore-course-search .rcs-results
table{width:100%;margin:0;border-width:0}.restore-course-search .rcs-results table .no-overflow{max-width:600px}.restore-course-search .rcs-results
.paging{padding:3px;margin:0;text-align:left;background-color:#eee}.restore-course-category .rcs-results{width:70%;min-width:400px;margin:5px
0;border:1px
solid #ddd}.restore-course-category .rcs-results
table{width:100%;margin:0;border-width:0}.restore-course-category .rcs-results table .no-overflow{max-width:600px}.restore-course-category .rcs-results
.paging{padding:3px;margin:0;text-align:left;background-color:#eee}.path-backup
.wibbler{position:relative;width:500px;min-height:4px;margin:0
auto 10px;border-right:1px solid black;border-bottom:1px solid black;border-left:1px solid black}.path-backup .wibbler
.wibble{position:absolute;top:0;right:0;left:0;height:4px}.path-backup .wibbler
.state0{background:#eee}.path-backup .wibbler
.state1{background:#ddd}.path-backup .wibbler
.state2{background:#ccc}.path-backup .wibbler
.state3{background:#bbb}.path-backup .wibbler
.state4{background:#aaa}.path-backup .wibbler
.state5{background:#999}.path-backup .wibbler
.state6{background:#888}.path-backup .wibbler
.state7{background:#777}.path-backup .wibbler
.state8{background:#666}.path-backup .wibbler
.state9{background:#555}.path-backup .wibbler
.state10{background:#444}.path-backup .wibbler
.state11{background:#333}.path-backup .wibbler
.state12{background:#222}.path-backup
.backup_log{margin-top:2em}.path-backup .backup_log
h2{font-size:1em}.path-backup
.backup_log_contents{height:300px;padding:10px;overflow-y:scroll;border:1px
solid #ddd}table.flexible,.generaltable{width:100%;margin-bottom:20px}table.flexible th,.generaltable th,table.flexible td,.generaltable
td{padding:8px;line-height:20px;text-align:left;vertical-align:top;border-top:1px solid #ddd}table.flexible th,.generaltable
th{font-weight:bold}table.flexible thead th,.generaltable thead
th{vertical-align:bottom}table.flexible caption+thead tr:first-child th,.generaltable caption+thead tr:first-child th,table.flexible caption+thead tr:first-child td,.generaltable caption+thead tr:first-child td,table.flexible colgroup+thead tr:first-child th,.generaltable colgroup+thead tr:first-child th,table.flexible colgroup+thead tr:first-child td,.generaltable colgroup+thead tr:first-child td,table.flexible thead:first-child tr:first-child th,.generaltable thead:first-child tr:first-child th,table.flexible thead:first-child tr:first-child td,.generaltable thead:first-child tr:first-child
td{border-top:0}table.flexible tbody+tbody,.generaltable tbody+tbody{border-top:2px solid #ddd}table.flexible .table,.generaltable
.table{background-color:#fff}.singlebutton
div{display:inline-block;margin-right:5px;margin-bottom:5px;margin-left:5px}#notice .buttons
.singlebutton{display:inline-block}.continuebutton{text-align:center}.btn-lineup{margin:0
0 10px 5px}input[name="searchwikicontent"]+input[type="submit"],select+input[type="submit"],input[type="text"]+input[type="button"],input[type="password"]+input[type="submit"],input[type="text"]+button,input[type="text"]+input[type="submit"]{margin:0
0 10px 5px}p.arrow_button{margin-top:5em;text-align:center}p.arrow_button
#remove{margin:3em
auto 5em}p.arrow_button
input{display:block;width:100%;padding-right:0;padding-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}#addcontrols{margin-top:30px;margin-bottom:3em;text-align:center}#addcontrols
label{display:inline}#addcontrols input,#removecontrols
input{display:block;width:100%;padding-right:0;padding-left:0;margin-right:auto;margin-left:auto;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}button,input.form-submit,input[type="button"],input[type="submit"],input[type="reset"]{display:inline-block;*display:inline;padding:4px
12px;margin-bottom:0;*margin-left:.3em;font-size:14px;line-height:20px;color:#333;text-align:center;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;cursor:pointer;background-color:#f5f5f5;*background-color:#e6e6e6;background-image:-moz-linear-gradient(top,#fff,#e6e6e6);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#e6e6e6));background-image:-webkit-linear-gradient(top,#fff,#e6e6e6);background-image:-o-linear-gradient(top,#fff,#e6e6e6);background-image:linear-gradient(to bottom,#fff,#e6e6e6);background-repeat:repeat-x;border:1px
solid #ccc;*border:0;border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe6e6e6',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);*zoom:1;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}button:hover,input.form-submit:hover,input[type="button"]:hover,input[type="submit"]:hover,input[type="reset"]:hover,button:focus,input.form-submit:focus,input[type="button"]:focus,input[type="submit"]:focus,input[type="reset"]:focus,button:active,input.form-submit:active,input[type="button"]:active,input[type="submit"]:active,input[type="reset"]:active,button.active,input.form-submit.active,input[type="button"].active,input[type="submit"].active,input[type="reset"].active,button.disabled,input.form-submit.disabled,input[type="button"].disabled,input[type="submit"].disabled,input[type="reset"].disabled,button[disabled],input.form-submit[disabled],input[type="button"][disabled],input[type="submit"][disabled],input[type="reset"][disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}button:active,input.form-submit:active,input[type="button"]:active,input[type="submit"]:active,input[type="reset"]:active,button.active,input.form-submit.active,input[type="button"].active,input[type="submit"].active,input[type="reset"].active{background-color:#ccc \9}button:first-child,input.form-submit:first-child,input[type="button"]:first-child,input[type="submit"]:first-child,input[type="reset"]:first-child{*margin-left:0}button:hover,input.form-submit:hover,input[type="button"]:hover,input[type="submit"]:hover,input[type="reset"]:hover,button:focus,input.form-submit:focus,input[type="button"]:focus,input[type="submit"]:focus,input[type="reset"]:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}button:focus,input.form-submit:focus,input[type="button"]:focus,input[type="submit"]:focus,input[type="reset"]:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}button.active,input.form-submit.active,input[type="button"].active,input[type="submit"].active,input[type="reset"].active,button:active,input.form-submit:active,input[type="button"]:active,input[type="submit"]:active,input[type="reset"]:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}button.disabled,input.form-submit.disabled,input[type="button"].disabled,input[type="submit"].disabled,input[type="reset"].disabled,button[disabled],input.form-submit[disabled],input[type="button"][disabled],input[type="submit"][disabled],input[type="reset"][disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}button .label,input.form-submit .label,input[type="button"] .label,input[type="submit"] .label,input[type="reset"] .label,button .badge,input.form-submit .badge,input[type="button"] .badge,input[type="submit"] .badge,input[type="reset"] .badge{position:relative;top:-1px}button,input.form-submit,input[type="button"],input[type="submit"],input[type="reset"]{margin:0
0 10px 5px}button.yui3-button.closebutton,button.yui3-button.closebutton:hover{background-position:0 0}input.fp-btn-choose{padding:2px
10px;font-size:11.9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.user-enroller-panel .uep-search-results .user .options
.enrol{padding:0
6px;font-size:10.5px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.user-enroller-panel .uep-search-results .user .options .enrol .label,.user-enroller-panel .uep-search-results .user .options .enrol
.badge{top:0}.gradetreebox
h4{font-size:14px}.gradetreebox th.cell,.gradetreebox input[type=text]{width:auto}.gradetreebox input[type=text],.gradetreebox
select{margin-bottom:0}#page-grade-report-grader-index
.topscrollcontent{height:1px}#page-grade-report-grader-index #user-grades{margin-top:4px}#page-grade-grading-manage #activemethodselector
label{display:inline-block}#page-grade-grading-manage #activemethodselector
.helptooltip{margin-right:.5em}#page-grade-grading-manage
.actions{display:block;margin-bottom:1em;text-align:center}#page-grade-grading-manage .actions
.action{position:relative;display:inline-block;*display:inline;width:150px;padding:4px
12px;padding:11px
19px;padding:1em;margin:.5em;margin-bottom:0;*margin-left:.3em;overflow:hidden;font-size:14px;font-size:17.5px;line-height:20px;color:#333;text-align:center;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;vertical-align:top;cursor:pointer;background-color:#f5f5f5;*background-color:#e6e6e6;background-image:-moz-linear-gradient(top,#fff,#e6e6e6);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#e6e6e6));background-image:-webkit-linear-gradient(top,#fff,#e6e6e6);background-image:-o-linear-gradient(top,#fff,#e6e6e6);background-image:linear-gradient(to bottom,#fff,#e6e6e6);background-repeat:repeat-x;border:1px
solid #ccc;border:1px
solid #aaa;*border:0;border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-webkit-border-radius:6px;-moz-border-radius:4px;-moz-border-radius:6px;border-radius:4px;border-radius:6px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe6e6e6',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);*zoom:1;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}#page-grade-grading-manage .actions .action:hover,#page-grade-grading-manage .actions .action:focus,#page-grade-grading-manage .actions .action:active,#page-grade-grading-manage .actions .action.active,#page-grade-grading-manage .actions .action.disabled,#page-grade-grading-manage .actions .action[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#page-grade-grading-manage .actions .action:active,#page-grade-grading-manage .actions
.action.active{background-color:#ccc \9}#page-grade-grading-manage .actions .action:first-child{*margin-left:0}#page-grade-grading-manage .actions .action:hover,#page-grade-grading-manage .actions .action:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#page-grade-grading-manage .actions .action:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#page-grade-grading-manage .actions .action.active,#page-grade-grading-manage .actions .action:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}#page-grade-grading-manage .actions .action.disabled,#page-grade-grading-manage .actions .action[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#page-grade-grading-manage .actions .action .label,#page-grade-grading-manage .actions .action
.badge{position:relative;top:-1px}#page-grade-grading-manage .actions .action .action-icon{position:relative;display:inline-block;width:64px;height:64px}#page-grade-grading-manage .actions .action .action-text{position:relative;top:.4em;font-size:14px}#page-grade-grading-form-rubric-edit .gradingform_rubric_editform
.status{font-size:70%}.gradingform_rubric.editor .addlevel input,.gradingform_rubric.editor .addcriterion
input{background:#fff none no-repeat top left}.dir-rtl #rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level
.score{float:right;margin-right:0;margin-left:28px;text-align:right}.dir-rtl #rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level
.delete{float:left}.dir-rtl #rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level .delete
input{right:auto;left:0}.dir-rtl #rubric-rubric.gradingform_rubric
.addcriterion{margin-right:5px;margin-left:0}.dir-rtl #rubric-rubric.gradingform_rubric .addcriterion
input{padding-right:26px;padding-left:10px;background-position:right 8px top 8px}.dir-rtl #rubric-rubric.gradingform_rubric .options .option
.value{margin-right:5px;margin-left:0}.dir-rtl #rubric-rubric.gradingform_rubric .options .option
input{margin-right:5px;margin-left:12px}#rubric-rubric.gradingform_rubric #rubric-criteria{margin-bottom:1em}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.description{padding:6px;vertical-align:top}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .description
textarea{height:115px;margin-bottom:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .definition
textarea{width:80%;margin-bottom:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.score{position:relative;float:left;margin-right:28px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .score
input{margin-bottom:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.level{padding:6px;vertical-align:top}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level
.delete{position:relative;float:right;width:32px;height:32px;margin-top:-32px;clear:both}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level .delete
input{position:absolute;right:0;bottom:0;display:block;width:24px;height:24px;margin:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level .delete input:hover{background-color:#ddd}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .scorevalue
input{float:none;width:2em}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .scorevalue input.hiddenelement,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .scorevalue
input.pseudotablink{width:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.addlevel{vertical-align:middle}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel
input{display:inline-block;*display:inline;height:30px;padding:4px
12px;margin-right:5px;margin-bottom:0;*margin-left:.3em;font-size:14px;line-height:20px;color:#333;text-align:center;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;cursor:pointer;background-color:#f5f5f5;*background-color:#e6e6e6;background-image:-moz-linear-gradient(top,#fff,#e6e6e6);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#e6e6e6));background-image:-webkit-linear-gradient(top,#fff,#e6e6e6);background-image:-o-linear-gradient(top,#fff,#e6e6e6);background-image:linear-gradient(to bottom,#fff,#e6e6e6);background-position:0 0;background-repeat:repeat-x;border:1px
solid #ccc;*border:0;border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe6e6e6',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);*zoom:1;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:hover,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:focus,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.disabled,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel
input.active{background-color:#ccc \9}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:first-child{*margin-left:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:hover,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.disabled,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input .label,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input
.badge{position:relative;top:-1px}#rubric-rubric.gradingform_rubric
.addcriterion{display:inline-block;*display:inline;padding:4px
12px;padding:0;margin-bottom:0;margin-bottom:1em;margin-left:5px;*margin-left:.3em;font-size:14px;line-height:20px;color:#333;text-align:center;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;cursor:pointer;background-color:#f5f5f5;*background-color:#e6e6e6;background-image:-moz-linear-gradient(top,#fff,#e6e6e6);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#e6e6e6));background-image:-webkit-linear-gradient(top,#fff,#e6e6e6);background-image:-o-linear-gradient(top,#fff,#e6e6e6);background-image:linear-gradient(to bottom,#fff,#e6e6e6);background-repeat:repeat-x;border:1px
solid #ccc;*border:0;border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe6e6e6',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);*zoom:1;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}#rubric-rubric.gradingform_rubric .addcriterion:hover,#rubric-rubric.gradingform_rubric .addcriterion:focus,#rubric-rubric.gradingform_rubric .addcriterion:active,#rubric-rubric.gradingform_rubric .addcriterion.active,#rubric-rubric.gradingform_rubric .addcriterion.disabled,#rubric-rubric.gradingform_rubric .addcriterion[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#rubric-rubric.gradingform_rubric .addcriterion:active,#rubric-rubric.gradingform_rubric
.addcriterion.active{background-color:#ccc \9}#rubric-rubric.gradingform_rubric .addcriterion:first-child{*margin-left:0}#rubric-rubric.gradingform_rubric .addcriterion:hover,#rubric-rubric.gradingform_rubric .addcriterion:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#rubric-rubric.gradingform_rubric .addcriterion:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#rubric-rubric.gradingform_rubric .addcriterion.active,#rubric-rubric.gradingform_rubric .addcriterion:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}#rubric-rubric.gradingform_rubric .addcriterion.disabled,#rubric-rubric.gradingform_rubric .addcriterion[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#rubric-rubric.gradingform_rubric .addcriterion .label,#rubric-rubric.gradingform_rubric .addcriterion
.badge{position:relative;top:-1px}#rubric-rubric.gradingform_rubric .addcriterion
input{padding-left:26px;margin:0;line-height:inherit;color:inherit;text-shadow:inherit;background:transparent url(/moodle/theme/image.php?theme=clean&component=core&rev=1488795260&image=t%2Fadd) no-repeat 7px 8px;border:0
none}#rubric-rubric.gradingform_rubric
.options{clear:both}#rubric-rubric.gradingform_rubric .options .option
label{padding:0;margin:0;font-size:inherit;font-weight:normal;line-height:2em;color:inherit;text-shadow:none;background-color:transparent}#rubric-rubric.gradingform_rubric .options .option
input{margin-right:12px;margin-left:5px}.transform-test-heading{padding:0;margin:0;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:11px;font-weight:bold;line-height:36px;text-align:center}body.has_dock
#page{padding-left:45px}body.has_dock
div#dock{display:inline}#dock{position:fixed;top:0;left:0;width:42px;height:100%;background-color:transparent;border-right:0 none}#dock
.nothingdocked{display:none;visibility:hidden}#dock
.dockeditem_container{margin-top:68px}#dock .dockeditem
.firstdockitem{margin-top:1em}#dock
.dockedtitle{display:inline-block;display:block;*display:inline;width:36px;padding:4px
12px;padding:0;margin:3px;margin-bottom:0;*margin-left:.3em;font-size:14px;line-height:20px;color:#333;text-align:center;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;cursor:pointer;background-color:#f5f5f5;*background-color:#e6e6e6;background-image:-moz-linear-gradient(top,#fff,#e6e6e6);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#e6e6e6));background-image:-webkit-linear-gradient(top,#fff,#e6e6e6);background-image:-o-linear-gradient(top,#fff,#e6e6e6);background-image:linear-gradient(to bottom,#fff,#e6e6e6);background-repeat:repeat-x;border:1px
solid #ccc;*border:0;border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe6e6e6',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);*zoom:1;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}#dock .dockedtitle:hover,#dock .dockedtitle:focus,#dock .dockedtitle:active,#dock .dockedtitle.active,#dock .dockedtitle.disabled,#dock .dockedtitle[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#dock .dockedtitle:active,#dock
.dockedtitle.active{background-color:#ccc \9}#dock .dockedtitle:first-child{*margin-left:0}#dock .dockedtitle:hover,#dock .dockedtitle:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#dock .dockedtitle:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#dock .dockedtitle.active,#dock .dockedtitle:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}#dock .dockedtitle.disabled,#dock .dockedtitle[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#dock .dockedtitle .label,#dock .dockedtitle
.badge{position:relative;top:-1px}#dock .dockedtitle
h2{padding:0;margin:0;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:11px;font-weight:bold;line-height:36px;text-align:center}#dock .dockedtitle
.filterrotate{margin-left:8px}#dock
.controls{position:absolute;bottom:1em;width:100%;text-align:center}#dock .controls
img{cursor:pointer}#dock .editing_move,#dock .moodle-core-dragdrop-draghandle{display:none}#dockeditempanel{position:relative;left:100%;z-index:12000;min-width:200px;padding-left:5px}#dockeditempanel.dockitempanel_hidden{display:none}#dockeditempanel
.dockeditempanel_content{width:384px;background-color:#f5f5f5;border:1px
solid #d5d5d5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:2px 4px 4px 2px #eee;-moz-box-shadow:2px 4px 4px 2px #eee;box-shadow:2px 4px 4px 2px #eee}#dockeditempanel
.dockeditempanel_bd{overflow:auto}#dockeditempanel .dockeditempanel_bd>*{margin:1em}#dockeditempanel .dockeditempanel_bd .block_navigation .block_tree
li{overflow:visible}#dockeditempanel
.dockeditempanel_hd{padding:.5em 1em;border-bottom:1px solid #fff}#dockeditempanel .dockeditempanel_hd
h2{display:block;padding:3px
15px;padding:0;margin:0;font-size:11px;font-size:1.1em;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase}#dockeditempanel .dockeditempanel_hd
.commands{display:block;text-align:right}#dockeditempanel .dockeditempanel_hd .commands>a,#dockeditempanel .dockeditempanel_hd .commands>span{margin-left:3px;cursor:pointer}#dockeditempanel .dockeditempanel_hd .commands img,#dockeditempanel .dockeditempanel_hd .commands
input{margin-right:1px;vertical-align:middle}#dockeditempanel .dockeditempanel_hd .commands .hidepanemicon
img{cursor:pointer}.dir-rtl.has_dock
#page{padding-right:45px;padding-left:0}.dir-rtl
#dock{right:0;left:auto}.dir-rtl #dock .dockedtitle
h2{line-height:25px}.dir-rtl
#dockeditempanel{right:100%}.dir-rtl #dockeditempanel .dockeditempanel_hd
.commands{text-align:left}@-ms-viewport{width:device-width}.hidden{display:none;visibility:hidden}.visible-phone{display:none!important}.visible-tablet{display:none!important}.hidden-desktop{display:none!important}.visible-desktop{display:inherit!important}@media(min-width:768px) and (max-width:979px){.hidden-desktop{display:inherit!important}.visible-desktop{display:none!important}.visible-tablet{display:inherit!important}.hidden-tablet{display:none!important}}@media(max-width:767px){.hidden-desktop{display:inherit!important}.visible-desktop{display:none!important}.visible-phone{display:inherit!important}.hidden-phone{display:none!important}}.visible-print{display:none!important}@media
print{.visible-print{display:inherit!important}.hidden-print{display:none!important}}@media(min-width:1200px){.row{margin-left:-30px;*zoom:1}.row:before,.row:after{display:table;line-height:0;content:""}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:30px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:1170px}.span12{width:1170px}.span11{width:1070px}.span10{width:970px}.span9{width:870px}.span8{width:770px}.span7{width:670px}.span6{width:570px}.span5{width:470px}.span4{width:370px}.span3{width:270px}.span2{width:170px}.span1{width:70px}.offset12{margin-left:1230px}.offset11{margin-left:1130px}.offset10{margin-left:1030px}.offset9{margin-left:930px}.offset8{margin-left:830px}.offset7{margin-left:730px}.offset6{margin-left:630px}.offset5{margin-left:530px}.offset4{margin-left:430px}.offset3{margin-left:330px}.offset2{margin-left:230px}.offset1{margin-left:130px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;line-height:0;content:""}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;float:left;width:100%;min-height:30px;margin-left:2.564102564102564%;*margin-left:2.5109110747408616%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.564102564102564%}.row-fluid
.span12{width:100%;*width:99.94680851063829%}.row-fluid
.span11{width:91.45299145299145%;*width:91.39979996362975%}.row-fluid
.span10{width:82.90598290598291%;*width:82.8527914166212%}.row-fluid
.span9{width:74.35897435897436%;*width:74.30578286961266%}.row-fluid
.span8{width:65.81196581196582%;*width:65.75877432260411%}.row-fluid
.span7{width:57.26495726495726%;*width:57.21176577559556%}.row-fluid
.span6{width:48.717948717948715%;*width:48.664757228587014%}.row-fluid
.span5{width:40.17094017094017%;*width:40.11774868157847%}.row-fluid
.span4{width:31.623931623931625%;*width:31.570740134569924%}.row-fluid
.span3{width:23.076923076923077%;*width:23.023731587561375%}.row-fluid
.span2{width:14.52991452991453%;*width:14.476723040552828%}.row-fluid
.span1{width:5.982905982905983%;*width:5.929714493544281%}.row-fluid
.offset12{margin-left:105.12820512820512%;*margin-left:105.02182214948171%}.row-fluid .offset12:first-child{margin-left:102.56410256410257%;*margin-left:102.45771958537915%}.row-fluid
.offset11{margin-left:96.58119658119658%;*margin-left:96.47481360247316%}.row-fluid .offset11:first-child{margin-left:94.01709401709402%;*margin-left:93.91071103837061%}.row-fluid
.offset10{margin-left:88.03418803418803%;*margin-left:87.92780505546462%}.row-fluid .offset10:first-child{margin-left:85.47008547008548%;*margin-left:85.36370249136206%}.row-fluid
.offset9{margin-left:79.48717948717949%;*margin-left:79.38079650845607%}.row-fluid .offset9:first-child{margin-left:76.92307692307693%;*margin-left:76.81669394435352%}.row-fluid
.offset8{margin-left:70.94017094017094%;*margin-left:70.83378796144753%}.row-fluid .offset8:first-child{margin-left:68.37606837606839%;*margin-left:68.26968539734497%}.row-fluid
.offset7{margin-left:62.393162393162385%;*margin-left:62.28677941443899%}.row-fluid .offset7:first-child{margin-left:59.82905982905982%;*margin-left:59.72267685033642%}.row-fluid
.offset6{margin-left:53.84615384615384%;*margin-left:53.739770867430444%}.row-fluid .offset6:first-child{margin-left:51.28205128205128%;*margin-left:51.175668303327875%}.row-fluid
.offset5{margin-left:45.299145299145295%;*margin-left:45.1927623204219%}.row-fluid .offset5:first-child{margin-left:42.73504273504273%;*margin-left:42.62865975631933%}.row-fluid
.offset4{margin-left:36.75213675213675%;*margin-left:36.645753773413354%}.row-fluid .offset4:first-child{margin-left:34.18803418803419%;*margin-left:34.081651209310785%}.row-fluid
.offset3{margin-left:28.205128205128204%;*margin-left:28.0987452264048%}.row-fluid .offset3:first-child{margin-left:25.641025641025642%;*margin-left:25.53464266230224%}.row-fluid
.offset2{margin-left:19.65811965811966%;*margin-left:19.551736679396257%}.row-fluid .offset2:first-child{margin-left:17.094017094017094%;*margin-left:16.98763411529369%}.row-fluid
.offset1{margin-left:11.11111111111111%;*margin-left:11.004728132387708%}.row-fluid .offset1:first-child{margin-left:8.547008547008547%;*margin-left:8.440625568285142%}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:30px}input.span12,textarea.span12,.uneditable-input.span12{width:1156px}input.span11,textarea.span11,.uneditable-input.span11{width:1056px}input.span10,textarea.span10,.uneditable-input.span10{width:956px}input.span9,textarea.span9,.uneditable-input.span9{width:856px}input.span8,textarea.span8,.uneditable-input.span8{width:756px}input.span7,textarea.span7,.uneditable-input.span7{width:656px}input.span6,textarea.span6,.uneditable-input.span6{width:556px}input.span5,textarea.span5,.uneditable-input.span5{width:456px}input.span4,textarea.span4,.uneditable-input.span4{width:356px}input.span3,textarea.span3,.uneditable-input.span3{width:256px}input.span2,textarea.span2,.uneditable-input.span2{width:156px}input.span1,textarea.span1,.uneditable-input.span1{width:56px}.thumbnails{margin-left:-30px}.thumbnails>li{margin-left:30px}.row-fluid
.thumbnails{margin-left:0}}@media(min-width:768px) and (max-width:979px){.row{margin-left:-20px;*zoom:1}.row:before,.row:after{display:table;line-height:0;content:""}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:20px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:724px}.span12{width:724px}.span11{width:662px}.span10{width:600px}.span9{width:538px}.span8{width:476px}.span7{width:414px}.span6{width:352px}.span5{width:290px}.span4{width:228px}.span3{width:166px}.span2{width:104px}.span1{width:42px}.offset12{margin-left:764px}.offset11{margin-left:702px}.offset10{margin-left:640px}.offset9{margin-left:578px}.offset8{margin-left:516px}.offset7{margin-left:454px}.offset6{margin-left:392px}.offset5{margin-left:330px}.offset4{margin-left:268px}.offset3{margin-left:206px}.offset2{margin-left:144px}.offset1{margin-left:82px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;line-height:0;content:""}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;float:left;width:100%;min-height:30px;margin-left:2.7624309392265194%;*margin-left:2.709239449864817%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.7624309392265194%}.row-fluid
.span12{width:100%;*width:99.94680851063829%}.row-fluid
.span11{width:91.43646408839778%;*width:91.38327259903608%}.row-fluid
.span10{width:82.87292817679558%;*width:82.81973668743387%}.row-fluid
.span9{width:74.30939226519337%;*width:74.25620077583166%}.row-fluid
.span8{width:65.74585635359117%;*width:65.69266486422946%}.row-fluid
.span7{width:57.18232044198895%;*width:57.12912895262725%}.row-fluid
.span6{width:48.61878453038674%;*width:48.56559304102504%}.row-fluid
.span5{width:40.05524861878453%;*width:40.00205712942283%}.row-fluid
.span4{width:31.491712707182323%;*width:31.43852121782062%}.row-fluid
.span3{width:22.92817679558011%;*width:22.87498530621841%}.row-fluid
.span2{width:14.3646408839779%;*width:14.311449394616199%}.row-fluid
.span1{width:5.801104972375691%;*width:5.747913483013988%}.row-fluid
.offset12{margin-left:105.52486187845304%;*margin-left:105.41847889972962%}.row-fluid .offset12:first-child{margin-left:102.76243093922652%;*margin-left:102.6560479605031%}.row-fluid
.offset11{margin-left:96.96132596685082%;*margin-left:96.8549429881274%}.row-fluid .offset11:first-child{margin-left:94.1988950276243%;*margin-left:94.09251204890089%}.row-fluid
.offset10{margin-left:88.39779005524862%;*margin-left:88.2914070765252%}.row-fluid .offset10:first-child{margin-left:85.6353591160221%;*margin-left:85.52897613729868%}.row-fluid
.offset9{margin-left:79.8342541436464%;*margin-left:79.72787116492299%}.row-fluid .offset9:first-child{margin-left:77.07182320441989%;*margin-left:76.96544022569647%}.row-fluid
.offset8{margin-left:71.2707182320442%;*margin-left:71.16433525332079%}.row-fluid .offset8:first-child{margin-left:68.50828729281768%;*margin-left:68.40190431409427%}.row-fluid
.offset7{margin-left:62.70718232044199%;*margin-left:62.600799341718584%}.row-fluid .offset7:first-child{margin-left:59.94475138121547%;*margin-left:59.838368402492065%}.row-fluid
.offset6{margin-left:54.14364640883978%;*margin-left:54.037263430116376%}.row-fluid .offset6:first-child{margin-left:51.38121546961326%;*margin-left:51.27483249088986%}.row-fluid
.offset5{margin-left:45.58011049723757%;*margin-left:45.47372751851417%}.row-fluid .offset5:first-child{margin-left:42.81767955801105%;*margin-left:42.71129657928765%}.row-fluid
.offset4{margin-left:37.01657458563536%;*margin-left:36.91019160691196%}.row-fluid .offset4:first-child{margin-left:34.25414364640884%;*margin-left:34.14776066768544%}.row-fluid
.offset3{margin-left:28.45303867403315%;*margin-left:28.346655695309746%}.row-fluid .offset3:first-child{margin-left:25.69060773480663%;*margin-left:25.584224756083227%}.row-fluid
.offset2{margin-left:19.88950276243094%;*margin-left:19.783119783707537%}.row-fluid .offset2:first-child{margin-left:17.12707182320442%;*margin-left:17.02068884448102%}.row-fluid
.offset1{margin-left:11.32596685082873%;*margin-left:11.219583872105325%}.row-fluid .offset1:first-child{margin-left:8.56353591160221%;*margin-left:8.457152932878806%}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:20px}input.span12,textarea.span12,.uneditable-input.span12{width:710px}input.span11,textarea.span11,.uneditable-input.span11{width:648px}input.span10,textarea.span10,.uneditable-input.span10{width:586px}input.span9,textarea.span9,.uneditable-input.span9{width:524px}input.span8,textarea.span8,.uneditable-input.span8{width:462px}input.span7,textarea.span7,.uneditable-input.span7{width:400px}input.span6,textarea.span6,.uneditable-input.span6{width:338px}input.span5,textarea.span5,.uneditable-input.span5{width:276px}input.span4,textarea.span4,.uneditable-input.span4{width:214px}input.span3,textarea.span3,.uneditable-input.span3{width:152px}input.span2,textarea.span2,.uneditable-input.span2{width:90px}input.span1,textarea.span1,.uneditable-input.span1{width:28px}}@media(max-width:767px){body{padding-right:20px;padding-left:20px}.navbar-fixed-top,.navbar-fixed-bottom,.navbar-static-top{margin-right:-20px;margin-left:-20px}.container-fluid{padding:0}.dl-horizontal
dt{float:none;width:auto;clear:none;text-align:left}.dl-horizontal
dd{margin-left:0}.container{width:auto}.row-fluid{width:100%}.row,.thumbnails{margin-left:0}.thumbnails>li{float:none;margin-left:0}[class*="span"],.uneditable-input[class*="span"],.row-fluid [class*="span"]{display:block;float:none;width:100%;margin-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.span12,.row-fluid
.span12{width:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="offset"]:first-child{margin-left:0}.input-large,.input-xlarge,.input-xxlarge,input[class*="span"],select[class*="span"],textarea[class*="span"],.uneditable-input{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.input-prepend input,.input-append input,.input-prepend input[class*="span"],.input-append input[class*="span"]{display:inline-block;width:auto}.controls-row [class*="span"]+[class*="span"]{margin-left:0}.modal{position:fixed;top:20px;right:20px;left:20px;width:auto;margin:0}.modal.fade{top:-100px}.modal.fade.in{top:20px}}@media(max-width:480px){.nav-collapse{-webkit-transform:translate3d(0,0,0)}.page-header h1
small{display:block;line-height:20px}input[type="checkbox"],input[type="radio"]{border:1px
solid #ccc}.form-horizontal .control-label{float:none;width:auto;padding-top:0;text-align:left}.form-horizontal
.controls{margin-left:0}.form-horizontal .control-list{padding-top:0}.form-horizontal .form-actions{padding-right:10px;padding-left:10px}.media .pull-left,.media .pull-right{display:block;float:none;margin-bottom:10px}.media-object{margin-right:0;margin-left:0}.modal{top:10px;right:10px;left:10px}.modal-header
.close{padding:10px;margin:-10px}.carousel-caption{position:static}}@media(max-width:979px){body{padding-top:0}.navbar-fixed-top,.navbar-fixed-bottom{position:static}.navbar-fixed-top{margin-bottom:20px}.navbar-fixed-bottom{margin-top:20px}.navbar-fixed-top .navbar-inner,.navbar-fixed-bottom .navbar-inner{padding:5px}.navbar
.container{width:auto;padding:0}.navbar
.brand{padding-right:10px;padding-left:10px;margin:0
0 0 -5px}.nav-collapse{clear:both}.nav-collapse
.nav{float:none;margin:0
0 10px}.nav-collapse .nav>li{float:none}.nav-collapse .nav>li>a{margin-bottom:2px}.nav-collapse .nav>.divider-vertical{display:none}.nav-collapse .nav .nav-header{color:#777;text-shadow:none}.nav-collapse .nav>li>a,.nav-collapse .dropdown-menu
a{padding:9px
15px;font-weight:bold;color:#777;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.nav-collapse
.btn{padding:4px
10px 4px;font-weight:normal;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.nav-collapse .dropdown-menu li+li
a{margin-bottom:2px}.nav-collapse .nav>li>a:hover,.nav-collapse .nav>li>a:focus,.nav-collapse .dropdown-menu a:hover,.nav-collapse .dropdown-menu a:focus{background-color:#f2f2f2}.navbar-inverse .nav-collapse .nav>li>a,.navbar-inverse .nav-collapse .dropdown-menu
a{color:#999}.navbar-inverse .nav-collapse .nav>li>a:hover,.navbar-inverse .nav-collapse .nav>li>a:focus,.navbar-inverse .nav-collapse .dropdown-menu a:hover,.navbar-inverse .nav-collapse .dropdown-menu a:focus{background-color:#111}.nav-collapse.in .btn-group{padding:0;margin-top:5px}.nav-collapse .dropdown-menu{position:static;top:auto;left:auto;display:none;float:none;max-width:none;padding:0;margin:0
15px;background-color:transparent;border:0;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.nav-collapse .open>.dropdown-menu{display:block}.nav-collapse .dropdown-menu:before,.nav-collapse .dropdown-menu:after{display:none}.nav-collapse .dropdown-menu
.divider{display:none}.nav-collapse .nav>li>.dropdown-menu:before,.nav-collapse .nav>li>.dropdown-menu:after{display:none}.nav-collapse .navbar-form,.nav-collapse .navbar-search{float:none;padding:10px
15px;margin:10px
0;border-top:1px solid #f2f2f2;border-bottom:1px solid #f2f2f2;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1);box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1)}.navbar-inverse .nav-collapse .navbar-form,.navbar-inverse .nav-collapse .navbar-search{border-top-color:#111;border-bottom-color:#111}.navbar .nav-collapse .nav.pull-right{float:none;margin-left:0}.nav-collapse,.nav-collapse.collapse{height:0;overflow:hidden}.navbar .btn-navbar{display:block}.navbar-static .navbar-inner{padding-right:10px;padding-left:10px}}@media(min-width:980px){.nav-collapse.collapse{height:auto!important;overflow:visible!important}}@media(min-width:980px){.dir-rtl .navbar .nav.pull-right,.dir-rtl .navbar
.logininfo{float:left}.dir-rtl .navbar
.nav{float:right}.dir-rtl .navbar .nav>li{float:right}}@media(min-width:980px) and (max-width:1199px){.form-item .form-label,.mform .fitem div.fitemtitle,.userprofile dl.list dt,.form-horizontal .control-label{width:200px}.form-item .form-setting,.form-item .form-description,.mform .fitem .felement,#page-mod-forum-search .c1,.mform .fdescription.required,.userprofile dl.list dd,.form-horizontal
.controls{margin-left:220px}.dir-rtl .form-item .form-setting,.dir-rtl .form-item .form-description,.dir-rtl .mform .fitem .felement,.dir-rtl .mform .fdescription.required,.dir-rtl .userprofile dl.list dd,.dir-rtl .form-horizontal
.controls{margin-right:220px}#page-mod-forum-search.dir-lrt
.c1{margin-right:220px}.path-admin .buttons,.form-buttons{padding-left:220px}}@media(max-width:873px){.file-picker .fp-repo-area{float:none;width:100%;height:auto;max-height:220px;border:0;y-scroll:auto}.file-picker .fp-repo-items{float:none;width:100%}.file-picker .fp-login-form .fp-login-input
label{text-align:left}.dir-rtl .file-picker .fp-login-form .fp-login-input
label{text-align:right}.file-picker .fp-content form
td{display:block;width:100%;text-align:left}.dir-rtl .file-picker .fp-content form
td{text-align:right}.fp-content .mdl-right{text-align:left}.dir-rtl .fp-content .mdl-right{text-align:right}.fp-repo-items .fp-navbar{border-top:1px solid #bbb}.dir-rtl .userprofile dl.list dt,.dir-rtl .userprofile dl.list
dd{float:none;margin-right:0;text-align:right}.fp-formset
div{height:auto}}@media(min-width:1200px){.path-question #id_answerhdr
div.fitem_feditor{padding-right:6px}.loginbox.twocolumns
.loginpanel{margin-left:0}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{width:48.717948717948715%;*width:48.664757228587014%}.form-item .form-label,.mform .fitem div.fitemtitle,.userprofile dl.list dt,.form-horizontal .control-label{width:245px}.form-item .form-setting,.form-item .form-description,.mform .fitem .felement,#page-mod-forum-search .c1,.mform .fdescription.required,.userprofile dl.list dd,.form-horizontal
.controls{margin-left:265px}.dir-rtl .form-item .form-setting,.dir-rtl .form-item .form-description,.dir-rtl .mform .fitem .felement,.dir-rtl .mform .fdescription.required,.dir-rtl .userprofile dl.list dd,.dir-rtl .form-horizontal
.controls{margin-right:165px}.dir-rtl #page-mod-forum-search
.c1{margin-right:265px}.dir-rtl .form-item .form-label,.dir-rtl .mform .fitem div.fitemtitle,.dir-rtl .userprofile dl.list dt,.dir-rtl .form-horizontal .control-label{width:145px}.path-admin .buttons,.form-buttons{padding-left:265px}.dir-rtl .path-admin .buttons,.dir-rtl .form-buttons{padding-right:265px}.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:74.35897435897436%;*width:74.30578286961266%}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4{width:23.076923076923077%;*width:23.023731587561375%}}@media(min-width:980px){.loginbox.twocolumns
.loginpanel{margin-left:0}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{width:48.617948717948715%;*width:48.664757228587014%}}@media(min-width:768px) and (max-width:979px){.loginbox.twocolumns
.loginpanel{margin-left:0}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{width:48.61878453038674%;*width:48.56559304102504%}.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:74.30939226519337%;*width:74.25620077583166%}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4{width:22.92817679558011%;*width:22.87498530621841%}}@media(max-width:767px){.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{display:block;float:none;width:100%;margin-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}#page-mod-quiz-edit div.quizcontents,.questionbankwindow.block{float:none;width:100%}#page-mod-quiz-edit #block-region-side-pre,#page-mod-quiz-edit #block-region-side-post{clear:both}}@media(max-width:480px){{}.nav-tabs>li{float:none}.nav-tabs>li>a{margin-right:0}.nav-tabs{border-bottom:0}.nav-tabs>li>a{border:1px
solid #ddd;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.nav-tabs>.active>a,.nav-tabs>.active>a:hover{border:1px
solid #ddd}.nav-tabs>li:first-child>a{-webkit-border-top-right-radius:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;border-top-left-radius:4px;-moz-border-radius-topright:4px;-moz-border-radius-topleft:4px}.nav-tabs>li:last-child>a{-webkit-border-bottom-right-radius:4px;border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;border-bottom-left-radius:4px;-moz-border-radius-bottomright:4px;-moz-border-radius-bottomleft:4px}.nav-tabs>li>a:hover,.nav-tabs>li>a:focus{z-index:2;border-color:#ddd}.fp-content-center{display:block;vertical-align:top}.course-content ul.topics li.section,.course-content ul.topics li.section .content,.course-content ul.weeks li.section .content,.course-content ul.weeks li.section,.course-content
ul.section{padding:0;margin-right:0;margin-left:0}.activityinstance{display:block}.editing .course-content .section
.activity{padding-bottom:.2em;margin-bottom:.2em;border-bottom:thin solid #eee}.course-content .section .activity
.commands{text-align:right}.jsenabled .choosercontainer #chooseform
.alloptions{max-width:100%}.jsenabled .choosercontainer #chooseform .instruction,.jsenabled .choosercontainer #chooseform
.typesummary{position:static}.que
.info{float:none;width:auto}.que
.content{margin:0}.path-mod-choice .horizontal .choices
.option{display:block}.path-mod-forum .forumsearch
#search{width:120px}.path-mod-forum .forumheaderlist
.picture{display:none}}@media(min-width:768px){.row-fluid .desktop-first-column{margin-left:0}#page-navbar .breadcrumb-button{display:inline}}@media(max-width:767px){.row-fluid .desktop-first-column{clear:right}}@media(max-width:767px){.form-item .form-label,.mform .fitem
div.fitemtitle{float:none;width:auto;padding-top:0;text-align:left}.form-item .form-label
label{display:inline-block;margin-right:.5em}.form-item .form-setting .form-checkbox{margin-top:0}.form-label span.form-shortname{display:inline-block}.form-item .form-setting,.mform .fitem .felement,.path-backup .mform .fitem .felement,.mform .fdescription.required,.form-item .form-description{margin-left:0}table#form td.submit,.form-buttons,#fitem_id_submitbutton,.fp-content-center form+div,#fgroup_id_buttonar,.form-horizontal .form-actions,.fitem_fsubmit
.felement.fsubmit{padding-right:10px;padding-left:10px}#helppopupbox{left:0!important;width:auto!important}}@media(min-width:768px) and (max-width:979px){.block_calendar_month .content,.block .minicalendar
td{padding-right:0;padding-left:0}}.dir-rtl .dropdown-menu{right:0;left:auto}.dir-rtl .navbar .nav>li>.dropdown-menu:before{right:9px;left:auto}.dir-rtl .navbar .nav>li>.dropdown-menu:after{right:10px;left:auto}.dir-rtl .dropdown-submenu>a:after{margin-right:-10px;margin-left:0;border-right-color:#ccc;border-left-color:transparent;border-width:5px 5px 5px 0}.dir-rtl .dropdown-submenu>.dropdown-menu{right:100%;left:auto}@media(max-width:979px){.nav-collapse{height:0}.nav-collapse .nav>li>a{color:#333}.nav-collapse .nav>li>a:hover,.nav-collapse .nav>li>a:focus,.nav-collapse .dropdown-menu a:hover,.nav-collapse .dropdown-menu a:focus,.nav-collapse .dropdown-submenu a:focus,.nav-collapse .dropdown-submenu a:hover,.nav-collapse .dropdown-submenu a:active,.nav-collapse .dropdown-menu>li>a:hover,.nav-collapse .dropdown-menu>li>a:focus{color:#333;background-image:none}.nav-collapse.active{height:auto}.path-mod-data .box>table>tbody>tr>td{display:block}.path-mod-forum .forumheaderlist thead
.header{font-size:12px;font-weight:normal}.path-mod-forum .forumheaderlist .discussion .author,.path-mod-forum .forumheaderlist .discussion .replies,.path-mod-forum .forumheaderlist .discussion
.lastpost{font-size:12px}.path-mod-forum .forumheaderlist .discussion .replies .unread
a{padding:0}}@media(max-width:767px){#filesskin .yui3-panel,#filesskin .file-picker.fp-generallayout{left:0;width:100%}.userprofile dl.list
dt{float:none;width:auto;clear:none;text-align:left}.userprofile dl.list
dd{margin-left:0}#page-mod-wiki-create .mform .fitem
div.fitemtitle{float:left}.container{width:auto}.row-fluid{width:100%}.row-fluid .span8.pull-right,.row-fluid .span9.pull-right{float:none}.row{margin-left:0}[class*="span"],.row-fluid [class*="span"]{display:block;float:none;width:100%;margin-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4,.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:100%;*width:99.94680851063829%}.row-fluid
.span12{width:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="offset"]:first-child{margin-left:0}div[role=main]{margin-bottom:1em}.coursebox .info .name
a{background-position:0 13px}.category-browse .coursebox .info .name
a{background-position:0 13px}}@media(min-width:1200px) and (max-width:1600px){#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-3 #course-listing{width:48.717948717948715%;*width:48.664757228587014%;margin-left:2.564102564102564%;*margin-left:2.5109110747408616%}#course-category-listings.columns-3 #category-listing:first-child,#course-category-listings.columns-3 #course-listing:first-child{margin-left:0}#course-category-listings.columns-3 #course-detail{width:100%;*width:99.94680851063829%;margin:1em
0 0}}@media(max-width:1199px){.path-question #id_answerhdr
div.fitem{padding-right:6px;padding-left:4px}#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-3 #course-listing,#course-category-listings.columns-3 #course-detail{width:100%;*width:99.94680851063829%;margin:0
0 1em 0}#page-mod-forum-discuss
.discussioncontrols{text-align:right}#page-mod-forum-discuss .discussioncontrols
.discussioncontrol{display:inline-block;float:none;width:auto;margin:0
3px .5em}#page-mod-forum-discuss .discussioncontrols .discussioncontrol select,#page-mod-forum-discuss .discussioncontrols .discussioncontrol
input{margin-bottom:0}#page-mod-forum-discuss .discussioncontrols
.discussioncontrol.movediscussion{padding-right:0;margin-right:0}#page-mod-forum-discuss.dir-rtl
.discussioncontrols{text-align:left}}@media(max-width:768px){.fp-forminset .control-group
.controls{margin-left:0}.dir-rtl .fp-formset .control-group label.control-label{float:none;text-align:right}.dir-rtl .fp-forminset .control-group label.control-label{float:none;text-align:right}.dir-rtl .fp-forminset .control-group
.controls{margin-right:0}}.phpinfo table,.phpinfo th,.phpinfo
h2{margin:auto;text-align:left}.phpinfo
h2{width:600px}.phpinfo .e,.phpinfo .v,.phpinfo
.h{font-size:.8em;color:#000;vertical-align:baseline;background-color:#ccc;border:1px
solid #000}.phpinfo
.e{font-weight:bold;background-color:#ccf}.phpinfo
.h{font-weight:bold;background-color:#99c}#page-footer
.performanceinfo{margin:10px
20%}#page-footer .performanceinfo
span{display:block}#page-footer
.validators{padding-top:5px;margin-top:40px;border-top:1px dotted gray}#page-footer .validators
ul{padding:0;margin:0;list-style-type:none}#page-footer .validators ul
li{display:inline;margin-right:10px;margin-left:10px}.performanceinfo
.cachesused{margin-top:1em}.performanceinfo .cachesused .cache-stats-heading,.performanceinfo .cachesused .cache-total-stats{margin-top:.3em;font-size:110%;font-weight:bold}#page-footer .performanceinfo .cachesused .cache-definition-stats{display:inline-block;margin:.3em;vertical-align:top;background-color:#f5f5f5}.cache-store-stats{padding:0
1.3em}.cache-store-stats.nohits{background-color:#f2dede}.cache-store-stats.lowhits{background-color:#fcf8e3}.cache-store-stats.hihits{background-color:#dff0d8}#page-footer,#page-footer .validators,#page-footer .purgecaches,#page-footer
.performanceinfo{text-align:center}table#explaincaps tbody>tr:nth-child(odd)>td,table#defineroletable tbody>tr:nth-child(odd)>td,table.grading-report tbody>tr:nth-child(odd)>td,table#listdirectories tbody>tr:nth-child(odd)>td,table.rolecaps tbody>tr:nth-child(odd)>td,table.userenrolment tbody>tr:nth-child(odd)>td,table#form tbody>tr:nth-child(odd)>td,form#movecourses table tbody>tr:nth-child(odd)>td,#page-admin-course-index .editcourse tbody>tr:nth-child(odd)>td,.forumheaderlist tbody>tr:nth-child(odd)>td,table.flexible tbody>tr:nth-child(odd)>td,.generaltable tbody>tr:nth-child(odd)>td,table#explaincaps tbody>tr:nth-child(odd)>th,table#defineroletable tbody>tr:nth-child(odd)>th,table.grading-report tbody>tr:nth-child(odd)>th,table#listdirectories tbody>tr:nth-child(odd)>th,table.rolecaps tbody>tr:nth-child(odd)>th,table.userenrolment tbody>tr:nth-child(odd)>th,table#form tbody>tr:nth-child(odd)>th,form#movecourses table tbody>tr:nth-child(odd)>th,#page-admin-course-index .editcourse tbody>tr:nth-child(odd)>th,.forumheaderlist tbody>tr:nth-child(odd)>th,table.flexible tbody>tr:nth-child(odd)>th,.generaltable tbody>tr:nth-child(odd)>th{background-color:#f9f9f9}.dir-rtl table#explaincaps td,.dir-rtl table#defineroletable td,.dir-rtl table.grading-report td,.dir-rtl table#listdirectories td,.dir-rtl table.rolecaps td,.dir-rtl table.userenrolment td,.dir-rtl table#form td,.dir-rtl form#movecourses table td,.dir-rtl .forumheaderlist td,.dir-rtl table.flexible td,.dir-rtl .generaltable td,.dir-rtl .generaltable thead:first-child tr:first-child td,.dir-rtl table#explaincaps th,.dir-rtl table#defineroletable th,.dir-rtl table.grading-report th,.dir-rtl table#listdirectories th,.dir-rtl table.rolecaps th,.dir-rtl table.userenrolment th,.dir-rtl table#form th,.dir-rtl form#movecourses table th,.dir-rtl .forumheaderlist th,.dir-rtl table.flexible th,.dir-rtl .generaltable th,.dir-rtl .generaltable thead:first-child tr:first-child
th{text-align:right}#page-admin-course-index.dir-rtl .editcourse td,#page-admin-course-index.dir-rtl .editcourse
th{text-align:right}#page-report-loglive-index .generaltable th,#page-admin-report-log-index .generaltable th,#page-report-log-user .generaltable th,#page-admin-user table th,.environmenttable th,.category_subcategories th,.rcs-results th,table#listdirectories th,#page-report-loglive-index .generaltable td,#page-admin-report-log-index .generaltable td,#page-report-log-user .generaltable td,#page-admin-user table td,.environmenttable td,.category_subcategories td,.rcs-results td,table#listdirectories
td{padding:4px
5px}.user-enroller-panel .uep-search-results .users tbody tr:hover>td,table.grading-report tbody tr:hover>td,.forumheaderlist tbody tr:hover>td,.generaltable tbody tr:hover>td,table.flexible tbody tr:hover>td,.category_subcategories tbody tr:hover>td,table#modules tbody tr:hover>td,table#permissions tbody tr:hover>td,.user-enroller-panel .uep-search-results .users tbody tr:hover>th,table.grading-report tbody tr:hover>th,.forumheaderlist tbody tr:hover>th,.generaltable tbody tr:hover>th,table.flexible tbody tr:hover>th,.category_subcategories tbody tr:hover>th,table#modules tbody tr:hover>th,table#permissions tbody tr:hover>th{background-color:#f5f5f5}div[id^="bar_pbar_"]{height:20px!important;margin-bottom:20px!important;overflow:hidden!important;background-color:#f7f7f7!important;background-image:-moz-linear-gradient(top,#f5f5f5,#f9f9f9)!important;background-image:-webkit-gradient(linear,0 0,0 100%,from(#f5f5f5),to(#f9f9f9))!important;background-image:-webkit-linear-gradient(top,#f5f5f5,#f9f9f9)!important;background-image:-o-linear-gradient(top,#f5f5f5,#f9f9f9)!important;background-image:linear-gradient(to bottom,#f5f5f5,#f9f9f9)!important;background-repeat:repeat-x!important;border:none!important;-webkit-border-radius:4px!important;-moz-border-radius:4px!important;border-radius:4px!important;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5',endColorstr='#fff9f9f9',GradientType=0)!important;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1)!important;-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1)!important;box-shadow:inset 0 1px 2px rgba(0,0,0,0.1)!important}div[id^="progress_pbar_"]{float:left!important;height:100%!important;padding-top:0!important;font-size:12px!important;color:#fff!important;text-align:center!important;text-shadow:0 -1px 0 rgba(0,0,0,0.25)!important;background-color:#0e90d2!important;background-image:-moz-linear-gradient(top,#149bdf,#0480be)!important;background-image:-webkit-gradient(linear,0 0,0 100%,from(#149bdf),to(#0480be))!important;background-image:-webkit-linear-gradient(top,#149bdf,#0480be)!important;background-image:-o-linear-gradient(top,#149bdf,#0480be)!important;background-image:linear-gradient(to bottom,#149bdf,#0480be)!important;background-repeat:repeat-x!important;border:none!important;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf',endColorstr='#ff0480be',GradientType=0)!important;-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15)!important;-moz-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15)!important;box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15)!important;-webkit-box-sizing:border-box!important;-moz-box-sizing:border-box!important;box-sizing:border-box!important;-webkit-transition:width .6s ease!important;-moz-transition:width .6s ease!important;-o-transition:width .6s ease!important;transition:width .6s ease!important}input.form-submit,input#id_submitbutton,input#id_submitbutton2,.path-admin .buttons input[type="submit"],td.submit
input{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#005aa8;*background-color:#0038a8;background-image:-moz-linear-gradient(top,#0070a8,#0038a8);background-image:-webkit-gradient(linear,0 0,0 100%,from(#0070a8),to(#0038a8));background-image:-webkit-linear-gradient(top,#0070a8,#0038a8);background-image:-o-linear-gradient(top,#0070a8,#0038a8);background-image:linear-gradient(to bottom,#0070a8,#0038a8);background-repeat:repeat-x;border-color:#0038a8 #0038a8 #001e5c;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8',endColorstr='#ff0038a8',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}input.form-submit:hover,input#id_submitbutton:hover,input#id_submitbutton2:hover,.path-admin .buttons input[type="submit"]:hover,td.submit input:hover,input.form-submit:focus,input#id_submitbutton:focus,input#id_submitbutton2:focus,.path-admin .buttons input[type="submit"]:focus,td.submit input:focus,input.form-submit:active,input#id_submitbutton:active,input#id_submitbutton2:active,.path-admin .buttons input[type="submit"]:active,td.submit input:active,input.form-submit.active,input#id_submitbutton.active,input#id_submitbutton2.active,.path-admin .buttons input[type="submit"].active,td.submit input.active,input.form-submit.disabled,input#id_submitbutton.disabled,input#id_submitbutton2.disabled,.path-admin .buttons input[type="submit"].disabled,td.submit input.disabled,input.form-submit[disabled],input#id_submitbutton[disabled],input#id_submitbutton2[disabled],.path-admin .buttons input[type="submit"][disabled],td.submit input[disabled]{color:#fff;background-color:#0038a8;*background-color:#002f8f}input.form-submit:active,input#id_submitbutton:active,input#id_submitbutton2:active,.path-admin .buttons input[type="submit"]:active,td.submit input:active,input.form-submit.active,input#id_submitbutton.active,input#id_submitbutton2.active,.path-admin .buttons input[type="submit"].active,td.submit
input.active{background-color:#002775 \9}input.form-submit .caret,input#id_submitbutton .caret,input#id_submitbutton2 .caret,.path-admin .buttons input[type="submit"] .caret,td.submit input
.caret{border-top-color:#fff;border-bottom-color:#fff}#notice .singlebutton+.singlebutton input,.submit.buttons input[name="cancel"]{display:inline-block;*display:inline;padding:4px
12px;margin-bottom:0;*margin-left:.3em;font-size:14px;line-height:20px;color:#333;text-align:center;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;cursor:pointer;background-color:#f5f5f5;*background-color:#e6e6e6;background-image:-moz-linear-gradient(top,#fff,#e6e6e6);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fff),to(#e6e6e6));background-image:-webkit-linear-gradient(top,#fff,#e6e6e6);background-image:-o-linear-gradient(top,#fff,#e6e6e6);background-image:linear-gradient(to bottom,#fff,#e6e6e6);background-repeat:repeat-x;border:1px
solid #ccc;*border:0;border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffe6e6e6',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);*zoom:1;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 1px 0 rgba(255,255,255,0.2),0 1px 2px rgba(0,0,0,0.05)}#notice .singlebutton+.singlebutton input:hover,.submit.buttons input[name="cancel"]:hover,#notice .singlebutton+.singlebutton input:focus,.submit.buttons input[name="cancel"]:focus,#notice .singlebutton+.singlebutton input:active,.submit.buttons input[name="cancel"]:active,#notice .singlebutton+.singlebutton input.active,.submit.buttons input[name="cancel"].active,#notice .singlebutton+.singlebutton input.disabled,.submit.buttons input[name="cancel"].disabled,#notice .singlebutton+.singlebutton input[disabled],.submit.buttons input[name="cancel"][disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#notice .singlebutton+.singlebutton input:active,.submit.buttons input[name="cancel"]:active,#notice .singlebutton+.singlebutton input.active,.submit.buttons input[name="cancel"].active{background-color:#ccc \9}#notice .singlebutton+.singlebutton input:first-child,.submit.buttons input[name="cancel"]:first-child{*margin-left:0}#notice .singlebutton+.singlebutton input:hover,.submit.buttons input[name="cancel"]:hover,#notice .singlebutton+.singlebutton input:focus,.submit.buttons input[name="cancel"]:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#notice .singlebutton+.singlebutton input:focus,.submit.buttons input[name="cancel"]:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#notice .singlebutton+.singlebutton input.active,.submit.buttons input[name="cancel"].active,#notice .singlebutton+.singlebutton input:active,.submit.buttons input[name="cancel"]:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05);box-shadow:inset 0 2px 4px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.05)}#notice .singlebutton+.singlebutton input.disabled,.submit.buttons input[name="cancel"].disabled,#notice .singlebutton+.singlebutton input[disabled],.submit.buttons input[name="cancel"][disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#notice .singlebutton+.singlebutton input .label,.submit.buttons input[name="cancel"] .label,#notice .singlebutton+.singlebutton input .badge,.submit.buttons input[name="cancel"] .badge{position:relative;top:-1px}#notice .singlebutton+.singlebutton input,.submit.buttons input[name="cancel"]{margin:0
0 10px 5px}input[id$="_clearbutton"],input[type="reset"]{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#faa732;*background-color:#f89406;background-image:-moz-linear-gradient(top,#fbb450,#f89406);background-image:-webkit-gradient(linear,0 0,0 100%,from(#fbb450),to(#f89406));background-image:-webkit-linear-gradient(top,#fbb450,#f89406);background-image:-o-linear-gradient(top,#fbb450,#f89406);background-image:linear-gradient(to bottom,#fbb450,#f89406);background-repeat:repeat-x;border-color:#f89406 #f89406 #ad6704;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450',endColorstr='#fff89406',GradientType=0);filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}input[id$="_clearbutton"]:hover,input[type="reset"]:hover,input[id$="_clearbutton"]:focus,input[type="reset"]:focus,input[id$="_clearbutton"]:active,input[type="reset"]:active,input[id$="_clearbutton"].active,input[type="reset"].active,input[id$="_clearbutton"].disabled,input[type="reset"].disabled,input[id$="_clearbutton"][disabled],input[type="reset"][disabled]{color:#fff;background-color:#f89406;*background-color:#df8505}input[id$="_clearbutton"]:active,input[type="reset"]:active,input[id$="_clearbutton"].active,input[type="reset"].active{background-color:#c67605 \9}input[id$="_clearbutton"] .caret,input[type="reset"] .caret{border-top-color:#fff;border-bottom-color:#fff}a.logo{background:url() no-repeat 0 0;display:block;float:left;height:75px;margin:0;padding:0;width:100%}.dir-rtl
a.logo{background:url() no-repeat 100% 0;display:block;float:right}