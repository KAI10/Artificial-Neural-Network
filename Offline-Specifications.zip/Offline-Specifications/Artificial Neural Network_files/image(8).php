<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [
	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">
]>
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="24px" height="24px" viewBox="0 0 24 24" style="overflow:visible;enable-background:new 0 0 24 24;"
	 xml:space="preserve" preserveAspectRatio="xMinYMid meet">
<defs>
</defs>
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="14.0054" y1="0" x2="14.0054" y2="20.0005">
	<stop  offset="0" style="stop-color:#95BFF8"/>
	<stop  offset="0.5569" style="stop-color:#84ADEF"/>
	<stop  offset="1" style="stop-color:#7CA4EB"/>
	<a:midPointStop  offset="0" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="0.4" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="1" style="stop-color:#7CA4EB"/>
</linearGradient>
<polygon style="fill:url(#SVGID_1_);" points="16.3,0 15.4,0 6.7,0 6,0 6,20 6.7,20 21.7,20 22,20 22,6.6 "/>
<linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="14.0054" y1="1" x2="14.0054" y2="19.0005">
	<stop  offset="0" style="stop-color:#E7F4FC"/>
	<stop  offset="1" style="stop-color:#DEEFFC"/>
	<a:midPointStop  offset="0" style="stop-color:#E7F4FC"/>
	<a:midPointStop  offset="0.5" style="stop-color:#E7F4FC"/>
	<a:midPointStop  offset="1" style="stop-color:#DEEFFC"/>
</linearGradient>
<polygon style="fill:url(#SVGID_2_);" points="7,19 7,1 15.8,1 21,6.9 21,19 "/>
<linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="14.0054" y1="2" x2="14.0054" y2="18.0005">
	<stop  offset="0" style="stop-color:#CEE9F9"/>
	<stop  offset="1" style="stop-color:#BBDFF8"/>
	<a:midPointStop  offset="0" style="stop-color:#CEE9F9"/>
	<a:midPointStop  offset="0.5" style="stop-color:#CEE9F9"/>
	<a:midPointStop  offset="1" style="stop-color:#BBDFF8"/>
</linearGradient>
<polygon style="fill:url(#SVGID_3_);" points="8,18 8,2 15.4,2 20,7.3 20,18 "/>
<linearGradient id="SVGID_4_" gradientUnits="userSpaceOnUse" x1="18.3101" y1="0" x2="18.3101" y2="7.7852">
	<stop  offset="0" style="stop-color:#95BFF8"/>
	<stop  offset="0.5569" style="stop-color:#84ADEF"/>
	<stop  offset="1" style="stop-color:#7CA4EB"/>
	<a:midPointStop  offset="0" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="0.4" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="1" style="stop-color:#7CA4EB"/>
</linearGradient>
<path style="fill:url(#SVGID_4_);" d="M14.8,7.5c0,0,5.2-1.3,7.2,0.3c0-0.1,0-1.2,0-1.2L16.2,0c0,0-1.5,0-1.6,0
	C16.8,3,14.8,7.5,14.8,7.5z"/>
<linearGradient id="SVGID_5_" gradientUnits="userSpaceOnUse" x1="16.3003" y1="6.1616" x2="18.5911" y2="3.8708">
	<stop  offset="0" style="stop-color:#E7F4FC"/>
	<stop  offset="0.5181" style="stop-color:#E5F3FC"/>
	<stop  offset="0.7045" style="stop-color:#DEF0FB"/>
	<stop  offset="0.8371" style="stop-color:#D3EBFA"/>
	<stop  offset="0.872" style="stop-color:#CEE9F9"/>
	<stop  offset="1" style="stop-color:#BDD8F0"/>
	<a:midPointStop  offset="0" style="stop-color:#E7F4FC"/>
	<a:midPointStop  offset="0.87" style="stop-color:#E7F4FC"/>
	<a:midPointStop  offset="0.872" style="stop-color:#CEE9F9"/>
	<a:midPointStop  offset="0.5" style="stop-color:#CEE9F9"/>
	<a:midPointStop  offset="1" style="stop-color:#BDD8F0"/>
</linearGradient>
<path style="fill:url(#SVGID_5_);" d="M16.3,6.2c0.3-1.2,0.5-2.9,0.1-4.4l4,4.4C20,6.1,19.4,6,18.8,6C17.9,6,17,6.1,16.3,6.2z"/>
<linearGradient id="SVGID_6_" gradientUnits="userSpaceOnUse" x1="11.9673" y1="12.167" x2="11.9673" y2="23.8853">
	<stop  offset="0" style="stop-color:#DDA976"/>
	<stop  offset="1" style="stop-color:#9F6B37"/>
	<a:midPointStop  offset="0" style="stop-color:#DDA976"/>
	<a:midPointStop  offset="0.5" style="stop-color:#DDA976"/>
	<a:midPointStop  offset="1" style="stop-color:#9F6B37"/>
</linearGradient>
<path style="fill:url(#SVGID_6_);" d="M10,18.9c-0.3-2.2,9.4,0.5,9.3-1.4c0-0.8-8.4-3.4-11.4-4.1c-0.9-0.2-6.5-1.2-6.5-1.2
	c-0.2,0.1-1.3,3.3-1.4,5.2c0.5,0.3,7.3,6.7,10,6.5c2.7-0.2,14.2-3.6,13.9-4.7C23.3,17.1,10.3,21.3,10,18.9z"/>
<linearGradient id="SVGID_7_" gradientUnits="userSpaceOnUse" x1="11.4893" y1="13.2803" x2="11.4893" y2="22.9336">
	<stop  offset="0" style="stop-color:#FFDDAA"/>
	<stop  offset="1" style="stop-color:#E3B17E"/>
	<a:midPointStop  offset="0" style="stop-color:#FFDDAA"/>
	<a:midPointStop  offset="0.5" style="stop-color:#FFDDAA"/>
	<a:midPointStop  offset="1" style="stop-color:#E3B17E"/>
</linearGradient>
<path style="fill:url(#SVGID_7_);" d="M1.7,17.4C1.4,17.2,1.2,17,1,16.9c0.1-1.2,0.6-2.8,0.9-3.6c1.8,0.3,5.1,0.9,5.7,1
	c2.6,0.6,9.4,2.3,9.7,3c0.5,1.1-8.3-1.9-8.1,1.7c0.2,3.5,12.4-0.6,12.7,0.5c0.2,0.7-10.1,3.6-12,3.5C7.9,22.8,3.3,18.8,1.7,17.4z"/>
<linearGradient id="SVGID_8_" gradientUnits="userSpaceOnUse" x1="7.5928" y1="14.4141" x2="7.5928" y2="21.9336">
	<stop  offset="0" style="stop-color:#F1C592"/>
	<stop  offset="1" style="stop-color:#E1AF7C"/>
	<a:midPointStop  offset="0" style="stop-color:#F1C592"/>
	<a:midPointStop  offset="0.5" style="stop-color:#F1C592"/>
	<a:midPointStop  offset="1" style="stop-color:#E1AF7C"/>
</linearGradient>
<path style="fill:url(#SVGID_8_);" d="M10.1,21.9c-0.8-0.1-2.8-1-7.6-5.2l-0.3-0.3c0.1-0.7,0.3-1.4,0.5-2.1c2.1,0.4,4.3,0.8,4.7,0.9
	c1.5,0.4,2.7,0.7,3.8,0.9c-1,0.1-1.8,0.4-2.3,1c-0.3,0.3-0.7,0.9-0.6,1.9c0.1,1.1,0.8,2.4,4,2.4c0.3,0,0.6,0,0.9,0
	C11.8,21.7,10.7,21.9,10.1,21.9L10.1,21.9z"/>
</svg>
